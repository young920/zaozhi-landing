// Kami 工作台服务端：静态页面 + 任务 API（端口默认 8712）
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { zipSync } from 'fflate';
import { publicTypes } from './types.mjs';
import { IS_WIN, LAPIAN, PEXELS_KEY, SKILLS, PYBIN } from './paths.mjs';
import { getTasks, findTask, createTask, cancelTask, retryTask, deleteTask, saveUpload, taskPaths, typeById, boot, capacity, engineEnv } from './engine.mjs';
import { readConfig, writeConfig, parallelCap, setAutostart, autostartState } from './config.mjs';
import { backupAll, saveToDownloadsZip } from './backup.mjs';
import { skillsCheck, skillsApply } from './skills.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const DIST = path.join(ROOT, 'web', 'dist');
const PORT = Number(process.env.PORT || 8712);
const SKIP_MARK = path.join(os.homedir(), '.zaozhiju', 'skip-setup'); // 装机"先不装"记号,bootstrap 认它

const MIME = {
  '.html': 'text/html; charset=utf-8', '.pdf': 'application/pdf', '.png': 'image/png',
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8',
  '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.mp4': 'video/mp4',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

function json(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

const shortErr = (e) => String(e?.message || e || '未知错误').slice(0, 200);

function readBody(req, maxBytes = 1e6) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', (d) => { b += d; if (b.length > maxBytes) reject(new Error('body too large')); });
    req.on('end', () => resolve(b));
    req.on('error', reject);
  });
}

function serveFile(res, file, { downloadName, req } = {}) {
  if (!fs.existsSync(file)) return json(res, 404, { error: '文件不存在' });
  const ext = path.extname(file);
  const headers = { 'content-type': MIME[ext] ?? 'application/octet-stream', 'cache-control': 'no-store', 'accept-ranges': 'bytes' };
  if (downloadName) {
    headers['content-disposition'] = `attachment; filename*=UTF-8''${encodeURIComponent(downloadName)}`;
  }
  // 视频要能拖进度条：支持 HTTP Range 分段（浏览器 <video> 必需）
  const rm = req && req.headers.range && /^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
  if (rm && ext === '.mp4') {
    const size = fs.statSync(file).size;
    let start = rm[1] ? parseInt(rm[1], 10) : 0;
    let end = rm[2] ? parseInt(rm[2], 10) : size - 1;
    if (start >= size) {
      res.writeHead(416, { ...headers, 'content-range': `bytes */${size}` });
      return res.end();
    }
    end = Math.min(end, size - 1);
    res.writeHead(206, { ...headers, 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${size}` });
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  headers['content-length'] = fs.statSync(file).size;
  res.writeHead(200, headers);
  fs.createReadStream(file).pipe(res);
}

function fileSlug(task) {
  const type = typeById(task.typeId);
  const topic = (task.topic || '素材成品').slice(0, 24).replace(/[\/\\:*?"<>|]/g, '_');
  return `${topic}-${type?.label ?? task.typeId}`;
}

// 成品文件定位（download 端点与桌面客户端「存到下载文件夹」共用一套规则）
function downloadArtifact(task, dir, kind) {
  if (kind === 'pdf') return { file: path.join(dir, 'output.pdf'), downloadName: `${fileSlug(task)}.pdf` };
  if (kind === 'pptx') return { file: path.join(dir, 'output.pptx'), downloadName: `${fileSlug(task)}.pptx` };
  if (kind === 'docx') return { file: path.join(dir, 'output.docx'), downloadName: `${fileSlug(task)}.docx` };
  if (kind === 'video') return { file: path.join(dir, 'output.mp4'), downloadName: `${fileSlug(task)}.mp4` };
  if (task.typeId === 'flowart') return { file: path.join(dir, 'output', 'art.png'), downloadName: `${fileSlug(task)}.png` };
  if (['xhs', 'wxcover'].includes(typeById(task.typeId)?.out)) {
    const outDir = path.join(dir, 'output');
    const cards = fs.existsSync(outDir) ? fs.readdirSync(outDir).filter((f) => /^(card|cover)-[a-z0-9-]+\.png$/i.test(f)).sort() : [];
    if (!cards.length) return { error: '没找到成品 PNG', code: 404 };
    const zipPath = path.join(dir, 'xhs-cards.zip');
    // 纯 Node 打包（fflate），不再依赖系统 zip 命令——Windows 上没有
    const entries = {};
    for (const c of cards) entries[c] = fs.readFileSync(path.join(outDir, c));
    fs.writeFileSync(zipPath, Buffer.from(zipSync(entries, { level: 0 })));
    return { file: zipPath, downloadName: `${fileSlug(task)}.zip` };
  }
  return { error: '落地页是网页：用"打开页面"查看，文件在服务器 output/ 目录', code: 400 };
}

// 桌面客户端（webview 壳）里没有浏览器的下载器和新窗口，这些动作交给系统办
function openWithSystem(file) {
  spawn(IS_WIN ? 'explorer.exe' : 'open', [file], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}
function saveToDownloads(srcFile, downloadName) {
  const downDir = path.join(os.homedir(), 'Downloads');
  fs.mkdirSync(downDir, { recursive: true });
  const { name, ext } = path.parse(downloadName);
  let dest = path.join(downDir, downloadName);
  let n = 2;
  while (fs.existsSync(dest)) dest = path.join(downDir, `${name} (${n++})${ext}`);
  fs.copyFileSync(srcFile, dest);
  return path.basename(dest);
}
// 桌面壳里点外部链接：target=_blank 是死的,交给系统浏览器
function openExternalUrl(url) {
  if (!/^https?:\/\//i.test(url)) return false;
  spawn(IS_WIN ? 'explorer.exe' : 'open', [url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  return true;
}

// ── 环境体检 + 设置 + 版本更新（界面「设置」页与首启指引用）──
const WIN_STATE_FILE = path.join(os.homedir(), '.zaozhiju', 'window.json'); // 桌面壳窗口大小/位置记忆
const VERSION = (() => { try { return fs.readFileSync(path.join(ROOT, 'VERSION'), 'utf8').trim(); } catch { return '0.0.0'; } })();
const UPDATE_URL = 'https://young920.github.io/zaozhi-landing/latest.json'; // 公开落地页仓的更新清单（私有仓拿不到 Release）
let envCache = { at: 0, data: null };
let updateCache = { at: 0, data: null };

function hasCmd(name, env) {
  try { return spawnSync(name, ['--version'], { stdio: 'ignore', timeout: 15000, shell: IS_WIN, env }) .status === 0; } catch { return false; }
}
// Word/PPT 产线依赖体检（2026-11-08）：pandoc(Word 转换)、python 库(pptx/docx)、放映软件(PPT 目检)——缺哪项设置页亮哪项
function pyOk(mod) {
  try { return spawnSync(IS_WIN ? 'python' : PYBIN, ['-c', `import ${mod}`], { timeout: 15000, stdio: 'ignore' }).status === 0; } catch { return false; }
}
function workbenchDeps() {
  let keynote = null;
  try { keynote = fs.existsSync('/Applications/Keynote.app') || hasCmd('soffice', engineEnv()); } catch { /* win 分支另行 */ }
  if (IS_WIN) {
    try { keynote = fs.existsSync('C:\\Program Files\\LibreOffice\\program\\soffice.exe') || hasCmd('soffice', engineEnv()); } catch { keynote = null; }
  }
  return { pandoc: hasCmd('pandoc', engineEnv()), pyLibs: pyOk('pptx') && pyOk('docx'), viewer: keynote };
}
function envStatus() {
  if (envCache.data && Date.now() - envCache.at < 60e3) return envCache.data;
  let pexels = false;
  try { pexels = !!fs.readFileSync(PEXELS_KEY, 'utf8').trim(); } catch { /* 没文件=没配 */ }
  let deps = null;
  try { deps = workbenchDeps(); } catch { /* 体检失败不拦主状态 */ }
  envCache = { at: Date.now(), data: { node: process.version, claude: hasCmd('claude'), pexels, deps } };
  return envCache.data;
}

// 选题模板存储（data/templates.json，不进 git、进不了备份也无妨——纯输入素材）
const TPLF = path.join(ROOT, 'data', 'templates.json');
function tplRead() { try { const a = JSON.parse(fs.readFileSync(TPLF, 'utf8')); return Array.isArray(a) ? a : []; } catch { return []; } }
function tplWrite(a) { try { fs.mkdirSync(path.dirname(TPLF), { recursive: true }); fs.writeFileSync(TPLF, JSON.stringify(a, null, 2)); } catch { /* 存不下就报给调用方 */ } }

// 一键升级的落地目录与状态
const UP = path.join(os.homedir(), '.zaozhiju', 'update');
function upStatus() { try { return JSON.parse(fs.readFileSync(path.join(UP, 'status.json'), 'utf8')); } catch { return null; } }
const vparts = (v) => String(v).split('.').map((n) => parseInt(n, 10) || 0);
const verGt = (a, b) => { const x = vparts(a), y = vparts(b); for (let i = 0; i < 3; i++) { if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0); } return false; };
async function checkUpdate(force) {
  if (force || !updateCache.data || Date.now() - updateCache.at > 864e5) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 6000);
      const r = await fetch(UPDATE_URL, { signal: ctrl.signal });
      clearTimeout(to);
      if (r.ok) updateCache = { at: Date.now(), data: await r.json() };
    } catch { updateCache = { ...updateCache, at: Date.now() }; } // 断网不算错,下次再查
  }
  const lat = updateCache.data;
  const update = lat && lat.version && verGt(lat.version, VERSION)
    ? { version: lat.version, notes: lat.notes || '', url: lat.url || 'https://github.com/young920/kami/releases/latest' } : null;
  return { version: VERSION, latest: lat || null, update };
}

async function handleApi(req, res, url) {
  const p = url.pathname;

  if (req.method === 'GET' && p === '/api/types') return json(res, 200, publicTypes());
  if (req.method === 'GET' && p === '/api/tasks') {
    const running = getTasks().filter((t) => t.status === 'running').length;
    return json(res, 200, { tasks: getTasks().slice().reverse(), running, capacity: capacity() });
  }
  if (req.method === 'POST' && p === '/api/uploads') {
    let body;
    try { body = JSON.parse(await readBody(req, 34e6)); } catch (e) { return json(res, 400, { error: e.message === 'body too large' ? '文件太大' : '无效的 JSON' }); }
    try { return json(res, 201, saveUpload(body)); } catch (e) { return json(res, 400, { error: e.message }); }
  }
  if (req.method === 'POST' && p === '/api/tasks') {
    let body;
    try { body = JSON.parse((await readBody(req, 4e6)) || '{}'); } catch (e) { return json(res, 400, { error: e.message === 'body too large' ? '内容过大，粘贴文本上限 20 万字' : '无效的 JSON' }); }
    try { return json(res, 201, createTask(body)); } catch (e) { return json(res, 400, { error: e.message }); }
  }

  if (req.method === 'GET' && p === '/api/env') return json(res, 200, envStatus());
  if (req.method === 'GET' && p === '/api/window-state') {
    try { return json(res, 200, JSON.parse(fs.readFileSync(WIN_STATE_FILE, 'utf8'))); } catch { return json(res, 200, {}); }
  }
  if (req.method === 'POST' && p === '/api/window-state') {
    let body;
    try { body = JSON.parse((await readBody(req, 2e4)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const n = (v) => Number.isFinite(v) && Math.abs(v) < 40000;
    if (typeof body.init_error === 'string') { // 前端重连壳失败的诊断信息(不影响使用,方便排查)。不能抹掉已存几何,否则窗口记忆丢坐标
      let prev = {};
      try { prev = JSON.parse(fs.readFileSync(WIN_STATE_FILE, 'utf8')); } catch { /* 没有就算了 */ }
      const geom = ['x', 'y', 'w', 'h'].filter((k) => n(prev[k])).reduce((a, k) => ({ ...a, [k]: prev[k] }), {});
      fs.mkdirSync(path.dirname(WIN_STATE_FILE), { recursive: true });
      fs.writeFileSync(WIN_STATE_FILE, JSON.stringify({ ...geom, init_error: body.init_error.slice(0, 300) }));
      return json(res, 200, { ok: true });
    }
    if (!(n(body.x) && n(body.y) && n(body.w) && n(body.h) && body.w >= 400 && body.h >= 300)) return json(res, 400, { error: '几何参数不对' });
    fs.mkdirSync(path.dirname(WIN_STATE_FILE), { recursive: true });
    fs.writeFileSync(WIN_STATE_FILE, JSON.stringify({ x: body.x, y: body.y, w: body.w, h: body.h }));
    return json(res, 200, { ok: true });
  }
  if (req.method === 'GET' && p === '/api/version') return json(res, 200, await checkUpdate(url.searchParams.get('fresh') === '1'));
  if (req.method === 'GET' && p === '/api/settings') {
    return json(res, 200, { parallel: parallelCap(), autostart: await autostartState(ROOT), setupSkip: fs.existsSync(SKIP_MARK) });
  }
  if (req.method === 'POST' && p === '/api/brand') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const u = String(body.url || '').trim();
    if (!/^https?:\/\/[^\s]+$/i.test(u)) return json(res, 400, { error: '请填 http(s) 开头的完整链接' });
    const script = path.join(SKILLS, 'kami', 'scripts', 'brand_extract.py');
    if (!fs.existsSync(script)) return json(res, 500, { error: '品牌提取工具不在（kami 技能没装好），先手动挑色' });
    const r = spawnSync(IS_WIN ? 'python' : 'python3', [script, u], { timeout: 60000, maxBuffer: 4 * 1024 * 1024, encoding: 'utf8' });
    if (r.error || r.status !== 0) return json(res, 502, { error: `没抓出品牌色：${String(r.stderr || r.error?.message || '站点不通或没写颜色').trim().slice(0, 120)}` });
    const raw = String(r.stdout || '');
    const seen = new Set();
    const colors = [...raw.matchAll(/#[0-9a-fA-F]{6}/g)].map((m) => m[0].toLowerCase())
      .filter((h) => {
        if (seen.has(h) || h === '#1b365d') return false; seen.add(h);
        const [rr, gg, bb] = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
        return Math.max(rr, gg, bb) - Math.min(rr, gg, bb) >= 30; // 灰黑白不算品牌色
      }).slice(0, 6);
    return json(res, 200, { colors, raw: raw.slice(0, 1200) });
  }
  if (req.method === 'POST' && p === '/api/settings') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const out = { ok: true };
    if (typeof body.pexelsKey === 'string') {
      const val = body.pexelsKey.trim();
      if (val && !/^[\w-]{10,120}$/.test(val)) return json(res, 400, { error: 'key 格式不对:Pexels 密钥是 10-120 位字母数字和连字符' });
      fs.mkdirSync(LAPIAN, { recursive: true });
      fs.writeFileSync(PEXELS_KEY, val ? val + '\n' : '');
      envCache.at = 0; // 下次 /api/env 重新读文件
      out.pexels = !!val;
    }
    if (body.parallel !== undefined) {
      const n = Number(body.parallel);
      if (!Number.isInteger(n) || n < 1 || n > 8) return json(res, 400, { error: '并发只能是 1-8 的整数' });
      writeConfig({ parallel: n });
      out.parallel = n;
    }
    if (body.autostart !== undefined) {
      try { out.autostart = await setAutostart(!!body.autostart, ROOT); }
      catch (e) { return json(res, 500, { error: '自启设置失败:' + e.message }); }
    }
    if (body.setupRemind === true) { // 装机"先不装"记号清除:下次打开应用重新弹体检
      try { fs.rmSync(SKIP_MARK, { force: true }); out.setupSkip = false; } catch { /* 本来就没 */ }
    }
    return json(res, 200, out);
  }
  if (req.method === 'POST' && p === '/api/skills/check') {
    try { return json(res, 200, await skillsCheck()); } catch (e) { return json(res, 502, { error: shortErr(e) }); }
  }
  if (req.method === 'POST' && p === '/api/skills/apply') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    try {
      const r = await skillsApply(String(body.name || ''), body.force === true);
      return json(res, r.error ? 422 : 200, r);
    } catch (e) { return json(res, 500, { error: shortErr(e) }); }
  }
  if (req.method === 'POST' && p === '/api/pexels-test') {
    // 验真：拿本机钥匙文件里的钥匙打一次 Pexels。密钥只在参数里流转，绝不进返回值/日志。
    let key = '';
    try { key = fs.readFileSync(PEXELS_KEY, 'utf8').trim(); } catch { /* 没文件 */ }
    if (!key) return json(res, 200, { ok: false, code: 0, error: 'no-key' });
    // Node fetch 不认系统代理，必须用 curl（走 engineEnv 的代理设置）
    const r = spawnSync('curl', ['-s', '-o', '/dev/null', '-w', '%{http_code}', '--max-time', '20',
      '-H', `Authorization: ${key}`, 'https://api.pexels.com/v1/search?query=hello&per_page=1'],
      { encoding: 'utf8', timeout: 30000, env: engineEnv() });
    const code = Number((r.stdout || '').trim()) || 0;
    if (r.error || code === 0) return json(res, 200, { ok: false, code: 0, error: 'net' });
    if (code === 200) return json(res, 200, { ok: true, code });
    if (code === 401 || code === 403) return json(res, 200, { ok: false, code, error: 'bad-key' });
    return json(res, 200, { ok: false, code, error: 'other' });
  }
  // ── 一键补依赖：失败卡上的入口（2026-11-09）。跑装机脚本(ZAOZHIJU_AUTO=1 免弹窗直接装)。脚本位置由 bootstrap 首启登记 ──
  if (req.method === 'POST' && p === '/api/setup/run') {
    let loc = '';
    try { loc = fs.readFileSync(path.join(os.homedir(), '.zaozhiju', 'setup.loc'), 'utf8').trim(); } catch { /* 老版没登记 */ }
    if (!loc || !fs.existsSync(loc)) return json(res, 200, { started: false });
    // 0.4.3:补依赖过程写日志+记 pid,设置页能看进度,不再全凭等
    const ZH = path.join(os.homedir(), '.zaozhiju');
    fs.mkdirSync(ZH, { recursive: true });
    let fd; try { fd = fs.openSync(path.join(ZH, 'setup-run.log'), 'a'); fs.writeSync(fd, `\n==== ${new Date().toISOString()} 一键补依赖开跑 ====\n`); } catch { /* 记不了进度也照跑 */ }
    const env = { ...engineEnv(), ZAOZHIJU_AUTO: '1' };
    const stdio = fd != null ? ['ignore', fd, fd] : 'ignore';
    const ch = IS_WIN
      ? spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', loc], { detached: true, stdio, env, windowsHide: true })
      : spawn('/bin/bash', [loc], { detached: true, stdio, env });
    if (fd != null) fs.closeSync(fd);
    if (ch.pid) { try { fs.writeFileSync(path.join(ZH, 'setup.pid'), String(ch.pid)); } catch {} }
    ch.unref();
    return json(res, 200, { started: true });
  }
  if (p === '/api/setup/status') {
    const ZH = path.join(os.homedir(), '.zaozhiju');
    let running = false;
    try { const pid = parseInt(fs.readFileSync(path.join(ZH, 'setup.pid'), 'utf8'), 10); if (pid > 0) { process.kill(pid, 0); running = true; } } catch { /* 没记号或已退 */ }
    const rd = (f, n) => { try { const b = fs.readFileSync(f); return b.subarray(Math.max(0, b.length - n)).toString('utf8'); } catch { return ''; } };
    // 进度行实际写在 bootstrap 自己的日志里(Mac: desktop-launch.log;Win: bootstrap.log 挨着脚本),横幅在 setup-run.log
    let slog = ''; try { slog = rd(path.join(path.dirname(fs.readFileSync(path.join(ZH, 'setup.loc'), 'utf8').trim()), 'bootstrap.log'), 1200); } catch { /* 没登记 */ }
    const parts = [rd(path.join(ZH, 'setup-run.log'), 600), rd(path.join(ZH, 'desktop-launch.log'), 2200), slog].filter(Boolean);
    let at = '';
    for (const f of [path.join(ZH, 'setup-run.log'), path.join(ZH, 'desktop-launch.log')]) { try { const m = fs.statSync(f).mtime.toISOString(); if (m > at) at = m; } catch {} }
    return json(res, 200, { running, hasRun: fs.existsSync(path.join(ZH, 'setup-run.log')), tail: parts.join('\n'), at });
  }
  // ── 选题模板：写过的长选题存下来，改个词一键再下单（2026-11-09）──
  if (p === '/api/templates' && req.method === 'GET') return json(res, 200, { templates: tplRead() });
  if (p === '/api/templates' && req.method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const topic = String(body.topic || '').trim();
    if (!topic) return json(res, 400, { error: '模板要有一段选题' });
    const name = (String(body.name || '').trim() || topic.slice(0, 12)).slice(0, 30);
    const all = tplRead();
    const sv = (v) => String(v ?? '').slice(0, 40); // 0.4.3:模板存全套设置（风格/色系/声音/画幅/时长/主色/要求/链接），一键复用整个配方
    const item = {
      id: String(body.id || 't' + Date.now().toString(36)), name, topic: topic.slice(0, 8000), typeId: String(body.typeId || ''), at: new Date().toISOString(),
      req: String(body.req || '').slice(0, 4000),
      links: (Array.isArray(body.links) ? body.links : []).map((x) => String(x).trim()).filter(Boolean).slice(0, 8),
      crawl: ['one', 'all'].includes(body.crawl) ? body.crawl : 'off',
      accent: /^#[0-9a-f]{6}$/i.test(String(body.accent || '')) ? String(body.accent).toLowerCase() : '',
      style: sv(body.style), theme: sv(body.theme), voice: sv(body.voice), aspect: sv(body.aspect), duration: sv(body.duration),
    };
    const i = all.findIndex((x) => x.id === item.id);
    if (i >= 0) all[i] = item; else { all.unshift(item); if (all.length > 60) all.length = 60; }
    tplWrite(all);
    return json(res, 200, { ok: true, templates: all });
  }
  if (p === '/api/templates/delete' && req.method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const all = tplRead().filter((x) => x.id !== String(body.id || ''));
    tplWrite(all);
    return json(res, 200, { ok: true, templates: all });
  }
  // ── 一键升级：公开 Pages 取新包→校验→换 App→自启（2026-11-09,双端）。没登记 App 位置的老版本走手动下载页 ──
  if (req.method === 'POST' && p === '/api/upgrade/start') {
    const ver = await checkUpdate(true);
    if (!ver.latest?.version) return json(res, 400, { error: '连不上更新源，稍后再试' });
    if (!ver.update) return json(res, 400, { error: '已经是最新版了' });
    const APPLOC = (() => { try { const s = fs.readFileSync(path.join(os.homedir(), '.zaozhiju', 'app.loc'), 'utf8').trim(); return fs.existsSync(s) ? s : ''; } catch { return ''; } })();
    if (!APPLOC) return json(res, 200, { started: false, manualUrl: 'https://young920.github.io/zaozhi-landing/#install' });
    const asset = `https://young920.github.io/zaozhi-landing/downloads/zaozhiju-${IS_WIN ? 'win' : 'mac'}.zip`;
    const nv = String(ver.update.version || ver.latest.version).replace(/[^0-9.]/g, '');
    fs.mkdirSync(UP, { recursive: true });
    fs.writeFileSync(path.join(UP, 'status.json'), JSON.stringify({ phase: 'downloading', target: nv }));
    if (IS_WIN) {
      const sc = path.join(UP, 'dl.ps1');
      fs.writeFileSync(sc, `$UP = '${UP}'\n$asset = '${asset}'\n$nv = '${nv}'\n$part = Join-Path $UP 'pkg.zip.part'\ntry {\n  Remove-Item -Force -EA SilentlyContinue $part\n  $j = Start-BitsTransfer -Source $asset -Destination $part -TransferType Download -Asynchronous\n  while ($true) {\n    $j = Get-BitsTransfer -JobId $j.JobId\n    $pct = if ($j.BytesTotal -gt 0) { [int](100 * $j.BytesTransferred / $j.BytesTotal) } else { 0 }\n    ('{"phase":"downloading","target":"'+$nv+'","pct":'+$pct+'}') | Set-Content (Join-Path $UP 'status.json') -Encoding ascii\n    if ($j.JobState -eq 'Transferred') { Complete-BitsTransfer -Job $j; break }\n    if ($j.JobState -notin 'Transferred','Connecting','Transferring') { throw ('BITS ' + $j.JobState) }\n    Start-Sleep 2\n  }\n  Move-Item -Force $part (Join-Path $UP 'pkg.zip')\n  ('{"phase":"ready","version":"'+$nv+'"}') | Set-Content (Join-Path $UP 'status.json') -Encoding ascii\n} catch {\n  '{\"phase\":\"error\",\"msg\":\"下载失败,网络不稳,稍后再点一次\"}' | Set-Content (Join-Path $UP 'status.json') -Encoding ascii\n  try { Get-BitsTransfer -EA SilentlyContinue | Where-Object { $_.JobId -eq $j.JobId } | Remove-BitsTransfer } catch {}\n}\n`);
      spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', sc], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    } else {
      const sc = path.join(UP, 'dl.sh');
      fs.writeFileSync(sc, `#!/bin/bash\nUP="${UP}"\nASSET="${asset}"\nNV="${nv}"\ntotal=$(curl -sIL --max-time 25 "$ASSET" | tr -d '\\r' | awk 'tolower($1) ~ /^content-length:/ {v=$2} END{print v+0}')\n[ "$total" -gt 0 ] 2>/dev/null || total=49600000\ncurl -fSL --retry 3 --max-time 1800 -o "$UP/pkg.zip.part" "$ASSET" &\ncp=$!\nwhile kill -0 $cp 2>/dev/null; do\n  cur=$(stat -f%z "$UP/pkg.zip.part" 2>/dev/null || echo 0)\n  printf '{"phase":"downloading","target":"%s","pct":%s}\\n' "$NV" "$(( cur * 100 / total ))" > "$UP/status.json"\n  sleep 2\ndone\nwait $cp; rc=$?\nif [ $rc -eq 0 ] && [ -s "$UP/pkg.zip.part" ]; then\n  mv -f "$UP/pkg.zip.part" "$UP/pkg.zip"\n  printf '{"phase":"ready","version":"%s"}\\n' "$NV" > "$UP/status.json"\nelse\n  rm -f "$UP/pkg.zip.part"\n  echo '{"phase":"error","msg":"下载失败,网络不稳,稍后再点一次"}' > "$UP/status.json"\nfi\n`);
      fs.chmodSync(sc, 0o755);
      spawn('/bin/bash', [sc], { detached: true, stdio: 'ignore' }).unref();
    }
    return json(res, 200, { started: true, target: nv });
  }
  if (p === '/api/upgrade/status') return json(res, 200, upStatus() || { phase: 'idle' });
  if (req.method === 'POST' && p === '/api/upgrade/apply') {
    const st = upStatus() || {};
    if (st.phase !== 'ready') return json(res, 400, { error: '新包还没下载好，稍等半分钟再点' });
    if (IS_WIN) {
      const sc = path.join(UP, 'apply.ps1');
      fs.writeFileSync(sc, `$UP = '${UP}'\n$APPLOC = (Get-Content (Join-Path $env:USERPROFILE '.zaozhiju\\app.loc') -ErrorAction SilentlyContinue)\nif (-not $APPLOC -or -not (Test-Path $APPLOC)) { Set-Content (Join-Path $UP 'status.json') '{\"phase\":\"error\",\"msg\":\"找不到原程序位置,请到下载页手动安装\"}'; exit 1 }\ntry { Get-Process | Where-Object { $_.Path -like (Join-Path $APPLOC '*') } | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}\n$svpid = (Get-Content (Join-Path $env:USERPROFILE '.zaozhiju\\server.pid') -ErrorAction SilentlyContinue)\nif ($svpid) { try { Stop-Process -Id ([int]$svpid) -Force -ErrorAction SilentlyContinue } catch {} }\nStart-Sleep 2\n$new = Join-Path $UP 'new'\nRemove-Item -Recurse -Force -ErrorAction SilentlyContinue $new\nExpand-Archive -Path (Join-Path $UP 'pkg.zip') -DestinationPath $new -Force\nrobocopy $new $APPLOC /E /XF bootstrap.log server.out.log server.err.log /NFL /NDL /NJH /NJS | Out-Null\nSet-Content (Join-Path $UP 'status.json') '{\"phase\":\"applied\"}'\nStart-Process -FilePath (Join-Path $APPLOC '造纸局.exe') -WorkingDirectory $APPLOC\n`);
      spawn('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', sc], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    } else {
      const sc = path.join(UP, 'apply.sh');
      fs.writeFileSync(sc, `#!/bin/bash\nUP="${UP}"\nAPPLOC="$(cat "$HOME/.zaozhiju/app.loc")"\nsleep 2\npid="$(cat "$HOME/.zaozhiju/server.pid" 2>/dev/null)"; [ -n "$pid" ] && ps -p "$pid" -o command= 2>/dev/null | grep -q 'server.mjs' && kill "$pid" 2>/dev/null\npkill -f 'node server/server.mjs' 2>/dev/null\npkill -f 'ZaozhiCore.app' 2>/dev/null\nrm -rf "$UP/new"; mkdir -p "$UP/new"\nunzip -qo "$UP/pkg.zip" -d "$UP/new"\nNEWAPP="$(find "$UP/new" -maxdepth 1 -name '造纸局.app' | head -1)"\nif [ -z "$NEWAPP" ]; then echo '{"phase":"error","msg":"包里没有造纸局.app"}' > "$UP/status.json"; exit 1; fi\nif [ -n "$APPLOC" ] && [ -d "$APPLOC" ]; then\n  rm -rf "$APPLOC"; cp -R "$NEWAPP" "$APPLOC"; xattr -dr com.apple.quarantine "$APPLOC" 2>/dev/null\n  echo '{"phase":"applied"}' > "$UP/status.json"\n  sleep 1; open "$APPLOC"\nelse\n  echo '{"phase":"error","msg":"找不到原 App 位置,请到下载页手动安装"}' > "$UP/status.json"\nfi\n`);
      fs.chmodSync(sc, 0o755);
      spawn('/bin/bash', [sc], { detached: true, stdio: 'ignore' }).unref();
    }
    return json(res, 200, { ok: true, note: '应用升级中：窗口会关掉再自动重开，是正常现象' });
  }
  if (req.method === 'GET' && p === '/api/diag') {
    const t = (f, n = 7000) => { try { const b = fs.readFileSync(f); return b.subarray(Math.max(0, b.length - n)).toString('utf8'); } catch { return '(没有)'; } };
    const env = envStatus(); const ver = await checkUpdate(false); const cfg = readConfig();
    const fails = getTasks().filter((x) => x.status === 'failed').slice(-6).reverse();
    const lines = [
      '造纸局诊断信息（发给助手用,不含任何钥匙内容）',
      `时间: ${new Date().toLocaleString()}`,
      `版本: v${ver.version}  最新: ${ver.latest?.version || '?'}  ${ver.update ? '有更新→' + ver.update.url : ''}`,
      `系统: ${process.platform}  Node: ${env.node}  运行: ${process.execPath}`,
      `代码目录: ${ROOT}`,
      `claude 引擎: ${env.claude ? '就绪' : '缺(出单会失败)'}  Pexels: ${env.pexels ? '已配' : '未配'}`,
      `Word/PPT 产线: pandoc ${env.deps?.pandoc ? '就绪' : '缺'}  python库 ${env.deps?.pyLibs ? '就绪' : '缺'}  目检软件 ${env.deps?.viewer ? '就绪' : '缺'}`,
      `并发: ${cfg.parallel || 2}  开机自启配置: ${cfg.autostart ? '开' : '关'}`,
      '', '── 最近失败任务 ──',
      ...(fails.length ? fails.map((x) => `[${x.finishedAt || ''}] ${x.typeId} ${x.topic || ''}: ${String(x.error || '').slice(0, 160)}`) : ['(没有失败记录)']),
      '', '── 装机/启动日志尾部(Mac) ──', t(path.join(os.homedir(), '.zaozhiju', 'desktop-launch.log')),
      '', '── 装机/启动日志尾部(Windows) ──', t(path.join(path.dirname(process.execPath), 'bootstrap.log')),
    ];
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent('造纸局诊断.txt')}` });
    return res.end(lines.join('\n'));
  }
  if (p === '/api/backup' && (req.method === 'GET' || req.method === 'POST')) {
    const b = backupAll(ROOT);
    if (b.error) return json(res, 400, { error: b.error });
    if (req.method === 'POST') return json(res, 200, { ok: true, name: saveToDownloadsZip(b.zip, b.name), count: b.count });
    res.writeHead(200, { 'content-type': 'application/zip', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(b.name)}`, 'content-length': b.zip.length });
    return res.end(b.zip);
  }
  if (req.method === 'POST' && p === '/api/system') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    if (body.action === 'open-url') {
      return openExternalUrl(String(body.url || '')) ? json(res, 200, { ok: true }) : json(res, 400, { error: '只允许打开 http(s) 链接' });
    }
    return json(res, 400, { error: 'action 只能是 open-url' });
  }

  const mf = p.match(/^\/api\/tasks\/([a-z0-9]+)\/view\/(.*)$/);
  if (mf) {
    const task = findTask(mf[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    const { dir } = taskPaths(task);
    const outDir = path.join(dir, 'output');
    let f = path.normalize(path.join(outDir, decodeURIComponent(mf[2]) || 'index.html'));
    if (f !== outDir && !f.startsWith(outDir + path.sep)) return json(res, 403, { error: 'forbidden' });
    return serveFile(res, f);
  }

  const ms = p.match(/^\/api\/tasks\/([a-z0-9]+)\/system$/);
  if (ms && req.method === 'POST') {
    const task = findTask(ms[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const { dir, kind } = taskPaths(task);
    const outDir = path.join(dir, 'output');
    if (body.mode === 'open') {
      const target = body.what === 'video' ? path.join(dir, 'output.mp4')
        : body.what === 'result' ? path.join(dir, 'result.txt')
        : body.what === 'qc' ? path.join(dir, 'qc.txt')
        : body.what === 'deliver' ? path.join(dir, 'deliver')
        : body.what === 'deckpdf' ? path.join(dir, kind === 'docx' ? 'output.pdf' : 'review.pdf')
        : body.what === 'output' ? path.join(dir, task.outputFile || 'output.pdf')
        : body.what === 'view' ? (fs.existsSync(path.join(outDir, 'index.html')) ? path.join(outDir, 'index.html') : outDir)
        : downloadArtifact(task, dir, kind).file;
      if (!target || !fs.existsSync(target)) return json(res, 404, { error: '文件还不存在' });
      openWithSystem(target);
      return json(res, 200, { ok: true });
    }
    if (body.mode === 'save') {
      if (task.status !== 'done') return json(res, 409, { error: '任务还没完成' });
      const a = downloadArtifact(task, dir, kind);
      if (a.error) return json(res, a.code || 404, { error: a.error });
      return json(res, 200, { ok: true, name: saveToDownloads(a.file, a.downloadName) });
    }
    return json(res, 400, { error: 'mode 只能是 open / save' });
  }

  const m = p.match(/^\/api\/tasks\/([a-z0-9]+)\/(cancel|retry|delete|output|preview|deckpdf|download|result|qc|video|cover)$/);
  if (m) {
    const task = findTask(m[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    const action = m[2];
    const { dir, kind } = taskPaths(task);
    if (action === 'cancel') return json(res, 200, cancelTask(task.id));
    if (action === 'retry') return json(res, 200, retryTask(task.id));
    if (action === 'delete') {
      const r = deleteTask(task.id);
      if (r.error) return json(res, r.code, { error: r.error });
      return json(res, 200, r);
    }
    if (action === 'result') return serveFile(res, path.join(dir, 'result.txt'));
    if (action === 'qc') return serveFile(res, path.join(dir, 'qc.txt')); // 质检单：文件在就有（旧任务没写过则 404，界面按 hasQc 决定是否显示入口）
    if (action === 'preview') return serveFile(res, path.join(dir, 'output', 'preview.png'));
    if (action === 'deckpdf') {
      if (kind === 'pptx') return serveFile(res, path.join(dir, 'review.pdf'), { req }); // PPT：放映软件导出的目检版
      if (kind === 'docx') return serveFile(res, path.join(dir, 'output.pdf'), { req }); // Word：排版对照 PDF
      return json(res, 400, { error: '这个任务没有 PDF 对照版' });
    }
    if (action === 'cover') return serveFile(res, path.join(dir, 'cover.png'), { req });
    if (action === 'video') {
      if (kind !== 'video') return json(res, 400, { error: '这个任务不是视频' });
      return serveFile(res, path.join(dir, 'output.mp4'), { req });
    }
    if (task.status !== 'done') return json(res, 409, { error: '任务还没完成' });
    if (action === 'output') return serveFile(res, path.join(dir, task.outputFile), { req });
    if (action === 'download') {
      const a = downloadArtifact(task, dir, kind);
      if (a.error) return json(res, a.code || 400, { error: a.error });
      return serveFile(res, a.file, { downloadName: a.downloadName });
    }
  }
  return json(res, 404, { error: 'not found' });
}

function serveStatic(res, url) {
  let file = path.normalize(path.join(DIST, url.pathname === '/' ? 'index.html' : url.pathname));
  if (!file.startsWith(DIST)) { res.writeHead(403); return res.end('forbidden'); }
  if (!fs.existsSync(file)) file = path.join(DIST, 'index.html'); // SPA fallback
  return serveFile(res, file);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (!fs.existsSync(path.join(DIST, 'index.html'))) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end('<h2>前端还没构建</h2><p>在项目目录运行 <code>npm run build</code> 后刷新</p>');
    }
    return serveStatic(res, url);
  } catch (err) {
    return json(res, 500, { error: err.message });
  }
});

boot();
server.listen(PORT, '127.0.0.1', () => {
  console.log(`造纸局已启动: http://127.0.0.1:${PORT}  (并发 ${capacity()})`);
});
