// Kami 工作台服务端：静态页面 + 任务 API（端口默认 8712）
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { zipSync } from 'fflate';
import { publicTypes } from './types.mjs';
import { IS_WIN, LAPIAN, PEXELS_KEY, SKILLS, PYBIN } from './paths.mjs';
import { getTasks, findTask, createTask, cancelTask, retryTask, deleteTask, saveUpload, taskPaths, typeById, boot, capacity, engineEnv } from './engine.mjs';
import { readConfig, writeConfig, parallelCap, setAutostart, autostartState } from './config.mjs';
import { backupAll, saveToDownloadsZip } from './backup.mjs';
import { skillsCheck, skillsApply } from './skills.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const DIST = path.join(ROOT, 'web', 'dist');
const PORT = Number(process.env.PORT || 8712);
const SKIP_MARK = path.join(os.homedir(), '.zaozhiju', 'skip-setup'); // 装机"先不装"记号,bootstrap 认它

const MIME = {
  '.html': 'text/html; charset=utf-8', '.pdf': 'application/pdf', '.png': 'image/png',
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8',
  '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.mp4': 'video/mp4',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

function json(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

const shortErr = (e) => String(e?.message || e || '未知错误').slice(0, 200);

function readBody(req, maxBytes = 1e6) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', (d) => { b += d; if (b.length > maxBytes) reject(new Error('body too large')); });
    req.on('end', () => resolve(b));
    req.on('error', reject);
  });
}

function serveFile(res, file, { downloadName, req } = {}) {
  if (!fs.existsSync(file)) return json(res, 404, { error: '文件不存在' });
  const ext = path.extname(file);
  const headers = { 'content-type': MIME[ext] ?? 'application/octet-stream', 'cache-control': 'no-store', 'accept-ranges': 'bytes' };
  if (downloadName) {
    headers['content-disposition'] = `attachment; filename*=UTF-8''${encodeURIComponent(downloadName)}`;
  }
  // 视频要能拖进度条：支持 HTTP Range 分段（浏览器 <video> 必需）
  const rm = req && req.headers.range && /^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
  if (rm && ext === '.mp4') {
    const size = fs.statSync(file).size;
    let start = rm[1] ? parseInt(rm[1], 10) : 0;
    let end = rm[2] ? parseInt(rm[2], 10) : size - 1;
    if (start >= size) {
      res.writeHead(416, { ...headers, 'content-range': `bytes */${size}` });
      return res.end();
    }
    end = Math.min(end, size - 1);
    res.writeHead(206, { ...headers, 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${size}` });
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  headers['content-length'] = fs.statSync(file).size;
  res.writeHead(200, headers);
  fs.createReadStream(file).pipe(res);
}

function fileSlug(task) {
  const type = typeById(task.typeId);
  const topic = (task.topic || '素材成品').slice(0, 24).replace(/[\/\\:*?"<>|]/g, '_');
  return `${topic}-${type?.label ?? task.typeId}`;
}

// 成品文件定位（download 端点与桌面客户端「存到下载文件夹」共用一套规则）
function downloadArtifact(task, dir, kind) {
  if (kind === 'pdf') return { file: path.join(dir, 'output.pdf'), downloadName: `${fileSlug(task)}.pdf` };
  if (kind === 'pptx') return { file: path.join(dir, 'output.pptx'), downloadName: `${fileSlug(task)}.pptx` };
  if (kind === 'docx') return { file: path.join(dir, 'output.docx'), downloadName: `${fileSlug(task)}.docx` };
  if (kind === 'video') return { file: path.join(dir, 'output.mp4'), downloadName: `${fileSlug(task)}.mp4` };
  if (task.typeId === 'flowart') return { file: path.join(dir, 'output', 'art.png'), downloadName: `${fileSlug(task)}.png` };
  if (['xhs', 'wxcover'].includes(typeById(task.typeId)?.out)) {
    const outDir = path.join(dir, 'output');
    const cards = fs.existsSync(outDir) ? fs.readdirSync(outDir).filter((f) => /^(card|cover)-[a-z0-9-]+\.png$/i.test(f)).sort() : [];
    if (!cards.length) return { error: '没找到成品 PNG', code: 404 };
    const zipPath = path.join(dir, 'xhs-cards.zip');
    // 纯 Node 打包（fflate），不再依赖系统 zip 命令——Windows 上没有
    const entries = {};
    for (const c of cards) entries[c] = fs.readFileSync(path.join(outDir, c));
    fs.writeFileSync(zipPath, Buffer.from(zipSync(entries, { level: 0 })));
    return { file: zipPath, downloadName: `${fileSlug(task)}.zip` };
  }
  return { error: '落地页是网页：用"打开页面"查看，文件在服务器 output/ 目录', code: 400 };
}

// 桌面客户端（webview 壳）里没有浏览器的下载器和新窗口，这些动作交给系统办
function openWithSystem(file) {
  spawn(IS_WIN ? 'explorer.exe' : 'open', [file], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}
function saveToDownloads(srcFile, downloadName) {
  const downDir = path.join(os.homedir(), 'Downloads');
  fs.mkdirSync(downDir, { recursive: true });
  const { name, ext } = path.parse(downloadName);
  let dest = path.join(downDir, downloadName);
  let n = 2;
  while (fs.existsSync(dest)) dest = path.join(downDir, `${name} (${n++})${ext}`);
  fs.copyFileSync(srcFile, dest);
  return path.basename(dest);
}
// 桌面壳里点外部链接：target=_blank 是死的,交给系统浏览器
function openExternalUrl(url) {
  if (!/^https?:\/\//i.test(url)) return false;
  spawn(IS_WIN ? 'explorer.exe' : 'open', [url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
  return true;
}

// ── 环境体检 + 设置 + 版本更新（界面「设置」页与首启指引用）──
const WIN_STATE_FILE = path.join(os.homedir(), '.zaozhiju', 'window.json'); // 桌面壳窗口大小/位置记忆
const VERSION = (() => { try { return fs.readFileSync(path.join(ROOT, 'VERSION'), 'utf8').trim(); } catch { return '0.0.0'; } })();
const UPDATE_URL = 'https://young920.github.io/zaozhi-landing/latest.json'; // 公开落地页仓的更新清单（私有仓拿不到 Release）
let envCache = { at: 0, data: null };
let updateCache = { at: 0, data: null };

function hasCmd(name, env) {
  try { return spawnSync(name, ['--version'], { stdio: 'ignore', timeout: 15000, shell: IS_WIN, env }) .status === 0; } catch { return false; }
}
// Word/PPT 产线依赖体检（2026-11-08）：pandoc(Word 转换)、python 库(pptx/docx)、放映软件(PPT 目检)——缺哪项设置页亮哪项
function pyOk(mod) {
  try { return spawnSync(IS_WIN ? 'python' : PYBIN, ['-c', `import ${mod}`], { timeout: 15000, stdio: 'ignore' }).status === 0; } catch { return false; }
}
function workbenchDeps() {
  let keynote = null;
  try { keynote = fs.existsSync('/Applications/Keynote.app') || hasCmd('soffice', engineEnv()); } catch { /* win 分支另行 */ }
  if (IS_WIN) {
    try { keynote = fs.existsSync('C:\\Program Files\\LibreOffice\\program\\soffice.exe') || hasCmd('soffice', engineEnv()); } catch { keynote = null; }
  }
  return { pandoc: hasCmd('pandoc', engineEnv()), pyLibs: pyOk('pptx') && pyOk('docx'), viewer: keynote };
}
function envStatus() {
  if (envCache.data && Date.now() - envCache.at < 60e3) return envCache.data;
  let pexels = false;
  try { pexels = !!fs.readFileSync(PEXELS_KEY, 'utf8').trim(); } catch { /* 没文件=没配 */ }
  let deps = null;
  try { deps = workbenchDeps(); } catch { /* 体检失败不拦主状态 */ }
  envCache = { at: Date.now(), data: { node: process.version, claude: hasCmd('claude'), pexels, deps } };
  return envCache.data;
}
const vparts = (v) => String(v).split('.').map((n) => parseInt(n, 10) || 0);
const verGt = (a, b) => { const x = vparts(a), y = vparts(b); for (let i = 0; i < 3; i++) { if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0); } return false; };
async function checkUpdate(force) {
  if (force || !updateCache.data || Date.now() - updateCache.at > 864e5) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 6000);
      const r = await fetch(UPDATE_URL, { signal: ctrl.signal });
      clearTimeout(to);
      if (r.ok) updateCache = { at: Date.now(), data: await r.json() };
    } catch { updateCache = { ...updateCache, at: Date.now() }; } // 断网不算错,下次再查
  }
  const lat = updateCache.data;
  const update = lat && lat.version && verGt(lat.version, VERSION)
    ? { version: lat.version, notes: lat.notes || '', url: lat.url || 'https://github.com/young920/kami/releases/latest' } : null;
  return { version: VERSION, latest: lat || null, update };
}

async function handleApi(req, res, url) {
  const p = url.pathname;

  if (req.method === 'GET' && p === '/api/types') return json(res, 200, publicTypes());
  if (req.method === 'GET' && p === '/api/tasks') {
    const running = getTasks().filter((t) => t.status === 'running').length;
    return json(res, 200, { tasks: getTasks().slice().reverse(), running, capacity: capacity() });
  }
  if (req.method === 'POST' && p === '/api/uploads') {
    let body;
    try { body = JSON.parse(await readBody(req, 34e6)); } catch (e) { return json(res, 400, { error: e.message === 'body too large' ? '文件太大' : '无效的 JSON' }); }
    try { return json(res, 201, saveUpload(body)); } catch (e) { return json(res, 400, { error: e.message }); }
  }
  if (req.method === 'POST' && p === '/api/tasks') {
    let body;
    try { body = JSON.parse((await readBody(req, 4e6)) || '{}'); } catch (e) { return json(res, 400, { error: e.message === 'body too large' ? '内容过大，粘贴文本上限 20 万字' : '无效的 JSON' }); }
    try { return json(res, 201, createTask(body)); } catch (e) { return json(res, 400, { error: e.message }); }
  }

  if (req.method === 'GET' && p === '/api/env') return json(res, 200, envStatus());
  if (req.method === 'GET' && p === '/api/window-state') {
    try { return json(res, 200, JSON.parse(fs.readFileSync(WIN_STATE_FILE, 'utf8'))); } catch { return json(res, 200, {}); }
  }
  if (req.method === 'POST' && p === '/api/window-state') {
    let body;
    try { body = JSON.parse((await readBody(req, 2e4)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const n = (v) => Number.isFinite(v) && Math.abs(v) < 40000;
    if (typeof body.init_error === 'string') { // 前端重连壳失败的诊断信息(不影响使用,方便排查)。不能抹掉已存几何,否则窗口记忆丢坐标
      let prev = {};
      try { prev = JSON.parse(fs.readFileSync(WIN_STATE_FILE, 'utf8')); } catch { /* 没有就算了 */ }
      const geom = ['x', 'y', 'w', 'h'].filter((k) => n(prev[k])).reduce((a, k) => ({ ...a, [k]: prev[k] }), {});
      fs.mkdirSync(path.dirname(WIN_STATE_FILE), { recursive: true });
      fs.writeFileSync(WIN_STATE_FILE, JSON.stringify({ ...geom, init_error: body.init_error.slice(0, 300) }));
      return json(res, 200, { ok: true });
    }
    if (!(n(body.x) && n(body.y) && n(body.w) && n(body.h) && body.w >= 400 && body.h >= 300)) return json(res, 400, { error: '几何参数不对' });
    fs.mkdirSync(path.dirname(WIN_STATE_FILE), { recursive: true });
    fs.writeFileSync(WIN_STATE_FILE, JSON.stringify({ x: body.x, y: body.y, w: body.w, h: body.h }));
    return json(res, 200, { ok: true });
  }
  if (req.method === 'GET' && p === '/api/version') return json(res, 200, await checkUpdate(url.searchParams.get('fresh') === '1'));
  if (req.method === 'GET' && p === '/api/settings') {
    return json(res, 200, { parallel: parallelCap(), autostart: await autostartState(ROOT), setupSkip: fs.existsSync(SKIP_MARK) });
  }
  if (req.method === 'POST' && p === '/api/brand') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const u = String(body.url || '').trim();
    if (!/^https?:\/\/[^\s]+$/i.test(u)) return json(res, 400, { error: '请填 http(s) 开头的完整链接' });
    const script = path.join(SKILLS, 'kami', 'scripts', 'brand_extract.py');
    if (!fs.existsSync(script)) return json(res, 500, { error: '品牌提取工具不在（kami 技能没装好），先手动挑色' });
    const r = spawnSync(IS_WIN ? 'python' : 'python3', [script, u], { timeout: 60000, maxBuffer: 4 * 1024 * 1024, encoding: 'utf8' });
    if (r.error || r.status !== 0) return json(res, 502, { error: `没抓出品牌色：${String(r.stderr || r.error?.message || '站点不通或没写颜色').trim().slice(0, 120)}` });
    const raw = String(r.stdout || '');
    const seen = new Set();
    const colors = [...raw.matchAll(/#[0-9a-fA-F]{6}/g)].map((m) => m[0].toLowerCase())
      .filter((h) => {
        if (seen.has(h) || h === '#1b365d') return false; seen.add(h);
        const [rr, gg, bb] = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
        return Math.max(rr, gg, bb) - Math.min(rr, gg, bb) >= 30; // 灰黑白不算品牌色
      }).slice(0, 6);
    return json(res, 200, { colors, raw: raw.slice(0, 1200) });
  }
  if (req.method === 'POST' && p === '/api/settings') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const out = { ok: true };
    if (typeof body.pexelsKey === 'string') {
      const val = body.pexelsKey.trim();
      if (val && !/^[\w-]{10,120}$/.test(val)) return json(res, 400, { error: 'key 格式不对:Pexels 密钥是 10-120 位字母数字和连字符' });
      fs.mkdirSync(LAPIAN, { recursive: true });
      fs.writeFileSync(PEXELS_KEY, val ? val + '\n' : '');
      envCache.at = 0; // 下次 /api/env 重新读文件
      out.pexels = !!val;
    }
    if (body.parallel !== undefined) {
      const n = Number(body.parallel);
      if (!Number.isInteger(n) || n < 1 || n > 8) return json(res, 400, { error: '并发只能是 1-8 的整数' });
      writeConfig({ parallel: n });
      out.parallel = n;
    }
    if (body.autostart !== undefined) {
      try { out.autostart = await setAutostart(!!body.autostart, ROOT); }
      catch (e) { return json(res, 500, { error: '自启设置失败:' + e.message }); }
    }
    if (body.setupRemind === true) { // 装机"先不装"记号清除:下次打开应用重新弹体检
      try { fs.rmSync(SKIP_MARK, { force: true }); out.setupSkip = false; } catch { /* 本来就没 */ }
    }
    return json(res, 200, out);
  }
  if (req.method === 'POST' && p === '/api/skills/check') {
    try { return json(res, 200, await skillsCheck()); } catch (e) { return json(res, 502, { error: shortErr(e) }); }
  }
  if (req.method === 'POST' && p === '/api/skills/apply') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    try {
      const r = await skillsApply(String(body.name || ''), body.force === true);
      return json(res, r.error ? 422 : 200, r);
    } catch (e) { return json(res, 500, { error: shortErr(e) }); }
  }
  if (req.method === 'POST' && p === '/api/pexels-test') {
    // 验真：拿本机钥匙文件里的钥匙打一次 Pexels。密钥只在参数里流转，绝不进返回值/日志。
    let key = '';
    try { key = fs.readFileSync(PEXELS_KEY, 'utf8').trim(); } catch { /* 没文件 */ }
    if (!key) return json(res, 200, { ok: false, code: 0, error: 'no-key' });
    // Node fetch 不认系统代理，必须用 curl（走 engineEnv 的代理设置）
    const r = spawnSync('curl', ['-s', '-o', '/dev/null', '-w', '%{http_code}', '--max-time', '20',
      '-H', `Authorization: ${key}`, 'https://api.pexels.com/v1/search?query=hello&per_page=1'],
      { encoding: 'utf8', timeout: 30000, env: engineEnv() });
    const code = Number((r.stdout || '').trim()) || 0;
    if (r.error || code === 0) return json(res, 200, { ok: false, code: 0, error: 'net' });
    if (code === 200) return json(res, 200, { ok: true, code });
    if (code === 401 || code === 403) return json(res, 200, { ok: false, code, error: 'bad-key' });
    return json(res, 200, { ok: false, code, error: 'other' });
  }
  if (req.method === 'GET' && p === '/api/diag') {
    const t = (f, n = 7000) => { try { const b = fs.readFileSync(f); return b.subarray(Math.max(0, b.length - n)).toString('utf8'); } catch { return '(没有)'; } };
    const env = envStatus(); const ver = await checkUpdate(false); const cfg = readConfig();
    const fails = getTasks().filter((x) => x.status === 'failed').slice(-6).reverse();
    const lines = [
      '造纸局诊断信息（发给助手用,不含任何钥匙内容）',
      `时间: ${new Date().toLocaleString()}`,
      `版本: v${ver.version}  最新: ${ver.latest?.version || '?'}  ${ver.update ? '有更新→' + ver.update.url : ''}`,
      `系统: ${process.platform}  Node: ${env.node}  运行: ${process.execPath}`,
      `代码目录: ${ROOT}`,
      `claude 引擎: ${env.claude ? '就绪' : '缺(出单会失败)'}  Pexels: ${env.pexels ? '已配' : '未配'}`,
      `Word/PPT 产线: pandoc ${env.deps?.pandoc ? '就绪' : '缺'}  python库 ${env.deps?.pyLibs ? '就绪' : '缺'}  目检软件 ${env.deps?.viewer ? '就绪' : '缺'}`,
      `并发: ${cfg.parallel || 2}  开机自启配置: ${cfg.autostart ? '开' : '关'}`,
      '', '── 最近失败任务 ──',
      ...(fails.length ? fails.map((x) => `[${x.finishedAt || ''}] ${x.typeId} ${x.topic || ''}: ${String(x.error || '').slice(0, 160)}`) : ['(没有失败记录)']),
      '', '── 装机/启动日志尾部(Mac) ──', t(path.join(os.homedir(), '.zaozhiju', 'desktop-launch.log')),
      '', '── 装机/启动日志尾部(Windows) ──', t(path.join(path.dirname(process.execPath), 'bootstrap.log')),
    ];
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent('造纸局诊断.txt')}` });
    return res.end(lines.join('\n'));
  }
  if (p === '/api/backup' && (req.method === 'GET' || req.method === 'POST')) {
    const b = backupAll(ROOT);
    if (b.error) return json(res, 400, { error: b.error });
    if (req.method === 'POST') return json(res, 200, { ok: true, name: saveToDownloadsZip(b.zip, b.name), count: b.count });
    res.writeHead(200, { 'content-type': 'application/zip', 'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(b.name)}`, 'content-length': b.zip.length });
    return res.end(b.zip);
  }
  if (req.method === 'POST' && p === '/api/system') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    if (body.action === 'open-url') {
      return openExternalUrl(String(body.url || '')) ? json(res, 200, { ok: true }) : json(res, 400, { error: '只允许打开 http(s) 链接' });
    }
    return json(res, 400, { error: 'action 只能是 open-url' });
  }

  const mf = p.match(/^\/api\/tasks\/([a-z0-9]+)\/view\/(.*)$/);
  if (mf) {
    const task = findTask(mf[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    const { dir } = taskPaths(task);
    const outDir = path.join(dir, 'output');
    let f = path.normalize(path.join(outDir, decodeURIComponent(mf[2]) || 'index.html'));
    if (f !== outDir && !f.startsWith(outDir + path.sep)) return json(res, 403, { error: 'forbidden' });
    return serveFile(res, f);
  }

  const ms = p.match(/^\/api\/tasks\/([a-z0-9]+)\/system$/);
  if (ms && req.method === 'POST') {
    const task = findTask(ms[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); } catch { return json(res, 400, { error: '无效的 JSON' }); }
    const { dir, kind } = taskPaths(task);
    const outDir = path.join(dir, 'output');
    if (body.mode === 'open') {
      const target = body.what === 'video' ? path.join(dir, 'output.mp4')
        : body.what === 'result' ? path.join(dir, 'result.txt')
        : body.what === 'qc' ? path.join(dir, 'qc.txt')
        : body.what === 'deliver' ? path.join(dir, 'deliver')
        : body.what === 'deckpdf' ? path.join(dir, kind === 'docx' ? 'output.pdf' : 'review.pdf')
        : body.what === 'output' ? path.join(dir, task.outputFile || 'output.pdf')
        : body.what === 'view' ? (fs.existsSync(path.join(outDir, 'index.html')) ? path.join(outDir, 'index.html') : outDir)
        : downloadArtifact(task, dir, kind).file;
      if (!target || !fs.existsSync(target)) return json(res, 404, { error: '文件还不存在' });
      openWithSystem(target);
      return json(res, 200, { ok: true });
    }
    if (body.mode === 'save') {
      if (task.status !== 'done') return json(res, 409, { error: '任务还没完成' });
      const a = downloadArtifact(task, dir, kind);
      if (a.error) return json(res, a.code || 404, { error: a.error });
      return json(res, 200, { ok: true, name: saveToDownloads(a.file, a.downloadName) });
    }
    return json(res, 400, { error: 'mode 只能是 open / save' });
  }

  const m = p.match(/^\/api\/tasks\/([a-z0-9]+)\/(cancel|retry|delete|output|preview|deckpdf|download|result|qc|video|cover)$/);
  if (m) {
    const task = findTask(m[1]);
    if (!task) return json(res, 404, { error: '任务不存在' });
    const action = m[2];
    const { dir, kind } = taskPaths(task);
    if (action === 'cancel') return json(res, 200, cancelTask(task.id));
    if (action === 'retry') return json(res, 200, retryTask(task.id));
    if (action === 'delete') {
      const r = deleteTask(task.id);
      if (r.error) return json(res, r.code, { error: r.error });
      return json(res, 200, r);
    }
    if (action === 'result') return serveFile(res, path.join(dir, 'result.txt'));
    if (action === 'qc') return serveFile(res, path.join(dir, 'qc.txt')); // 质检单：文件在就有（旧任务没写过则 404，界面按 hasQc 决定是否显示入口）
    if (action === 'preview') return serveFile(res, path.join(dir, 'output', 'preview.png'));
    if (action === 'deckpdf') {
      if (kind === 'pptx') return serveFile(res, path.join(dir, 'review.pdf'), { req }); // PPT：放映软件导出的目检版
      if (kind === 'docx') return serveFile(res, path.join(dir, 'output.pdf'), { req }); // Word：排版对照 PDF
      return json(res, 400, { error: '这个任务没有 PDF 对照版' });
    }
    if (action === 'cover') return serveFile(res, path.join(dir, 'cover.png'), { req });
    if (action === 'video') {
      if (kind !== 'video') return json(res, 400, { error: '这个任务不是视频' });
      return serveFile(res, path.join(dir, 'output.mp4'), { req });
    }
    if (task.status !== 'done') return json(res, 409, { error: '任务还没完成' });
    if (action === 'output') return serveFile(res, path.join(dir, task.outputFile), { req });
    if (action === 'download') {
      const a = downloadArtifact(task, dir, kind);
      if (a.error) return json(res, a.code || 400, { error: a.error });
      return serveFile(res, a.file, { downloadName: a.downloadName });
    }
  }
  return json(res, 404, { error: 'not found' });
}

function serveStatic(res, url) {
  let file = path.normalize(path.join(DIST, url.pathname === '/' ? 'index.html' : url.pathname));
  if (!file.startsWith(DIST)) { res.writeHead(403); return res.end('forbidden'); }
  if (!fs.existsSync(file)) file = path.join(DIST, 'index.html'); // SPA fallback
  return serveFile(res, file);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  try {
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (!fs.existsSync(path.join(DIST, 'index.html'))) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end('<h2>前端还没构建</h2><p>在项目目录运行 <code>npm run build</code> 后刷新</p>');
    }
    return serveStatic(res, url);
  } catch (err) {
    return json(res, 500, { error: err.message });
  }
});

boot();
server.listen(PORT, '127.0.0.1', () => {
  console.log(`造纸局已启动: http://127.0.0.1:${PORT}  (并发 ${capacity()})`);
});
