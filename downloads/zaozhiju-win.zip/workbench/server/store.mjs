import fs from 'node:fs';
import path from 'node:path';

const DATA = path.resolve(import.meta.dirname, '..', 'data');
const FILE = path.join(DATA, 'tasks.json');

export function loadTasks() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return [];
  }
}

let timer = null;
export function saveTasks(tasks) {
  clearTimeout(timer);
  timer = setTimeout(() => flushTasks(tasks), 300);
}

export function flushTasks(tasks) {
  clearTimeout(timer);
  timer = null;
  fs.mkdirSync(DATA, { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(tasks, null, 1));
  fs.renameSync(tmp, FILE);
}
