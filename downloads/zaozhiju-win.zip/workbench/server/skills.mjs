// 技能更新跟进（2026-11-08 杨拍板第 3 条）：设置页一键"检查技能更新→验收→备份→换装"。
// 三个技能的上游：kami=tw93/Kami(GitHub Release)；guizang=op7418/guizang-social-card-skill(主干提交)；
// sweety=自制技能，仓库即主源，无外部上游。换装前先跑"零件自检"（关键文件在、脚本加载得动），
// 过不了就不碰本机；换之前旧版整目录备份到 data/skill-backups/，随时可手动回滚。
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { engineEnv } from './engine.mjs';
import { IS_WIN } from './paths.mjs';

const run = promisify(execFile);
const ROOT = path.resolve(import.meta.dirname, '..');
const SRC = path.join(ROOT, 'skills');                                   // 仓库/载荷主源（分发包构建从这里取）
const LIVE = path.join(os.homedir(), '.claude', 'skills');               // 引擎实际读取处
const LEDGER = path.join(os.homedir(), '.zaozhiju', 'skills-sync.json'); // 本机同步基线
const UP_DIR = path.join(ROOT, 'data', 'skill-updates');
const BK_DIR = path.join(ROOT, 'data', 'skill-backups');

export const SKILL_SPECS = [
  { name: 'kami', label: '排版技能 kami', repo: 'tw93/Kami', mode: 'release' },
  { name: 'guizang-social-card-skill', label: '社交卡技能 guizang', repo: 'op7418/guizang-social-card-skill', mode: 'commit' },
  { name: 'sweety-statechart-video', label: '蜡笔视频技能 sweety', repo: null, mode: 'own' },
];

function readLedger() { try { return JSON.parse(fs.readFileSync(LEDGER, 'utf8')); } catch { return {}; } }
function writeLedger(l) {
  try { fs.mkdirSync(path.dirname(LEDGER), { recursive: true }); fs.writeFileSync(LEDGER, JSON.stringify(l, null, 2)); } catch { /* 记不上就算了,下次重新问 */ }
}
const short = (e) => String(e?.message || e || '').slice(0, 140);
async function curlJson(url) {
  const { stdout } = await run('curl', ['-fsSL', '--max-time', '12', url], { env: engineEnv(), maxBuffer: 4e6 });
  return JSON.parse(stdout);
}
const vparse = (v) => String(v || '').replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
const verGt = (a, b) => { const x = vparse(a), y = vparse(b); for (let i = 0; i < 3; i++) { if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0); } return false; };
const localVersion = (name) => { try { return fs.readFileSync(path.join(SRC, name, 'VERSION'), 'utf8').trim(); } catch { return null; } };

async function checkOne(sp) {
  const base = { name: sp.name, label: sp.label, current: localVersion(sp.name) };
  if (sp.mode === 'own') return { ...base, status: 'own', note: '自制技能，仓库就是主源，没有外部上游' };
  const rec = readLedger()[sp.name] || null;
  try {
    if (sp.mode === 'release') {
      const rel = await curlJson(`https://api.github.com/repos/${sp.repo}/releases/latest`);
      const tag = String(rel.tag_name || '').replace(/^v/i, '');
      if (!tag) throw new Error('上游没给出版本号');
      return { ...base, latest: tag, date: rel.published_at, url: rel.html_url || '', status: verGt(tag, base.current || '0.0.0') ? 'new' : 'latest' };
    }
    const repo = await curlJson(`https://api.github.com/repos/${sp.repo}`);
    const br = repo.default_branch || 'main';
    const c = await curlJson(`https://api.github.com/repos/${sp.repo}/commits/${encodeURIComponent(br)}`);
    const sha = String(c.sha || '');
    const date = c.commit?.committer?.date || c.commit?.author?.date;
    if (!sha) throw new Error('上游没给出提交号');
    if (!rec?.sha) return { ...base, latest: sha.slice(0, 7), date, status: 'unknown', note: '还没记同步基线。点「同步」会拉官方最新版,先对比再换：本机没改过的直接换,改过的会先问一声' };
    return { ...base, synced: rec.sha.slice(0, 7), latest: sha.slice(0, 7), date, status: rec.sha === sha ? 'latest' : 'new' };
  } catch (e) {
    return { ...base, status: 'error', note: '连不上更新源：' + short(e) };
  }
}

export async function skillsCheck() {
  const skills = await Promise.all(SKILL_SPECS.map(checkOne));
  return { skills, at: new Date().toISOString() };
}

// 换装前的"零件自检"：文件必须在，脚本必须加载得动——过不了就不碰本机
async function findSkillRoot(dir, depth) { // 官方包结构自适应：根目录或 skills/<name>/ 里的 SKILL.md 都认
  if (fs.existsSync(path.join(dir, 'SKILL.md'))) return dir;
  if (depth <= 0) return null;
  let dirs = [];
  try { dirs = fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory() && !d.name.startsWith('.')).map((d) => path.join(dir, d.name)); } catch { return null; }
  for (const d of dirs) { const r = await findSkillRoot(d, depth - 1); if (r) return r; }
  return null;
}
const GATE_FILES = {
  kami: ['SKILL.md', 'scripts/build.py', 'scripts/render.py', 'assets/templates/slides.py'],
  'guizang-social-card-skill': ['SKILL.md', 'validate-social-deck.mjs', 'package.json', 'assets'],
};
async function gate(sp, dir) {
  for (const f of GATE_FILES[sp.name] || []) {
    if (!fs.existsSync(path.join(dir, f))) return `缺 ${f}`;
  }
  if (sp.name === 'kami') {
    try { await run(IS_WIN ? 'python' : 'python3', ['-c', 'import sys; sys.path.insert(0,"scripts"); import build'], { cwd: dir, timeout: 45000, env: process.env }); }
    catch { return 'kami 核心脚本加载失败（缺依赖或语法不合本机）'; }
  } else {
    try { await run('node', ['--check', 'validate-social-deck.mjs'], { cwd: dir, timeout: 30000 }); }
    catch { return 'validate 脚本语法不通'; }
  }
  return null;
}

async function copyInto(srcRoot, dstRoot) { // 合并式复制：只覆盖官方包里有的文件，本机独有的(node_modules 等)不动
  let added = 0, changed = 0, same = 0;
  const walk = (dir, rel = '') => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name === '.git' || e.name === 'node_modules' || e.name === '__pycache__') continue;
      const s = path.join(dir, e.name), r = path.posix.join(rel, e.name);
      if (e.isDirectory()) { walk(s, r); continue; }
      if (!e.isFile()) continue;
      const d = path.join(dstRoot, r);
      let verdict;
      try {
        const [a, b] = [fs.readFileSync(s), fs.existsSync(d) ? fs.readFileSync(d) : null];
        verdict = !b ? 'added' : a.equals(b) ? 'same' : 'changed';
      } catch { verdict = 'added'; }
      if (verdict !== 'same') {
        fs.mkdirSync(path.dirname(d), { recursive: true });
        fs.copyFileSync(s, d);
        try { fs.chmodSync(d, fs.statSync(s).mode & 0o777); } catch { /* 权限照搬失败不拦 */ }
      }
      if (verdict === 'added') added++; else if (verdict === 'changed') changed++; else same++;
    }
  };
  walk(srcRoot);
  return { added, changed, same };
}

export async function skillsApply(name, force = false) {
  const sp = SKILL_SPECS.find((x) => x.name === name);
  if (!sp) return { error: '不认识这个技能' };
  if (!sp.repo) return { error: '这是自制技能，没有公开上游可拉' };

  // 1) 定官方包地址
  let tarUrl, ref;
  if (sp.mode === 'release') {
    const rel = await curlJson(`https://api.github.com/repos/${sp.repo}/releases/latest`);
    tarUrl = rel.tarball_url; ref = String(rel.tag_name || '').replace(/^v/i, '');
    if (!tarUrl || !ref) return { error: '没拿到官方发布包地址' };
  } else {
    const repo = await curlJson(`https://api.github.com/repos/${sp.repo}`);
    const br = repo.default_branch || 'main';
    const c = await curlJson(`https://api.github.com/repos/${sp.repo}/commits/${encodeURIComponent(br)}`);
    ref = String(c.sha || '');
    if (!ref) return { error: '没拿到官方最新提交号' };
    tarUrl = `https://codeload.github.com/${sp.repo}/tar.gz/refs/heads/${br}`;
  }

  // 2) 下载解包到暂存区（不碰本机技能）
  const ts = Date.now().toString(36);
  const work = path.join(UP_DIR, `${name}-${ts}`);
  fs.mkdirSync(work, { recursive: true });
  const tgz = work + '.tar.gz';
  let skillDir;
  try {
    await run('curl', ['-fsSL', '--max-time', '180', '-o', tgz, tarUrl], { env: engineEnv(), maxBuffer: 2e6 });
    await run('tar', ['-xzf', tgz, '-C', work], { timeout: 60000 });
    fs.rmSync(tgz, { force: true });
    const tops = fs.readdirSync(work, { withFileTypes: true }).filter((d) => d.isDirectory());
    if (tops.length !== 1) return { error: '官方包结构看不懂（顶层不是单一目录），本机技能未动' };
    // 官方包有的直接是技能目录,有的是整个仓库(技能藏在 skills/<name>/)——按 SKILL.md 找真身,最多下探两层
    skillDir = await findSkillRoot(path.join(work, tops[0].name), 2);
    if (!skillDir) return { error: '官方包里没找到技能本体（没有 SKILL.md），本机技能未动' };
  } catch (e) {
    return { error: '下载解包失败：' + short(e) + '（本机技能未动）' };
  }

  // 3) 验收
  const gateErr = await gate(sp, skillDir);
  if (gateErr) {
    try { fs.rmSync(work, { recursive: true, force: true }); } catch { /* 留着也能排查 */ }
    return { error: `官方新包验收没过：${gateErr}，本机技能未动` };
  }

  // 3.5) 本地改动护栏：官方包与本机都有、内容不同的文件会被官方覆盖——先数出来问一声
  const localRoot = path.join(SRC, name);
  const covered = [];
  const walkDiv = (dir, rel = '') => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name === '.git' || e.name === 'node_modules' || e.name === '__pycache__') continue;
      const s = path.join(dir, e.name), r = path.posix.join(rel, e.name);
      if (e.isDirectory()) { walkDiv(s, r); continue; }
      if (!e.isFile()) continue;
      const d = path.join(localRoot, r);
      if (!fs.existsSync(d)) continue; // 官方新增文件不算覆盖本机改动
      try { if (!fs.readFileSync(s).equals(fs.readFileSync(d))) covered.push(r); } catch { covered.push(r); }
    }
  };
  try { walkDiv(skillDir); } catch { /* 数不动就当有改动,走确认 */ covered.push('(无法比对)'); }
  if (covered.length && !force) {
    return { needConfirm: true, overwrite: covered.length, sample: covered.slice(0, 8), hint: `官方包会覆盖本机改过的 ${covered.length} 个文件(如 ${covered.slice(0, 3).join('、')})。这台机器可能用的是定制版技能,覆盖后出卡/出文档的风格会变。拿不准就别换;要换再点一次(换前自动留备份)` };
  }

  // 4) 备份 → 5) 换装（仓库主源 + 引擎读取处一起）
  const bkp = path.join(BK_DIR, `${name}-${ts}`);
  try {
    fs.cpSync(path.join(SRC, name), bkp, { recursive: true, filter: (s) => !/(node_modules|__pycache__)/.test(s) });
  } catch (e) { return { error: '备份失败，本机技能未动：' + short(e) }; }
  const a = await copyInto(skillDir, path.join(SRC, name));
  await copyInto(skillDir, path.join(LIVE, name));

  // 6) 记基线、清暂存
  const l = readLedger();
  l[name] = sp.mode === 'release' ? { tag: ref, at: new Date().toISOString() } : { sha: ref, at: new Date().toISOString() };
  writeLedger(l);
  try { fs.rmSync(work, { recursive: true, force: true }); } catch { /* 清理失败不拦 */ }
  return {
    ok: true, name, ref: sp.mode === 'release' ? `v${ref}` : ref.slice(0, 7),
    added: a.added, changed: a.changed, same: a.same, backup: bkp,
    note: '已同步到仓库主源和引擎读取处；旧版备份在上面路径，想回滚让助手拷回即可',
  };
}
