// 跨平台路径单一来源：Mac 本机与 Windows 安装包共用（提示词里的路径全部从这里生成，不许再硬编码 /Users/…）
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const IS_WIN = process.platform === 'win32';
export const ROOT = path.join(here, '..'); // workbench 根目录
export const HOME = os.homedir();
export const SKILLS = path.join(HOME, '.claude', 'skills');
export const LAPIAN = path.join(HOME, '.lapian');
export const PEXELS_KEY = path.join(LAPIAN, 'pexels_key');
export const SCA_ASSETS = path.join(ROOT, 'engine-assets', 'sca');
export const SKILL_KAMI = path.join(SKILLS, 'kami');
export const SKILL_GUIZANG = path.join(SKILLS, 'guizang-social-card-skill');
export const SKILL_SWEETY = path.join(SKILLS, 'sweety-statechart-video');

// 提示词里一律用正斜杠（Windows 引擎的 Bash 是 git-bash，C:/Users/… 合法；node require 也认）
export const fw = (p) => p.split(path.sep).join('/');

// Windows 官方安装器不叫 python3（git-bash 里也没有），提示词里用变量拼
export const PYBIN = IS_WIN ? 'python' : 'python3';
