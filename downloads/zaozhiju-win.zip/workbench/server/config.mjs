// 工作台本地配置：并发数、开机自启。存 ~/.zaozhiju/config.json,与安装包/开发机通用。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { IS_WIN } from './paths.mjs';

const execFileP = promisify(execFile);
const FILE = path.join(os.homedir(), '.zaozhiju', 'config.json');
const LABEL = 'net.zaozhiju.server';

export function readConfig() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return {}; }
}
export function writeConfig(patch) {
  const cur = readConfig();
  const next = { ...cur, ...patch };
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(next, null, 1));
  return next;
}

export const parallelCap = () => Math.min(8, Math.max(1, readConfig().parallel || 2));

// ── 开机自启：mac=LaunchAgent(由 launchd 拉起本机 node 服务),Windows=任务计划程序 LogonTask ──
// 服务代码目录取当前运行的 ROOT(开发机=仓库,装机=~/.zaozhiju/workbench),自启路径随安装走。
function plist(root) {
  // 启动前先看端口:服务已活着就立刻退出(点开关/重登都不撞车);crash 噪声也不会有
  const cmd = `curl -s --max-time 2 http://127.0.0.1:8712/api/types >/dev/null || exec ${process.execPath} ${path.join(root, 'server', 'server.mjs')}`;
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>${LABEL}</string>
  <key>ProgramArguments</key><array>
    <string>/bin/bash</string>
    <string>-c</string>
    <string>${cmd.replace(/&/g, '&amp;')}</string>
  </array>
  <key>WorkingDirectory</key><string>${root}</string>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>${path.join(os.homedir(), '.zaozhiju', 'autostart.log')}</string>
  <key>StandardErrorPath</key><string>${path.join(os.homedir(), '.zaozhiju', 'autostart.log')}</string>
</dict></plist>`;
}

export async function setAutostart(on, root) {
  if (IS_WIN) {
    const js = path.join(os.homedir(), '.zaozhiju', 'autostart.js');
    if (on) {
      fs.mkdirSync(path.dirname(js), { recursive: true });
      fs.writeFileSync(js, `// 造纸局开机自启:后台拉起本地服务(装机的 node 与仓库路径以写入时为准)\nvar cp = require('child_process');\ncp.spawn('${process.execPath.replace(/\\/g, '\\\\')}', ['${path.join(root, 'server', 'server.mjs').replace(/\\/g, '\\\\')}'], { detached: true, stdio: 'ignore', windowsHide: true }).unref();\n`);
      await execFileP('schtasks', ['/create', '/tn', 'ZaozhijuServer', '/tr', `wscript.exe //b "${js}"`, '/sc', 'logon', '/f']);
    } else {
      try { await execFileP('schtasks', ['/delete', '/tn', 'ZaozhijuServer', '/f']); } catch { /* 本来就没建 */ }
    }
  } else {
    const pl = path.join(os.homedir(), 'Library', 'LaunchAgents', `${LABEL}.plist`);
    if (on) {
      fs.mkdirSync(path.dirname(pl), { recursive: true });
      fs.writeFileSync(pl, plist(root));
      try { await execFileP('launchctl', ['bootstrap', `gui/${os.userInfo().uid}`, pl]); } catch { /* 已加载 */ }
    } else {
      try { await execFileP('launchctl', ['bootout', `gui/${os.userInfo().uid}/${LABEL}`]); } catch { /* 没加载 */ }
      try { fs.rmSync(pl, { force: true }); } catch { /* 忽略 */ }
    }
  }
  writeConfig({ autostart: !!on });
  return !!on;
}

export async function autostartState(root) {
  if (readConfig().autostart !== true) return false;
  try {
    if (IS_WIN) { await execFileP('schtasks', ['/query', '/tn', 'ZaozhijuServer']); return true; }
    await execFileP('launchctl', ['print', `gui/${os.userInfo().uid}/${LABEL}`]);
    return true;
  } catch { return false; }
}
