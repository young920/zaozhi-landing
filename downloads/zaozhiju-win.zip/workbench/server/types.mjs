// 15 种产出类型定义 + 提示词模板（收敛规则内置，配方来自 test-output/demos 实测）
import { fw, PYBIN, SCA_ASSETS, SKILL_KAMI, SKILL_GUIZANG, SKILL_SWEETY, PEXELS_KEY } from './paths.mjs';

export const CONVERGE = `【硬性交付规则——必须遵守】
1. 最多允许 2 轮"渲染→检查→修改"循环，达到无溢出、无乱码、板块齐全即交付，禁止第三轮修改
2. 禁止对配色、间距、字号做微调式打磨，结构合格就停
3. 宁可保留小瑕疵也要按时交付
4. 机检例外：技能自带的机器检查（lint / validate / check-content / check-charts / mix-report）报出硬伤时，允许"只修机器报出的那几项"再多跑 1 轮，修完立即交付；借机做审美打磨仍然禁止
完成后只报告：总耗时、修改轮数、遗留瑕疵（如有）；若有素材缺口清单（[DATA NEEDED]）也一并列出。`;

const PDF_OUT = `输出要求：最终 PDF 必须保存为当前工作目录下的 ./output.pdf（中间文件放哪都行，但最终版必须写到这个文件名）。写完后立即停止，不要再做任何打磨。`;
const SITE_OUT = `输出要求：可部署的静态站点放到当前工作目录的 ./output/ 目录里（入口 ./output/index.html），并对页面首屏截图保存为 ./output/preview.png。完成后立即停止，不要再做任何打磨。`;
const FLOWART_OUT = `输出要求（艺术流程图管线 = statechart-art 原版手绘引擎，按步骤执行，不要自创渲染方式、不要用 HTML/SVG/画图工具代替）：
1. 先用 Read 工具看画风基准图 ${fw(SCA_ASSETS)}/sample.png（成品要长这样），再在当前工作目录写 draw.cjs（必须是 CJS；require 会解析到 workbench 的依赖，禁止 npm install）。坐标一律毫米，画布 216×216mm（2160px），y 向下。开头：const S = require('${fw(SCA_ASSETS)}')
2. API 速查（全是现成函数，照着组合即可）：
   const P = S.plate({ seed: '任意字符串' })                    // 热压水彩纸+全套钢笔彩铅画具
   S.title(P, '主标题', { sub: '副题（斜体）', kicker: '眉题小字' }) // 左上标题区，占 y≤42
   const F = S.flow({ starts:[{x,y,to:'a'}],
     nodes:[{id,x,y,label,sub,no:'No.1',pin:0,w:30,h:14}],
     edges:[{from,to,label,bug,via:[[x,y],[x,y]]}] })            // 布局数据；x,y=票中心
   S.tickets(P, F, { bugColor: '#b5453a', bugWash: '#f0b3a8' })  // 红绳小票图：状态=图钉小票(红字编号+锯齿底)，转移=钢笔红曲线+箭头，label 里 [条件] 自动红字；有 bug:true 边才传 bugColor 那第三参
   S.person(P, x, y, 0.9, { seed:'p1', pose:'stand|wave|shake|hold|reach|cheer', hair:'short|bob|bun|wavy', shirt:{color:S.C.sky}, apron:S.C.sage, look:-0.9, flip:true, hold:{ r:(Q,h)=>S.H.bobaCup(Q,h[0],h[1]+2,0.42,{stage:'ready'}) } })  // y=脚底基线
   场景道具 S.H：counter(P,x0,x1,y,h) register(P,cx,by,s) bell coin(P,x,y,r) bobaCup(P,cx,by,s,{stage:'sealed|ready'}) jar(P,cx,by,s,{label:'珍珠',pearls:[[-4,-2]]}) shaker magnifier hourglass stove kettle pot mop vine planter awning(P,x0,x1,top,bottom,'招牌字') shopWindow sunrise moon
   色板：S.C（caramel/rose/sage/sky/mint/blush/wood/gold/pearl…）与 S.SOFT
   S.note(P, { x, y, w, h, lines: ['第一行','第二行'] })          // 胶带便签卡
   S.text(P, '文字', x, y, { size: 4, align: 'center', color: '#6a5a50' }) // 中文楷体（文楷），size 毫米
   兜底手绘层：S.D.ell/rrect/curve/tf 出几何，P.ink/P.curve/P.paper/P.colour/P.outline/P.hatch/P.dot 落墨
   await S.finish(P, './output')                                 // 写 output/art.png + preview.png
3. 版式纪律（必须遵守，违反即返工）：
   - 标题区 y≤44；小票区 y 50-128，每排最多 4 票、水平间距≥54mm；场景区 y≥150，人物脚底基线≤212，道具摆在人物旁
   - 票面中文：label≤5字、sub≤7字；edge label≤5字；框默认 30×14，只按内容微调
   - 分支/易错环节单独一排放下面，边加 bug:true
   - 场景要"演出"这个流程：至少 1 个人物 + 2 个道具，与环节呼应（点单=柜台+收银机、审核=桌前+放大镜、发货=打包+小车、学习=书+灯…）；道具不够就用兜底层自己画简单形状
   - 内容（环节/分支/规则/文案）以素材/链接/主题为准，不得虚构与素材矛盾的流程
4. node draw.cjs 生成 ./output/art.png（约 2-4 分钟，属正常，等它跑完）
5. 写 ./output/index.html：纸色底 #f4efe6、居中显示 art.png（width:100%;max-width:760px）、顶部标题一行、页脚"造纸局 · 艺术流程图"
6. 用 Read 工具亲眼检查 output/art.png：中文清晰无豆腐块、文字不溢出票框、箭头不穿票、图不叠图；最多修 2 轮
7. 修好后跑 sips -Z 1080 ./output/art.png --out ./output/preview.png。完成后立即停止，不要再做任何打磨。`

const SVIDEO_OUT = `输出要求（蜡笔状态图视频管线 = sweety-statechart-video 技能，严格按步骤走，不要自创渲染方式）：
1. 技能目录：${fw(SKILL_SWEETY)}（下称 SKILL）。所有命令绝对路径：${PYBIN} SKILL/scripts/scv.py <命令> <任务目录>。任务目录用当前工作目录下的 ./job，禁止放进 SKILL 目录。
2. 读 SKILL/SKILL.md 与 SKILL/references/story-design.md，把主题拆成 2-4 章"会动的状态图"（每章 ≤8 卡片、≤12 箭头；卡片写看得见的状态 2-6 字，箭头写发生了什么 ≤8 字，每步一行旁白字幕 ≤24 字、讲因果）。
3. ${PYBIN} SKILL/scripts/scv.py new ./job --title "…" 起骨架，编辑 job/film.json 填真实内容，并设置："aspect":"3:4"、"duration":"2-3分钟"、"voice":"crayon-sister"、"watermark":null、"music":{"mood":"curious","sync":true}、"deliver":["clips","social","longimage","gif","html"]（deliver 让渲染时顺带产出分章短片/平台补边图/长图/GIF/单文件网页，别单独再跑；若下方"用户选项"指定了画幅/时长，用指定值替换 aspect/duration）。
4. 断点续跑：若 ./job 里已有 film.json 和 scenes.js（这是重试），先 scv.py check ./job（有 error 必改到 0），只补缺失的步骤，绝不从头重做已完成内容。首次才走全流程：check → layout → draft → 细改 scenes.js（每个状态都有跟随动作的插画，不压卡片不压字）。
5. scv.py lint ./job：最多 2 轮。每轮只修 issues 里列的硬伤（卡片重叠、文字被压）；修完重跑一次 lint 确认硬伤清零再往下（两轮后还剩 spill/holes 这类提示性警告就直接走）。写作+检查阶段合计不超过 30 分钟——到点就进第 6 步，成片优先于打磨。
6. scv.py voice ./job：若报旁白环境缺失，把 film.json 改 "voice":"none" 出无声版，不许卡住干等。然后 ${PYBIN} SKILL/scripts/scv.py --workers 3 all ./job 一条跑完（配音+渲染约 15-35 分钟，命令慢属正常，等它结束）。
7. 跑完做两件收尾：
   a) 用 Read 工具看 ./job/work/audio/mix-report.json：旁白被音乐盖住（报告判 voice_over_bed_db 差值不足）就只调 music 的 gain_db 调低一档、重跑 voice+mix 一遍（按机检例外只多跑这一轮）；sync 偏差超 60ms 记一笔即可，不重渲。
   b) ${PYBIN} SKILL/scripts/scv.py publish ./job，然后把 job/outputs/publish/ 里的 titles.txt、description.txt、tags.txt、chapters.txt、cover.txt（有哪个取哪个）拼到 ./result.txt 末尾，段首写【发文物料：3 个标题/简介/话题/章节时码/封面文案】；再建 ./deliver/ 目录，把 job/outputs/clips/、job/outputs/social/、job/outputs/longimage/、job/outputs/gif/、job/outputs/film.html（哪些存在拷哪些）拷进去——这些是给用户直接发小红书/微信/B站用的成品物料。
8. 最后：把 job/outputs/film.mp4 复制到当前工作目录 ./output.mp4，把 job/outputs/cover.png 复制到 ./cover.png。写完立即停止，不要再做任何打磨。
内容纪律：状态图的环节、分支与旁白以素材/链接/主题为准，不得虚构与素材矛盾的流程。`;

const PPTX_OUT = `输出要求（可编辑 PPT 管线 = kami 技能 python-pptx 路，严格按步骤执行，不要自创渲染方式、不要用 HTML 截图代替）：
1. 技能目录：${fw(SKILL_KAMI)}（下称 SKILL）。先读 SKILL/SKILL.md 的 slides 行、references/production.md「Part 2 · Python -> PPTX」（色板/字号/结构/安全区规矩）与 references/deck-preflight.md；把 SKILL/assets/templates/slides.py 复制成当前工作目录的 deck.py 做工作副本，禁止修改 SKILL 目录里任何文件。
2. 素材保真：把主题/素材整理成 ./content.json（结构按 SKILL/references/schemas/slides.json），素材里每个数字、人名、日期都作为事实字段进入；跑 ${PYBIN} ${fw(SKILL_KAMI)}/scripts/build.py --check-content ./content.json，schema 报错改到清零。确实放不进成品的，在 ./result.txt 开头用 [DATA NEEDED] 逐条列出，不许静默丢事实。
3. 改 deck.py 填真实内容：8-12 页 16:9，每页标题是一个观点句（不是名词短语），跑 ${PYBIN} deck.py 生成 ./output.pptx。字体纪律：模板默认 Source Han Serif SC 本机不一定装了——先确认可用中文字体（ls /System/Library/Fonts /System/Library/Fonts/Supplemental ~/Library/Fonts），没有就用 Songti SC（宋体-简）或 PingFang SC 顶上，最终用了哪个字体记进 ./result.txt。
4. 目检（技能硬规矩：python-pptx 保存成功不算交付）：让 Keynote 无人值守把成品导出 PDF 再逐页看。osascript 执行：
   tell application "Keynote"
     set d to open POSIX file "<当前工作目录绝对路径>/output.pptx"
     export d to POSIX file "<当前工作目录绝对路径>/review.pdf" as PDF
     close d saving no
   end tell
   再用 Read 工具逐页看 ./review.pdf：中文无豆腐块、字体没被静默换成 Calibri/Aptos 之类、文字不溢出不裁切、页码完整。发现问题改 deck.py 重跑第 3-4 步，最多 2 轮。Keynote 不通就试 soffice --headless --convert-to pdf review 链路；两条都不通就在 ./result.txt 开头写明「未经放映软件目检」，不许瞒。
5. 交付：./output.pptx（可编辑成品）与 ./review.pdf（目检导出件）都留在当前工作目录。写完立即停止，不要再做任何打磨。`;

const DOCX_OUT = `输出要求（可编辑 Word 管线 = kami 技能，先按长文档路排版出 PDF，再按 production.md Part 5 转 .docx，严格按步骤执行，不要自创转换方式）：
1. 技能目录：${fw(SKILL_KAMI)}（下称 SKILL）。先读 SKILL/SKILL.md 的 Output formats 行与 references/production.md「Part 5 · HTML -> DOCX」（铁律：正文里的内联 SVG 会让 Word 报错打不开，必须先烤成 PNG 再转换）。禁止修改 SKILL 目录里任何文件。
2. 先按 kami 长文档路出排版 PDF：把素材整理成 ./content.json（结构按 SKILL/references/schemas/long-doc.json），跑 ${PYBIN} ${fw(SKILL_KAMI)}/scripts/build.py --check-content ./content.json 报错改到清零；按 SKILL 长文档模板排 4-8 页源文件 ./document.html（章节层级清晰、开头导读、结尾结论），按 production.md Part 1 渲染 ./output.pdf，并用 Read 工具逐页目检 ./output.pdf：中文无豆腐块、不溢出不裁切，最多修 2 轮。排版纪律与「长文档」单完全一致。
3. 图表烤 PNG（源 HTML 里有内联 <svg> 才做，没有就跳过直接第 4 步）：写一个小脚本用 ${PYBIN} 把每个 <svg> 提取成独立文件（补 xmlns 属性），再用 ${fw(SKILL_GUIZANG)}/node_modules 里的 playwright（require 写法同截图脚本）逐个截成宽 1600 的 PNG，把源 HTML 的 <svg> 块替换成对应 <img src>，得到 ./document-for-word.html；playwright 用不了就把图表改成文字表格并在 ./result.txt 开头记一笔。
4. 转换与校验：跑 pandoc ./document-for-word.html -o ./output.docx。本机没有 pandoc（command not found）就在 ./result.txt 开头写「本机缺 pandoc，Word 转换装不了：~/.zaozhiju/bin 或 brew install pandoc」，此单按失败处理，不许拿 PDF 冒充 Word。转换后用 ${PYBIN} 校验：docx.Document("./output.docx") 打得开、段落数 >10、段落里有中文；不合格回第 3 步修，最多 2 轮。
5. 交付：./output.docx（可编辑成品）与 ./output.pdf（排版对照版）都留在当前工作目录。写完立即停止，不要再做任何打磨。`;

const XHS_OUT = `输出要求（小红书图文管线 = guizang-social-card-skill 技能，严格按步骤走，不要自创渲染方式）：
1. 技能目录：${fw(SKILL_GUIZANG)}（下称 SKILL）。任务工作区用当前目录下的 ./job；禁止在 SKILL 目录里建任务或修改其任何文件。
2. 先读 SKILL/SKILL.md，再读它的两份必读参考 references/content-summarization-prerequisite.md 与 references/content-summarization-flow.md，然后按内容气质选一个风格 Mode（若下方"用户选项"已指定风格/色系，直接用指定的，不再自选；否则自选路由：观点/故事/生活方式→Mode A Editorial；工具/教程/评测/数据密集→Mode B Swiss 瑞士网格；强观点海报冲击→Mode C 野兽派；周报/研究综述→Mode D 报纸；单篇论文/情报卡→Mode F 论文快报；访谈/播客→对话栏 E）。读对应模板参考与该 Mode 的风格纪律后，把 SKILL/assets/ 的种子模板复制为 ./job/index.html，只替换 POSTERS_HERE 区域，不动种子已接好的字体/主题/尺寸系统。
3. 产出一套小红书 3:4 竖版卡（每张 1080×1440）：5-8 张，第 1 张是封面钩子，之后每张只讲一个观点；文案、数据、结论以素材/链接/主题为准，不得虚构。逐页版式不许徒手发明：每填一张卡前，从 SKILL/references/layout-recipes.md 里挑一条适合这页内容的配方（A 档编辑版式/B 档 Swiss 版式按所选 Mode 用对应编号段），只读那一条小节的骨架 HTML 与 Minimum density 要求照搭；相邻两张不重复同一配方，全套至少用 3 种不同骨架，任何一页不许空着半张卡。
4. 无头执行、禁止向用户提问（技能里"先问用户要图"的关卡直接跳过）：上传素材里有图片就优先用用户的图——备注写了用途的（如"放封面""第 3 页用"）严格按备注排进对应卡位；用户图不够的图位再走 Pexels 官方 API 补图：图位要补图时才发请求，curl 里用 -H "Authorization: $(tr -d '[:space:]' < ${fw(PEXELS_KEY)})" 把密钥从文件直接注入（文件不存在或为空就跳过补图，该图位改纯排版）。密钥只能这样命令替换进 curl，严禁把 key 的字符抄写、转述、截断进命令或任何文件（2026-11-08 实测：模型手抄密钥会抄断导致 401），也不许把密钥原文写进产物/日志。然后 curl -s "https://api.pexels.com/v1/search?query=<英文关键词>&per_page=3&orientation=portrait&size=large"，从返回 JSON 挑与页面内容角色匹配的图（补的图要真实服务版面，不做泛泛装饰），curl 下载其 src.large2x 到 ./job/assets/（文件名按用途命名如 hero-desk.jpg，并记 assets/SOURCES.md 一行：文件名 ← 图片页URL · 摄影师名；用户自己上传的图不记 SOURCES）；API 或下载失败就把该图位改纯排版（大字标题+要点+引言），照常交付。Google Fonts 不通是正常的：截图用 waitUntil:'domcontentloaded' 再等 1500ms，让系统字体回退，不要等网络空闲。图上文字纪律（每张有图的卡都要做，遵守 references/image-overlay.md）：先用 Read 工具亲眼看图，判断主体（人脸/产品/地平线）在画面里的位置，在 <img> 旁留一行注释写明主体方位（如 <!-- subject: left -->），并按该图内联写 object-position 保住主体——模板默认的 center 50% 不许照抄；标题不许压人脸；每张封面级图在 360px 宽的缩略尺寸下自查标题完整可读。
5. 渲染：在 ./ 写 render.cjs —— const { chromium } = require('${fw(SKILL_GUIZANG)}/node_modules/playwright'); launch 后 newPage({ viewport: { width: 1200, height: 1700 } })，打开 ./job/index.html，对每个 section.poster 逐个 locator.screenshot 存到 ./output/card-01.png、card-02.png…（3:4 的 .poster.xhs；尺寸不是 1080 宽先查模板再修）。node render.cjs 跑完。
6. 核查：跑 node ${fw(SKILL_GUIZANG)}/validate-social-deck.mjs ./job（若风格类名没标全导致识别错，加 --style=editorial|swiss|brutalist 之一覆盖）。FAIL 和 WARN 都是修复靶子：输出里每条规则自带改法，按它修（R5 四带密度不足、R6 大标题行数顶格、R8 底部大片空白、R9 标题贴正文是返工高发项；文字溢出按它给的分级梯子处理——轻微就微调、明显就换紧凑档、大片装不下就换 layout-recipes 里容量更大的配方，禁止靠缩到看不清的字号硬塞，也不许为过检加无意义装饰）。最多 2 轮，机检硬伤可走交付规则的机检例外；再用 Read 工具亲眼检查 ./output/card-01.png 到末张：中文清晰无豆腐块、文字不溢出不贴边、3:4 吃满画布不空半张卡。
7. 交付：写 ./output/index.html —— 纸色底 #f4efe6、顶部标题一行、把 card-01…card-NN 竖排居中展示（img width:100%;max-width:540px）、页脚"造纸局 · 小红书图文"；再 cp ./output/card-01.png ./output/preview.png。另外写 ./output/发帖文案.txt（纯文本，照小红书发帖习惯，四段：【备选标题】3 条各 ≤20 字钩子式；【正文】100-200 字收拢全套卡片的核心信息、结尾带一句互动引导；【话题标签】5-8 个 # 开头空格分隔、含 1-2 个大流量标签；【发布建议】一句话）。标题与标签必须从已做好的卡片文案里提炼，不得虚构新事实；再把这段发帖文案全文抄到 ./result.txt 末尾，段首写【发帖文案】。写完立即停止，不要再做任何打磨。`;

const WXCOVER_OUT = `输出要求（公众号封面管线 = guizang-social-card-skill 技能，严格按步骤走，不要自创渲染方式）：
1. 技能目录：${fw(SKILL_GUIZANG)}（下称 SKILL）。任务工作区用当前目录下的 ./job；禁止在 SKILL 目录里建任务或修改其任何文件。
2. 读 SKILL/SKILL.md 的"微信公众号封面"相关段落与 references/platform-specs.md、references/title-shortener.md；风格 Mode 按下方"用户选项"指定的用，没指定则按气质自选：稳/有质感→Mode A Editorial，科技/数据/工具→Mode B Swiss，强冲击观点→Mode C 野兽派（读该 Mode 的模板参考，全套只用一个 Mode）；把对应种子模板复制为 ./job/index.html。
3. 产出封面双图（同一个 HTML 里两个 poster 节点）：21:9 主封面（.poster.wide）带完整/接近完整的标题+副题+一组强视觉关系；1:1 方封面（.poster.square）用从长标题提炼的短标题——大字居中、默认不放图、不放挤小的副题（提炼方法按 title-shortener.md）。两张都要在手机缩略尺寸下读得清。文案以素材/链接/主题为准，不得虚构。
4. 无头执行、禁止向用户提问：用户上传了图片就优先用（备注写明用途的照办）；21:9 需要配图且没有用户图时，走 Pexels 官方 API 补 1 张横版实景图：curl 里用 -H "Authorization: $(tr -d '[:space:]' < ${fw(PEXELS_KEY)})" 把密钥从文件直接注入（文件不存在或为空就主封面改纯排版；密钥只能命令替换，严禁手抄/写进产物，手抄会截断导致 401），curl -s "https://api.pexels.com/v1/search?query=<英文关键词>&per_page=3&orientation=landscape&size=large"，下载 src.large2x 到 ./job/assets/，记 assets/SOURCES.md；没密钥或抓图失败就主封面改纯排版大字，1:1 方封面始终不用网图。Google Fonts 不通正常：截图用 waitUntil:'domcontentloaded' 再等 1500ms，系统字体回退。文字压图时遵守 image-overlay.md 的主体图/安全区/缩略图测试规则。
5. 渲染：在 ./ 写 render.cjs —— const { chromium } = require('${fw(SKILL_GUIZANG)}/node_modules/playwright'); launch 后 newPage({ viewport: { width: 1300, height: 1200 } })，打开 ./job/index.html，把 .poster.wide 节点截到 ./output/cover-wide.png、.poster.square 截到 ./output/cover-square.png（尺寸按 platform-specs.md）。node render.cjs 跑完。
6. 核查：再用 Read 工具亲眼检查两张 PNG：中文无豆腐块、标题完整不贴边、1:1 里没有挤不下的小字；发现问题最多改 2 轮重渲。
7. 交付：写 ./output/index.html —— 纸色底 #f4efe6，宽封面与方封面上下展示（各标"21:9 主封面 / 1:1 方封面"），页脚"造纸局 · 公众号封面"；再 cp ./output/cover-wide.png ./output/preview.png。写完立即停止，不要再做任何打磨。`;

export const TYPES = [
  {
    id: 'onepager', label: '一页纸', kind: 'pdf', est: 10,
    desc: '一页讲清一个产品 / 项目 / 决策',
    brief: (t) => `使用 kami skill 制作一份中文"一页纸"PDF：${t}。要求：一页纸版式——标题 + 核心结论前置，正文分板块（背景 / 要点 / 风险或下一步），信息密度高，一眼读完。`,
  },
  {
    id: 'longdoc', label: '长文档', kind: 'pdf', est: 30,
    desc: '多页长文 / 白皮书 / 研报排版',
    brief: (t) => `使用 kami skill 制作一份中文长文档 PDF（4-8 页）：${t}。要求：章节层级清晰，开头有导读或目录，正文有小标题分段，结尾有结论。`,
  },
  {
    id: 'letter', label: '信件', kind: 'pdf', est: 9,
    desc: '正式信件 / 邀请函 / 公开信',
    brief: (t) => `使用 kami skill 制作一封中文信件 PDF（1-2 页）：${t}。要求：标准信件格式——日期、称呼、正文、祝辞、落款，排版庄重。`,
  },
  {
    id: 'portfolio', label: '作品集', kind: 'pdf', est: 18,
    desc: '个人作品集 / 案例合集',
    brief: (t) => `使用 kami skill 制作一份中文个人作品集 PDF（2-4 页）：${t}。要求：概述 + 3-5 个代表项目（角色、成果、量化数据）+ 联系方式占位。`,
  },
  {
    id: 'resume', label: '简历', kind: 'pdf', est: 15,
    desc: '一到两页中文简历',
    brief: (t) => `使用 kami skill 制作一份中文简历 PDF（1-2 页）：${t}。要求：教育 / 工作 / 项目 / 技能板块，成果量化，不留"待补充"字样。`,
  },
  {
    id: 'slides', label: '演示文稿', kind: 'pdf', est: 14,
    desc: '8-12 页横版 slides',
    brief: (t) => `使用 kami skill 制作一套中文演示文稿 PDF（8-12 页，16:9 横版）：${t}。要求：有封面页，每页一个核心观点，信息层级清楚。`,
  },
  {
    id: 'pptx', label: 'PPT 汇报稿', kind: 'pptx', out: 'pptx', est: 20,
    desc: '8-12 页可编辑 PPTX（PowerPoint / Keynote 直接打开改字）',
    brief: (t) => `使用 kami skill 制作一套中文可编辑 PPT 演示稿（PPTX，8-12 页，16:9 横版）：${t}。要求：每页一个断言式观点标题，封面/结尾齐全，数字事实来自素材。`,
  },
  {
    id: 'docx', label: 'Word 文档', kind: 'docx', out: 'docx', est: 30,
    desc: '4-8 页可编辑 Word（.docx），同时附排版 PDF 对照版',
    brief: (t) => `使用 kami skill 制作一份中文可编辑 Word 文档（.docx，4-8 页长文）：${t}。要求：章节层级清晰、标题正文规范、数字事实来自素材，交稿即可在 Word/WPS 里继续改。`,
  },
  {
    id: 'equity', label: '财报点评', kind: 'pdf', est: 8,
    desc: '财报 / 行业点评报告',
    brief: (t) => `使用 kami skill 制作一份中文财报 / 行业点评 PDF（2-3 页）：${t}。要求：核心观点摘要、关键数据表格、风险提示、结论评级。`,
  },
  {
    id: 'changelog', label: '更新日志', kind: 'pdf', est: 7,
    desc: '新版本发布说明',
    brief: (t) => `使用 kami skill 制作一份中文更新日志 PDF（1-2 页）：${t}。要求：版本亮点、新功能列表（3-5 个，每个一句话说清价值）、改进、修复、升级提示。`,
  },
  {
    id: 'landing', label: '落地页', kind: 'site', est: 13,
    desc: '产品宣传静态网页（HTML）',
    brief: (t) => `使用 kami skill 制作一个中文产品落地页（静态站点）：${t}。要求：首屏标题 + 副标题 + CTA 按钮、3 个卖点、使用步骤、定价、页脚。`,
  },
  {
    id: 'flowart', label: '艺术流程图', kind: 'site', out: 'flowart', est: 14,
    desc: 'statechart-art 手绘引擎：红绳小票流程图 + 状态场景（正方形 PNG）',
    brief: (t) => `制作一张中文「艺术流程图」：${t}。用 statechart-art 手绘引擎把流程画成一张"状态画"：每个环节是一枚图钉钉住的小票卡（红字编号+锯齿底），转移是钢笔红色曲线箭头，[条件]用红铅笔字，易错/待确认分支单独放一排；画面下方三分之一要画出与流程呼应的场景（人物+柜台/道具等，像插画分镜）。正方形画布、手机上一眼看清。内容（环节、分支、规则）以素材/链接/主题为准，不得虚构与素材矛盾的流程。`,
  },
  {
    id: 'scvideo', label: '蜡笔状态图视频', kind: 'video', out: 'scvideo', est: 60,
    desc: '把一个流程/生意/系统做成会动的状态图短片（MP4，画幅/时长可选，带旁白字幕）',
    brief: (t) => `使用 sweety-statechart-video 技能（格物·蜡笔状态图）制作一支中文状态图短片：${t}。把主题讲成一个"会动的状态图"故事：小圆点沿箭头跑、卡片弹出、旁白逐步解说。`,
    voiceOpts: [
      { v: 'crayon-sister', label: '蜡笔姐姐（默认）', hint: '年轻女声，明亮温暖带笑意，适合生活知识、轻松科普' },
      { v: 'blueprint-guy', label: '图纸哥', hint: '清爽男声，理性利落带点幽默，适合流程、原理、机制' },
      { v: 'sunny-girl', label: '元气少女', hint: '清脆甜亮、语调上扬稍快，适合有趣的小科普' },
      { v: 'old-master', label: '老师傅', hint: '温厚略沙哑、慢悠悠带笑，适合手艺、老行当、道理' },
      { v: 'none', label: '不要旁白', hint: '出无声版，只有字幕与音乐' },
    ],
    aspectOpts: [
      { v: 'a34', film: '3:4', label: '3:4 竖版（默认）', hint: '小红书/视频号竖屏最稳' },
      { v: 'a916', film: '9:16', label: '9:16 全屏竖版', hint: '抖音/手机全屏；卡片字自动放大，版次要重排' },
      { v: 'asq', film: '1:1', label: '1:1 方形', hint: '微信文章内嵌/头像位友好' },
    ],
    durationOpts: [
      { v: 'short', film: '1分钟', label: '约 1 分钟速览', ratio: '1-2 章 × 每章 ≤6 步，每句旁白 10-16 字' },
      { v: 'standard', film: '2-3分钟', label: '2-3 分钟标准（默认）', ratio: '2-4 章 × 每章 ≤8 步，每句旁白 12-20 字' },
    ],
  },
  {
    id: 'xhs', label: '小红书图文', kind: 'site', out: 'xhs', est: 25,
    desc: '一套 5-8 张 3:4 竖版图文卡 PNG（guizang 社交卡引擎，编辑/瑞士/野兽派等固定风格系统）',
    brief: (t) => `使用 guizang-social-card-skill 技能制作一套中文小红书图文（3:4 竖版卡片组图）：${t}。要求：第 1 张封面钩子抓人，之后每张只讲一个观点，手机上刷一眼读懂；全套只用一个风格 Mode，色板与字号体系遵守技能里的固定模板。`,
    styleOpts: [
      { v: 'editorial', label: '编辑纸墨', hint: '衬线大字+米纸底，慢读、有手作感（生活方式/观点/故事）', themes: [
        { v: 'ink-classic', label: '墨典' }, { v: 'indigo-porcelain', label: '青瓷' }, { v: 'forest-ink', label: '松墨' },
        { v: 'kraft-paper', label: '牛皮纸' }, { v: 'dune', label: '沙丘' }, { v: 'midnight-ink', label: '夜墨' } ] },
      { v: 'swiss', label: '瑞士网格', hint: '极细网格+单一高饱和强调色，系统感、数据感（工具/评测/方法论）', themes: [
        { v: 'ikb', label: '克莱因蓝' }, { v: 'lemon-yellow', label: '柠檬黄' }, { v: 'lemon-green', label: '柠檬绿' }, { v: 'safety-orange', label: '安全橙' } ] },
      { v: 'brutalist', label: '野兽派', hint: '米黄纸+黑色硬描边+高饱和色块，强观点强冲击' },
      { v: 'newspaper', label: '报纸风', hint: '固定米纸+墨黑+藏青红，周报/研究综述感' },
      { v: 'paperbrief', label: '论文快报', hint: '米白纸+黑头块+琥珀黄，单篇论文/情报卡' },
      { v: 'dialogue', label: '对话栏', hint: '淡柠檬绿块+双语排版，访谈/播客栏目' },
    ],
  },
  {
    id: 'wechat', label: '公众号封面', kind: 'site', out: 'wxcover', est: 15,
    desc: '微信公众号封面双图：21:9 头图 + 1:1 方图（PNG 成套，guizang 引擎）',
    brief: (t) => `使用 guizang-social-card-skill 技能制作一组微信公众号封面双图：${t}。要求：21:9 主封面讲清主信息，1:1 方封面用提炼后的短标题大字居中；两张在信息流小图尺寸下都要能读。`,
    styleOpts: [
      { v: 'editorial', label: '编辑纸墨', hint: '衬线大字+米纸底，稳、有质感', themes: [
        { v: 'ink-classic', label: '墨典' }, { v: 'indigo-porcelain', label: '青瓷' }, { v: 'forest-ink', label: '松墨' },
        { v: 'kraft-paper', label: '牛皮纸' }, { v: 'dune', label: '沙丘' }, { v: 'midnight-ink', label: '夜墨' } ] },
      { v: 'swiss', label: '瑞士网格', hint: '网格+单一强调色，科技/数据感', themes: [
        { v: 'ikb', label: '克莱因蓝' }, { v: 'lemon-yellow', label: '柠檬黄' }, { v: 'lemon-green', label: '柠檬绿' }, { v: 'safety-orange', label: '安全橙' } ] },
      { v: 'brutalist', label: '野兽派', hint: '硬描边色块，强冲击' },
    ],
  },
];

const QC_OUT = `质检单（交付文件写完后的最后一步，一两分钟写完，不许借此展开新的打磨）：在当前工作目录写 ./qc.txt——首行【质检单】，随后一行一项检查，以 ✅ / ⚠️ / ❌ 开头，只写真实做过的：
- 目检：用 Read 工具实际看过哪些页/图，看到了什么（写具体，如"逐页 12 页均无溢出"）
- 机检：跑过哪些自检命令（--check-content / validate / lint / mix-report / pandoc 校验等），报错是否清零
- 事实保真：素材里的数字/人名/日期是否逐条进入成品；有遗漏的列 [DATA NEEDED]
- 文件齐全：本类型交付清单里每个文件都在且非空
- 遗留瑕疵：如实列出；没法检查的项目标 ⚠️ 并写明原因。禁止编造 ✅，禁止隐瞒 ❌
- 密钥纪律：本单与任何交付文件里不得出现 API key/token 的原文或片段，需要提及就只写文件路径`;

const FALLBACK_NOTE = '如果只给了主题没有给素材，围绕主题自行生成合理内容（允许虚构的占位素材，但必须自洽可信）。';

export function buildPrompt(type, topic, requirements, ctx = {}) {
  const links = (ctx.links || []).filter(Boolean);
  const inputFiles = (ctx.inputFiles || []).filter(Boolean)
    .map((f) => (typeof f === 'string' ? { name: f } : f));
  const text = (ctx.text || '').trim();
  const hasMaterial = links.length > 0 || inputFiles.length > 0 || !!text;

  const head = topic && topic.trim()
    ? type.brief(topic.trim())
    : type.kind === 'pdf' || type.kind === 'docx'
      ? `使用 kami skill 制作一份中文「${type.label}」（${type.desc}）：主题依据下方素材与链接自行归纳。`
      : `制作一份中文「${type.label}」（${type.desc}）：主题与内容依据下方素材、文本与链接自行归纳。`;

  const parts = [head];
  if (!hasMaterial) parts.push(FALLBACK_NOTE);
  if (text) {
    parts.push(`参考资料·用户粘贴正文（以下内容是用户直接提供的正文素材，为主要内容来源；围绕它展开与排版，不得虚构与其矛盾的事实）：\n<<<\n${text}\n>>>`);
  }
  if (links.length) {
    const crawl = ctx.crawl || 'off';
    const follow = crawl === 'one'
      ? '追子链接（用户选择的模式）：抓完这些页面后，从每个页面的同域子链接中挑 1 个与主题最相关的（如仓库首页→README/文档页、目录页→正文页），用同样方式抓取正文作为补充素材；只追这 1 个，不再深挖。'
      : crawl === 'all'
        ? '追子链接（用户选择的模式）：抓完这些页面后，列出每个页面的同域子链接，按与主题的相关度挑选最多 8 个，逐个抓取正文；跨站外链不追；抓满 8 个立即停止，禁止再深挖二级子页，防止超时。'
        : '只抓这些页面本身，不要自动追页面里的子链接。';
    parts.push(`参考资料·链接（必须先用 WebFetch 抓取全文作为主要内容来源；若 WebFetch 失败或超时，改用 Bash 执行 curl -sL 抓取（引擎环境已注入系统代理，浏览器能打开的站点都能通；GitHub 仓库页重点抓 README）；飞书/字节文档链接用已配置的 lark 工具读取原文。${follow}一切以真实抓到的内容为准，不得凭想象编造页面内容）：\n${links.map((l) => `- ${l}`).join('\n')}`);
  }
  if (inputFiles.length) {
    parts.push(`参考资料·上传素材（在 ./input/ 目录下，逐个用 Read 工具阅读，PDF 与图片可直接读取；以其为主要内容来源，不得虚构与素材矛盾的事实${inputFiles.some((f) => f.note) ? '；标注了"用户备注"的图片，用途要严格按备注执行' : ''}）：\n${inputFiles.map((f) => `- input/${f.name}${f.note ? `（用户备注：${f.note}）` : ''}`).join('\n')}`);
  }
  if (requirements) parts.push(`补充要求：${requirements}`);
  const isKami = type.kind === 'pdf' || type.kind === 'docx' || type.id === 'landing';
  if (hasMaterial && isKami) {
    parts.push(`素材保真工序（本次有真实素材，kami 技能的内容 IR 必须走，不许跳过）：
1. 排版前先把素材整理成当前目录的 content.json——按 kami 技能 references/schemas 里对应类型的 IR 结构写，素材里出现的每个数字、人名、日期、金额都要作为事实字段进入，不许只写散文
2. ${PYBIN} ${fw(SKILL_KAMI)}/scripts/build.py --check-content ./content.json：schema 报错就改到清零
3. 成品源文件（HTML）写好后跑 ${PYBIN} ${fw(SKILL_KAMI)}/scripts/build.py --check-content ./content.json <成品源文件>：素材里的原子事实必须逐条在成品中存活；确实没放进成品的，在 ./result.txt 开头用 [DATA NEEDED] 逐条列出，不许静默丢事实
4. 图表：素材含 ≥3 个同口径可比数字（序列/占比/对比）时，用 ${PYBIN} ${fw(SKILL_KAMI)}/scripts/build.py --chart spec.json -o chart.svg 生成真图表嵌入文档（bar/line/hbar/donut/candlestick/waterfall 六种按数据形态选），几何由数据生成，禁止手画假图；交付前跑 --check-charts 校验图文一致
这些机检跑不过时走交付规则的"机检例外"（只修机检项多 1 轮）。`);
  }
  const optLines = [];
  if (ctx.style) {
    const s = (type.styleOpts || []).find((x) => x.v === ctx.style);
    if (s) {
      const modeName = { editorial: 'Mode A — Editorial Magazine x E-ink', swiss: 'Mode B — Swiss International', brutalist: 'Mode C — Neo-Brutalist（野兽派）', newspaper: 'Mode D — Newspaper Weekly', paperbrief: 'Mode F — Paper Brief（论文快报）', dialogue: '对话栏（dialogue-poster）' }[ctx.style] || ctx.style;
      let line = `用户选项·风格（指定，覆盖输出步骤里的"自选 Mode"）：全套只用 ${modeName}（"${s.label}"），不许换、不许混`;
      if (ctx.theme) {
        const th = (s.themes || []).find((x) => x.v === ctx.theme);
        if (th) line += `；色系用"${th.label}"：编辑纸墨写在 <html data-theme="${ctx.theme}">，瑞士网格写在 <html data-accent="${ctx.theme}">`;
      }
      optLines.push(line);
    }
  }
  if (ctx.voice) {
    const vopt = (type.voiceOpts || []).find((x) => x.v === ctx.voice);
    if (vopt) optLines.push(`用户选项·旁白音色（指定，覆盖输出步骤里的默认值）：第 3 步 film.json 的 "voice" 字段写 "${ctx.voice}"（${vopt.label}）。`);
  }
  if (ctx.aspect) {
    const aopt = (type.aspectOpts || []).find((x) => x.v === ctx.aspect);
    if (aopt) optLines.push(`用户选项·画幅（指定）：第 3 步 film.json 的 "aspect" 写 "${aopt.film}"（${aopt.label}）。画幅不是默认 3:4 时必须重跑 scv.py layout ./job，并按新的 work/layout 空地重写 scenes.js 插画（卡片排布与留白随画幅变，不许照抄默认版式）。`);
  }
  if (ctx.duration) {
    const dopt = (type.durationOpts || []).find((x) => x.v === ctx.duration);
    if (dopt) optLines.push(`用户选项·时长（指定）：第 3 步 film.json 的 "duration" 写 "${dopt.film}"（${dopt.label}）。章步配比跟着缩放：${dopt.ratio}。跑 scv.py check 后按它给的时间预估增删步骤一次再进渲染，别硬摊薄旁白。`);
  }
  if (optLines.length) parts.push(optLines.join('\n'));
  const accent = String(ctx.accent || '').toLowerCase();
  if (/^#[0-9a-f]{6}$/.test(accent) && accent !== '#1b365d' && !['flowart', 'scvideo', 'xhs', 'wxcover', 'pptx'].includes(type.out)) {
    parts.push(`主色定制（用户已选定 ${accent}，覆盖模板默认墨蓝 #1B365D）：\n- 只改当前任务目录里的模板工作副本：把 :root 的 --brand 值改为 ${accent}，这一处改完全局生效；禁止修改 ~/.claude/skills/kami 下的源模板\n- 纸张底色、字体、版式与其余所有颜色一律不动，全文保持"单一强调色"纪律\n- 若跑 skill 的 lint / scripts/tokens.py 报 off-palette：在工作副本的 tokens.json 里同步登记新值再重跑\n- 渲染后用 Read 工具亲眼检查成品：强调色已全局替换、无墨蓝残留，才许交付`);
  }
  parts.push(type.kind === 'pdf' ? PDF_OUT : type.kind === 'pptx' ? PPTX_OUT : type.kind === 'docx' ? DOCX_OUT : type.out === 'flowart' ? FLOWART_OUT : type.out === 'scvideo' ? SVIDEO_OUT : type.out === 'xhs' ? XHS_OUT : type.out === 'wxcover' ? WXCOVER_OUT : SITE_OUT);
  parts.push(QC_OUT);
  parts.push(CONVERGE);
  return parts.join('\n\n');
}

export function publicTypes() {
  return TYPES.map((t) => ({
    id: t.id, label: t.label, kind: t.kind, est: t.est, desc: t.desc,
    hasAccent: t.kind !== 'video' && !['flowart', 'xhs', 'wxcover', 'pptx'].includes(t.out),
    styleOpts: t.styleOpts || null,
    voiceOpts: t.voiceOpts || null,
    aspectOpts: t.aspectOpts || null,
    durationOpts: t.durationOpts || null,
  }));
}
