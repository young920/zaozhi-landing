// 成品一键备份：把 data/tasks 里的最终产物(PDF/MP4/PNG/HTML/result)打成 zip。
// 手写 STORE(不压缩)zip——mp4/png 再压缩没意义，还能边收集边拼，不引新依赖。上限 1.5GB 防炸内存。
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { crc32 } from 'zlib';

const MAX_BYTES = 1.5e9;

function collect(root) {
  const items = [];
  let total = 0;
  const tasksDir = path.join(root, 'data', 'tasks');
  if (!fs.existsSync(tasksDir)) return { items, total };
  const all = (() => { try { return JSON.parse(fs.readFileSync(path.join(root, 'data', 'tasks.json'), 'utf8')); } catch { return []; } })();
  const byId = new Map(all.map((t) => [t.id, t]));
  for (const id of fs.readdirSync(tasksDir)) {
    const dir = path.join(tasksDir, id);
    const meta = byId.get(id) || {};
    const topic = String(meta.topic || '素材成品').slice(0, 24).replace(/[\\/:*?"<>|]/g, '_');
    const push = (abs, name) => {
      try {
        const st = fs.statSync(abs);
        if (!st.isFile() || st.size > MAX_BYTES) return;
        if (total + st.size > MAX_BYTES) return;
        total += st.size;
        items.push({ abs, name: `${topic}/${name}`, size: st.size });
      } catch { /* 没这个文件=正常 */ }
    };
    // 2026-11-08 补漏:output.pptx(PPT 成品之前根本没进包=bug)、qc.txt(质检单)
    for (const f of ['output.pdf', 'output.mp4', 'output.docx', 'output.pptx', 'cover.png', 'result.txt', 'qc.txt']) push(path.join(dir, f), f);
    const out = path.join(dir, 'output');
    if (fs.existsSync(out)) {
      const walk = (d, rel) => {
        for (const e of fs.readdirSync(d, { withFileTypes: true })) {
          if (e.isDirectory()) walk(path.join(d, e.name), rel + e.name + '/');
          else if (!e.name.startsWith('.')) push(path.join(d, e.name), rel + e.name);
        }
      };
      walk(out, 'output/');
    }
  }
  return { items, total };
}

// DOS 时间/日期是分开两个 u16:time=h<<11|m<<5|s/2,date=(年-1980)<<9|月<<5|日
const dosFields = (d) => [
  ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xffff,
  (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xffff,
];

export function buildZip(items) {
  const parts = [];
  const central = [];
  let offset = 0;
  for (const it of items) {
    const buf = fs.readFileSync(it.abs);
    const nameBuf = Buffer.from(it.name, 'utf8');
    const c = crc32(buf);
    const [dt, dd] = dosFields(new Date(fs.statSync(it.abs).mtime));
    const lfh = Buffer.alloc(30);
    lfh.writeUInt32LE(0x04034b50, 0); lfh.writeUInt16LE(20, 4); lfh.writeUInt16LE(0x0800, 6); // UTF-8 名字
    lfh.writeUInt16LE(0, 8); lfh.writeUInt16LE(dt, 10); lfh.writeUInt16LE(dd, 12); lfh.writeUInt32LE(c, 14);
    lfh.writeUInt32LE(buf.length, 18); lfh.writeUInt32LE(buf.length, 22); lfh.writeUInt16LE(nameBuf.length, 26);
    parts.push(lfh, nameBuf, buf);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8);
    ch.writeUInt16LE(dt, 12); ch.writeUInt16LE(dd, 14); ch.writeUInt32LE(c, 16);
    ch.writeUInt32LE(buf.length, 20); ch.writeUInt32LE(buf.length, 24);
    ch.writeUInt16LE(nameBuf.length, 28); ch.writeUInt32LE(offset, 42);
    central.push(Buffer.concat([ch, nameBuf]));
    offset += 30 + nameBuf.length + buf.length;
  }
  const cd = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(items.length, 8); end.writeUInt16LE(items.length, 10);
  end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, cd, end]);
}

export function backupAll(root) {
  const { items, total } = collect(root);
  if (!items.length) return { error: '还没有任何成品可备份（先出几单再来）' };
  const zip = buildZip(items);
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return { zip, name: `造纸局成品-${stamp}.zip`, count: items.length, bytes: total };
}

export function saveToDownloadsZip(zip, downloadName) {
  const dir = path.join(os.homedir(), 'Downloads');
  fs.mkdirSync(dir, { recursive: true });
  const { name, ext } = path.parse(downloadName);
  let dest = path.join(dir, downloadName);
  let n = 2;
  while (fs.existsSync(dest)) dest = path.join(dir, `${name} (${n++})${ext}`);
  fs.writeFileSync(dest, zip);
  return path.basename(dest);
}
