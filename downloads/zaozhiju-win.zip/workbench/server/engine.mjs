// 引擎适配层：任务队列 + claude 无头进程调度（收敛规则在 prompt 内置）
import { spawn, execSync } from 'node:child_process';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { TYPES, buildPrompt } from './types.mjs';
import { IS_WIN } from './paths.mjs';
import { loadTasks, saveTasks, flushTasks } from './store.mjs';
import { parallelCap } from './config.mjs';

const ROOT = path.resolve(import.meta.dirname, '..');
const TASK_DIR = path.join(ROOT, 'data', 'tasks');
const UPLOAD_DIR = path.join(ROOT, 'data', 'uploads');
export const capacity = () => parallelCap(); // 同时出单数:1-8,存 ~/.zaozhiju/config.json,改完即时生效(设置页可调)
const TIMEOUT_MS = (parseInt(process.env.ZAOZHIJU_TIMEOUT_MIN || '', 10) || 35) * 60 * 1000; // 文档类:25 分实测不够——素材保真工序(content.json→check-content→图表→复核对账)本身就多两轮机检(2026-11-08 一页纸 25 分被杀,产物 15:08 还在推进);且长文档类预估 30 分本来就被旧 25 分预算卡死,一并解开。ZAOZHIJU_TIMEOUT_MIN 仅供超时路径测试注入,平时不设=35 分(2026-11-08 验证优雅收尾分支用的隐藏钩子)
const VIDEO_TIMEOUT_MS = 90 * 60 * 1000; // 视频任务：实测 45 分不够（写稿~35 分+配音渲染~30 分），2026-11-05 上调
const XHS_TIMEOUT_MS = 45 * 60 * 1000; // 小红书图文/公众号封面：读技能参考+建站+playwright 渲染+两轮核查，25 分钟偏紧（2026-11-06）。Word 单也用这档：长文档排版 PDF 已近 30 分，再加烤图+pandoc 转换+校验（2026-11-08）
export const UPLOAD_MAX_BYTES = 20 * 1024 * 1024;
export const UPLOAD_EXT = new Set(['.md', '.markdown', '.txt', '.pdf', '.docx', '.html', '.htm', '.png', '.jpg', '.jpeg', '.webp']);
export const UPLOAD_MAX_FILES = 10; // 素材区≤5 + 配图区≤5

const tasks = loadTasks();
const children = new Map();

// —— 系统代理注入：浏览器里能打开的链接，引擎也读得到（macOS scutil，每分钟探测一次）——
let proxyCache = { at: 0, env: null };
function apiHosts() { // 模型 API 域名保持直连，代理挂了不殃及生成
  const hosts = ['127.0.0.1', 'localhost'];
  try {
    const s = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude', 'settings.json'), 'utf8'));
    const base = (s.env && s.env.ANTHROPIC_BASE_URL) || process.env.ANTHROPIC_BASE_URL;
    if (base) hosts.push(new URL(base).hostname);
  } catch { /* 读不到配置就用默认直连名单 */ }
  return hosts;
}
export function engineEnv() { // 导出给技能更新模块复用：界面进程发的网络请求也走系统代理
  if (Date.now() - proxyCache.at < 60000) return withToolBin(proxyCache.env || process.env);
  proxyCache.at = Date.now();
  let env = null;
  try {
    const out = execSync('scutil --proxy', { timeout: 3000 }).toString();
    const g = (k) => (out.match(new RegExp(`^\\s*${k}\\s*:\\s*(.+)$`, 'm')) || [])[1]?.trim();
    const host = g('HTTPSProxy'), port = g('HTTPSPort');
    if (g('HTTPSEnable') === '1' && host && port && /^\d+$/.test(port)) {
      execSync(`nc -z -G 2 ${host} ${port}`, { timeout: 4000 }); // 端口存活探测
      const proxy = `http://${host}:${port}`;
      const noProxy = [...new Set([
        ...apiHosts(),
        ...(process.env.NO_PROXY || '').split(',').map((h) => h.trim()).filter(Boolean),
      ])].join(',');
      env = { ...process.env,
        HTTP_PROXY: proxy, HTTPS_PROXY: proxy, ALL_PROXY: proxy,
        http_proxy: proxy, https_proxy: proxy, all_proxy: proxy,
        NO_PROXY: noProxy, no_proxy: noProxy };
    }
  } catch { env = null; } // 代理未开/探测失败：直连，任务照常跑
  proxyCache.env = env;
  return withToolBin(env || process.env);
}

// 手动装的工具二进制目录（2026-11-08: Word 管线需要的 pandoc 装在 ~/.zaozhiju/bin，免 sudo 免 brew），引擎与任务 shell 都能看见
const TOOL_BIN = path.join(os.homedir(), '.zaozhiju', 'bin');
function withToolBin(e) {
  const p = String(e.PATH || '');
  if (p.split(path.delimiter).includes(TOOL_BIN)) return e;
  return { ...e, PATH: p ? `${TOOL_BIN}${path.delimiter}${p}` : TOOL_BIN };
}

// —— 素材上传：先落盘，任务创建时引用 uid ——
export function saveUpload({ name, data } = {}) {
  const safe = String(name || '').replace(/[/\\\0]/g, '_').replace(/^\.+/, '').slice(0, 100);
  const ext = path.extname(safe).toLowerCase();
  if (!safe || !UPLOAD_EXT.has(ext)) throw new Error(`不支持的文件类型：${ext || safe}（支持 md/txt/pdf/docx/html/图片）`);
  let buf;
  try { buf = Buffer.from(String(data), 'base64'); } catch { throw new Error('文件内容无效'); }
  if (!buf.length) throw new Error('文件是空的');
  if (buf.length > UPLOAD_MAX_BYTES) throw new Error(`文件超过 ${UPLOAD_MAX_BYTES / 1024 / 1024}MB 限制`);
  const uid = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  fs.mkdirSync(path.join(UPLOAD_DIR, uid), { recursive: true });
  fs.writeFileSync(path.join(UPLOAD_DIR, uid, safe), buf);
  return { uid, name: safe, size: buf.length };
}

export function getTasks() { return tasks; }
export function findTask(id) { return tasks.find((t) => t.id === id) ?? null; }
export function typeById(id) { return TYPES.find((t) => t.id === id); }

export const CONTENT_MAX_CHARS = 200000;

export function createTask({ typeId, topic, requirements, links, uploads, content, crawl, accent, style, theme, voice, aspect, duration } = {}) {
  const type = typeById(typeId);
  if (!type) throw new Error(`未知类型: ${typeId}`);
  const cleanLinks = (Array.isArray(links) ? links : String(links || '').split(/\n+/))
    .map((s) => s.trim()).filter(Boolean).slice(0, 10);
  const cleanUploads = (Array.isArray(uploads) ? uploads : []).slice(0, UPLOAD_MAX_FILES);
  const t = String(topic || '').trim();
  const contentText = String(content || '').trim();
  const crawlMode = ['off', 'one', 'all'].includes(crawl) ? crawl : 'off';
  const accentHex = String(accent || '').trim().toLowerCase();
  const cleanAccent = /^#[0-9a-f]{6}$/.test(accentHex) ? accentHex : null; // 只认 #rrggbb,其余当没选
  const styleIds = (type.styleOpts || []).map((s) => s.v);
  const cleanStyle = styleIds.includes(style) ? style : null;
  const styleDef = (type.styleOpts || []).find((s) => s.v === cleanStyle);
  const themeVs = (styleDef?.themes || []).map((x) => x.v);
  const cleanTheme = themeVs.includes(theme) ? theme : null;
  const voiceVs = (type.voiceOpts || []).map((x) => x.v);
  const cleanVoice = voiceVs.includes(voice) ? voice : null;
  const aspectVs = (type.aspectOpts || []).map((x) => x.v);
  const cleanAspect = aspectVs.includes(aspect) ? aspect : null; // 只认该类型提供的画幅
  const durVs = (type.durationOpts || []).map((x) => x.v);
  const cleanDuration = durVs.includes(duration) ? duration : null;
  if (contentText.length > CONTENT_MAX_CHARS) throw new Error(`粘贴文本超过 ${CONTENT_MAX_CHARS / 10000} 万字，请精简或改用上传文件`);
  if (!t && !cleanLinks.length && !cleanUploads.length && !contentText) throw new Error('主题、链接、素材、文本至少给一个');
  for (const u of cleanUploads) {
    if (!u?.uid || !fs.existsSync(path.join(UPLOAD_DIR, u.uid))) throw new Error(`素材 ${u?.name || u?.uid} 不存在，请重新上传`);
  }
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const task = {
    id, typeId,
    topic: t,
    requirements: String(requirements || '').trim(),
    content: contentText,
    crawl: crawlMode,
    accent: cleanAccent,
    style: cleanStyle,
    theme: cleanTheme,
    voice: cleanVoice,
    aspect: cleanAspect,
    duration: cleanDuration,
    links: cleanLinks,
    uploads: cleanUploads.map((u) => ({ uid: u.uid, name: String(u.name || '').replace(/[/\\]/g, '_'), note: String(u.note || '').slice(0, 200) })),
    status: 'queued',
    createdAt: new Date().toISOString(),
    startedAt: null, finishedAt: null,
    pid: null, outputFile: null, error: null,
  };
  tasks.push(task);
  persist();
  queueSoon();
  return task;
}

export function cancelTask(id) {
  const task = findTask(id);
  if (!task) return null;
  if (task.status === 'queued') {
    task.status = 'cancelled';
    task.finishedAt = new Date().toISOString();
    persist();
    return task;
  }
  if (task.status === 'running') { killChild(id, 'cancelled', '手动取消'); return task; }
  return task;
}

export function taskPaths(task) {
  const type = typeById(task.typeId);
  return { dir: path.join(TASK_DIR, task.id), kind: type?.kind ?? 'pdf' };
}

let tickTimer = null;
function persist() { saveTasks(tasks); }
function queueSoon() {
  if (tickTimer) return;
  tickTimer = setTimeout(() => { tickTimer = null; tick(); }, 200);
}

function tick() {
  const cap = parallelCap();
  const running = tasks.filter((t) => t.status === 'running').length;
  if (running >= cap) return;
  const queued = tasks.filter((t) => t.status === 'queued').slice(0, cap - running);
  for (const task of queued) launch(task);
}
setInterval(tick, 2500);

// 字体预放(2026-11-08):商业字体是固定字节,缓存里有就直接硬链进任务目录,模型省掉"想起这步+搬运"的一整轮;
// 缓存没有(新机器首启前)就啥也不做——和现在行为一致,无回退风险。文件内容与模型自己下的完全相同。
function stageFonts(dir) {
  const src = path.join(os.homedir(), '.local', 'share', 'fonts', 'kami');
  let files;
  try { files = fs.readdirSync(src).filter((f) => /\.(ttf|otf)$/i.test(f)); } catch { return; }
  if (!files.length) return;
  const dst = path.join(dir, 'fonts');
  try { fs.mkdirSync(dst, { recursive: true }); } catch { return; }
  for (const f of files) {
    const d = path.join(dst, f);
    if (fs.existsSync(d)) continue;
    try { fs.linkSync(path.join(src, f), d); }
    catch { try { fs.copyFileSync(path.join(src, f), d); } catch { /* 跨盘失败就算了,模型会自己搞定 */ } }
  }
}

function launch(task) {
  const type = typeById(task.typeId);
  const dir = path.join(TASK_DIR, task.id);
  fs.mkdirSync(dir, { recursive: true });
  if (type.kind === 'pdf') { try { stageFonts(dir); } catch { /* 预放失败不拦任务 */ } }
  const inputFiles = [];
  for (const u of task.uploads || []) {
    try {
      const src = path.join(UPLOAD_DIR, u.uid, u.name);
      fs.mkdirSync(path.join(dir, 'input'), { recursive: true });
      fs.copyFileSync(src, path.join(dir, 'input', u.name));
      inputFiles.push({ name: u.name, note: u.note });
    } catch { /* 单个素材复制失败不拦任务 */ }
  }
  const prompt = buildPrompt(type, task.topic, task.requirements, { links: task.links, inputFiles, text: task.content, crawl: task.crawl, accent: task.accent, style: task.style, theme: task.theme, voice: task.voice, aspect: task.aspect, duration: task.duration });
  fs.writeFileSync(path.join(dir, 'prompt.txt'), prompt);
  task.status = 'running';
  task.startedAt = new Date().toISOString();
  persist();

  let child;
  try {
    // Windows 上 npm 全局装的是 claude.cmd（Node 禁直接 spawn .cmd），必须走 shell 让 PATHEXT 解析；参数全是无空格 token，安全
    child = spawn('claude',
      ['-p', '--model', 'claude-sonnet-5', '--allowedTools', 'WebFetch,Bash,Read,Write,Edit'],
      { cwd: dir, env: engineEnv(), shell: IS_WIN, windowsHide: true });
  } catch (err) {
    fail(task, `引擎启动失败: ${err.message}`);
    return;
  }

  const log = fs.createWriteStream(path.join(dir, 'result.txt'), { flags: 'w' });
  children.set(task.id, { child, log });
  task.pid = child.pid;
  persist();

  child.stdin.on('error', () => {});
  child.stdin.write(prompt);
  child.stdin.end();
  child.stdout.pipe(log);
  child.stderr.pipe(log);
  child.on('error', (err) => fail(task, `引擎进程错误: ${err.message}`));

  const budget = type?.kind === 'video' ? VIDEO_TIMEOUT_MS : (type?.out === 'xhs' || type?.out === 'wxcover' || type?.out === 'docx') ? XHS_TIMEOUT_MS : TIMEOUT_MS;
  const killer = setTimeout(() => {
    if (children.has(task.id)) killChild(task.id, 'timeout', `超过 ${budget / 60000} 分钟未完成，已强制终止（可重试）`);
  }, budget);

  child.on('close', (code) => {
    clearTimeout(killer);
    children.delete(task.id);
    log.end();
    if (task.status !== 'running') { persist(); return; }
    const out = findOutput(dir, type.kind);
    if (out) {
      task.status = 'done';
      task.outputFile = out;
      scanExtras(task);
    } else {
      task.status = 'failed';
      task.error = `进程退出(code ${code})但未生成最终产物（期望 ${type.kind === 'pdf' ? 'output.pdf' : type.kind === 'docx' ? 'output.docx' : type.kind === 'video' ? 'output.mp4' : 'output/index.html'}）。可点重试，或看 result.txt 排查`;
      scanDepFail(task);
    }
    task.finishedAt = new Date().toISOString();
    persist();
    if (task.status === 'done') notifyTask('造纸局 · 出炉了', `《${task.topic}》可以收活了`);
    else notifyTask('造纸局 · 这单失败了', `《${task.topic}》：${task.error || ''}`);
    queueSoon();
  });
}

function killChild(id, status, reason) {
  const c = children.get(id);
  const task = findTask(id);
  if (status === 'timeout' && c && task) {
    // 优雅收尾(2026-11-08):到点了但产物早已生成且 20 秒没再改动→按正常进程退出的同一标准(findOutput)判完成,不扔成品。
    // 判定逻辑零新增标准:平时 close 事件就是这么放行成品的,这里只是不让计时器把好端端的产出误杀(一页纸那次 25 分被杀,产物 15:08 还在,白重跑)。
    const type = typeById(task.typeId);
    const dir = path.join(TASK_DIR, task.id);
    const out = type && findOutput(dir, type.kind);
    let stable = false;
    try { stable = !!out && Date.now() - fs.statSync(path.join(dir, out)).mtimeMs > 20000; } catch { /* 读不到就按没完成 */ }
    if (out && stable) {
      children.delete(id);
      try { c.log.end(); } catch { /* 已关 */ }
      try { c.child.kill('SIGKILL'); } catch { /* 已退 */ }
      task.status = 'done';
      task.outputFile = out;
      scanExtras(task);
      task.finishedAt = new Date().toISOString();
      persist();
      notifyTask('造纸局 · 出炉了', `《${task.topic}》(比预估慢,但成品已齐,照常放行)`);
      queueSoon();
      return;
    }
  }
  if (c) { try { c.child.kill('SIGKILL'); } catch {} }
  if (task && task.status === 'running') {
    task.status = status;
    task.error = reason;
    task.finishedAt = new Date().toISOString();
    persist();
    if (status === 'timeout') notifyTask('造纸局 · 出单超时', `《${task.topic}》${reason}`); // 手动取消不弹
  }
  queueSoon();
}

function fail(task, msg) {
  task.status = 'failed';
  task.error = msg;
  task.finishedAt = new Date().toISOString();
  scanDepFail(task);
  persist();
  notifyTask('造纸局 · 这单失败了', `《${task.topic}》：${msg}`);
  queueSoon();
}

// 成品页附属件标记（2026-11-08）：质检单 qc.txt 与小红书发帖文案——文件在才显示对应按钮，旧任务没写过就不显示
function scanExtras(task) {
  try {
    const { dir } = taskPaths(task);
    task.hasQc = fs.existsSync(path.join(dir, 'qc.txt'));
    task.hasCopy = task.typeId === 'xhs' && fs.existsSync(path.join(dir, 'output', '发帖文案.txt'));
  } catch { /* 探不到就当没有，不影响完成状态 */ }
}

// 缺依赖型失败标记（2026-11-09）：result.txt/错误里出现缺件字样→任务卡给「一键补依赖」入口，失败不再是死字
function scanDepFail(task) {
  try {
    const { dir } = taskPaths(task);
    let txt = '';
    try { txt = fs.readFileSync(path.join(dir, 'result.txt'), 'utf8').slice(-4000); } catch { /* 没结果文件就没标记 */ }
    const all = txt + '\n' + String(task.error || '');
    task.depFail = /缺(?:少)?\s*pandoc|没有\s*pandoc|pandoc\s*(不可用|未就位|下载失败)|缺(?:少)?\s*ffmpeg|缺(?:少)?\s*python|缺(?:少)?\s*技能|未安装|playwright|chromium|pip install/i.test(all);
  } catch { /* 探不到当不缺 */ }
}

// 系统级通知:人不在屏幕前也知道出单了。弹不出去就算了,绝不影响队列。
function notifyTask(title, body) {
  const scrub = (s) => String(s || '').replace(/[`$"'\\《》]/g, '').slice(0, 70);
  try {
    if (IS_WIN) {
      const ps = `Add-Type -AssemblyName System.Windows.Forms;$ni=New-Object System.Windows.Forms.NotifyIcon;$ni.Icon=[System.Drawing.SystemIcons]::Information;$ni.Visible=$true;$ni.ShowBalloonTip(5000,'${scrub(title)}','${scrub(body)}','Info');Start-Sleep -Seconds 4;$ni.Visible=$false;$ni.Dispose()`;
      spawn('powershell', ['-NoProfile', '-Command', ps], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    } else {
      spawn('osascript', ['-e', `display notification "${scrub(body)}" with title "${scrub(title)}"`], { detached: true, stdio: 'ignore' }).unref();
    }
  } catch { /* 没通知就没通知 */ }
}

function findOutput(dir, kind) {
  if (kind === 'pdf') {
    const p = path.join(dir, 'output.pdf');
    return fs.existsSync(p) && fs.statSync(p).size > 1024 ? 'output.pdf' : null;
  }
  if (kind === 'pptx') {
    const p = path.join(dir, 'output.pptx');
    return fs.existsSync(p) && fs.statSync(p).size > 2048 ? 'output.pptx' : null;
  }
  if (kind === 'docx') {
    const p = path.join(dir, 'output.docx');
    return fs.existsSync(p) && fs.statSync(p).size > 2048 ? 'output.docx' : null;
  }
  if (kind === 'video') {
    const p = path.join(dir, 'output.mp4');
    return fs.existsSync(p) && fs.statSync(p).size > 100 * 1024 ? 'output.mp4' : null;
  }
  const p = path.join(dir, 'output', 'index.html');
  return fs.existsSync(p) ? 'output/index.html' : null;
}

// 服务重启后的状态恢复：上一轮 running 的进程已不存在
export function boot() {
  for (const task of tasks) {
    if (task.status !== 'running') continue;
    const { dir } = taskPaths(task);
    const type = typeById(task.typeId);
    const out = findOutput(dir, type.kind);
    if (out) { task.status = 'done'; task.outputFile = out; scanExtras(task); }
    else { task.status = 'failed'; task.error = '服务重启，任务被中断（可重试）'; }
    task.finishedAt = task.finishedAt || new Date().toISOString();
  }
  flushTasks(tasks);
  queueSoon();
}

export function deleteTask(id) {
  const idx = tasks.findIndex((t) => t.id === id);
  if (idx < 0) return { error: '任务不存在', code: 404 };
  const task = tasks[idx];
  if (task.status === 'queued' || task.status === 'running') return { error: '任务进行中，请先取消', code: 409 };
  tasks.splice(idx, 1);
  try { fs.rmSync(path.join(TASK_DIR, id), { recursive: true, force: true }); } catch { /* 目录删不掉不拦状态 */ }
  persist();
  return { deleted: id };
}

export function retryTask(id) {
  const task = findTask(id);
  if (!task) return null;
  if (task.status === 'running') return task;
  // 把旧产物挪进 prev-<ts>/，否则 agent 会对着现成的 output.pdf 走"核验即通过"，而不是真重做
  const { dir } = taskPaths(task);
  try {
    const prev = path.join(dir, `prev-${Date.now()}`);
    fs.mkdirSync(prev, { recursive: true });
    if (fs.existsSync(path.join(dir, 'output.docx'))) {
      fs.renameSync(path.join(dir, 'output.docx'), path.join(prev, 'output.docx'));
      for (const aux of ['output.pdf', 'document-for-word.html']) { try { if (fs.existsSync(path.join(dir, aux))) fs.renameSync(path.join(dir, aux), path.join(prev, aux)); } catch { /* 挪不动不拦 */ } }
    } else if (fs.existsSync(path.join(dir, 'output.pdf'))) {
      fs.renameSync(path.join(dir, 'output.pdf'), path.join(prev, 'output.pdf'));
      for (const aux of ['review.pdf']) { try { if (fs.existsSync(path.join(dir, aux))) fs.renameSync(path.join(dir, aux), path.join(prev, aux)); } catch { /* 挪不动不拦 */ } }
    } else if (fs.existsSync(path.join(dir, 'output.pptx'))) {
      fs.renameSync(path.join(dir, 'output.pptx'), path.join(prev, 'output.pptx'));
      if (fs.existsSync(path.join(dir, 'review.pdf'))) fs.renameSync(path.join(dir, 'review.pdf'), path.join(prev, 'review.pdf'));
    } else if (fs.existsSync(path.join(dir, 'output.mp4'))) {
      fs.renameSync(path.join(dir, 'output.mp4'), path.join(prev, 'output.mp4'));
      if (fs.existsSync(path.join(dir, 'cover.png'))) fs.renameSync(path.join(dir, 'cover.png'), path.join(prev, 'cover.png'));
    } else if (fs.existsSync(path.join(dir, 'output'))) {
      fs.renameSync(path.join(dir, 'output'), path.join(prev, 'output'));
    }
    // 质检单全类型通用：上面无论走了哪个分支都一并挪档，否则重试单会把旧质检当新结论
    if (fs.existsSync(path.join(dir, 'qc.txt'))) fs.renameSync(path.join(dir, 'qc.txt'), path.join(prev, 'qc.txt'));
  } catch { /* 挪不动不拦重试，大不了复跑核验 */ }
  task.status = 'queued';
  task.error = null;
  task.outputFile = null;
  task.startedAt = null;
  task.finishedAt = null;
  persist();
  queueSoon();
  return task;
}
