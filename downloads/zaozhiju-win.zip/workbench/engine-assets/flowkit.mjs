// flowkit — 造纸局「艺术流程图」画具包（ESM）
// 复刻 statechart-art 的画风：纸纹底 + 钢笔抖动勾线 + 彩铅涂抹 + 小票化状态
// 用法(任务目录里写 draw.mjs): import kit from '/Users/yang/Desktop/kami/workbench/engine-assets/flowkit.mjs'
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FONT = path.join(__dirname, 'fonts', 'LXGWWenKai-Regular.ttf');
let fontReady = false;

// —— 调色（与 statechart-art / kami 同调）——
const INK = '#1c2a24';      // 钢笔墨
const PAPER = '#f2ecdd';    // 纸
const BLUE = '#4b96aa';     // 主彩铅：蓝绿
const RED = '#c0392b';      // 批注红铅
const AMBER = '#e0a458';    // 琥珀
const GREEN = '#6a9955';    // 草绿
const MUT = '#5d6a5e';      // 铅笔灰

// —— 确定性随机（同一 seed 画同一张图）——
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// —— 画布 ——
function create(opts = {}) {
  const size = opts.size || 2160;
  const seed = opts.seed || 7;
  if (!fontReady) { GlobalFonts.registerFromPath(FONT, 'LXGW WenKai'); fontReady = true; }
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  const r = mulberry32(seed);
  // 纸底
  ctx.fillStyle = PAPER; ctx.fillRect(0, 0, size, size);
  // 纸纹：稀疏纤维点
  for (let i = 0; i < size * 3; i++) {
    ctx.fillStyle = r() > 0.5 ? 'rgba(120,110,90,0.035)' : 'rgba(255,252,240,0.05)';
    const x = r() * size, y = r() * size, w = 1 + r() * 8, h = 0.6 + r() * 1.4;
    ctx.fillRect(x, y, w, h);
  }
  // 四角轻微做旧
  const g = ctx.createRadialGradient(size / 2, size / 2, size * 0.42, size / 2, size / 2, size * 0.78);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(90,80,60,0.06)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
  return { canvas, ctx, size, r };
}

// —— 钢笔线：中点抖动，双遍描 ——
function penLine(ctx, r, x1, y1, x2, y2, o = {}) {
  const w = o.w || 5, color = o.color || INK, passes = o.passes || 2;
  const amp = o.wobble == null ? Math.max(2.5, w * 0.55) : o.wobble;
  const len = Math.hypot(x2 - x1, y2 - y1);
  const segs = Math.max(4, Math.round(len / 46));
  for (let p = 0; p < passes; p++) {
    ctx.strokeStyle = color;
    ctx.globalAlpha = p === 0 ? 0.9 : 0.35;
    ctx.lineWidth = p === 0 ? w : w * 0.6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    let x = x1 + (r() - 0.5) * amp, y = y1 + (r() - 0.5) * amp;
    ctx.moveTo(x, y);
    for (let i = 1; i <= segs; i++) {
      const t = i / segs;
      let nx = x1 + (x2 - x1) * t + (r() - 0.5) * amp * 2;
      let ny = y1 + (y2 - y1) * t + (r() - 0.5) * amp * 2;
      if (i === segs) { nx = x2 + (r() - 0.5) * amp * 0.6; ny = y2 + (r() - 0.5) * amp * 0.6; }
      ctx.lineTo(nx, ny);
      x = nx; y = ny;
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

// —— 钢笔折线路径（多点）——
function penPath(ctx, r, pts, o = {}) {
  for (let i = 0; i < pts.length - 1; i++) penLine(ctx, r, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], o);
}

// —— 彩铅涂抹：矩形内斜向平行短排线 ——
function pencilFill(ctx, r, x, y, w, h, o = {}) {
  const color = o.color || BLUE, angle = o.angle == null ? -0.6 : o.angle;
  const gap = o.gap || 18, alpha = o.alpha == null ? 0.16 : o.alpha;
  ctx.save();
  ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
  ctx.strokeStyle = color; ctx.lineCap = 'round';
  const cos = Math.cos(angle), sin = Math.sin(angle);
  const diag = Math.hypot(w, h);
  const cx = x + w / 2, cy = y + h / 2;
  for (let d = -diag / 2; d < diag / 2; d += gap) {
    ctx.globalAlpha = alpha * (0.55 + r() * 0.9);
    ctx.lineWidth = 5 + r() * 5;
    const px = cx + (-sin) * d, py = cy + cos * d; // 排线中心点
    const halfLen = diag; // 足够长，靠 clip 裁
    ctx.beginPath();
    const n = 10;
    for (let i = 0; i <= n; i++) {
      const t = -halfLen + (2 * halfLen * i) / n;
      const sx = px + cos * t + (r() - 0.5) * 5;
      const sy = py + sin * t + (r() - 0.5) * 5;
      i === 0 ? ctx.moveTo(sx, sy) : ctx.lineTo(sx, sy);
    }
    ctx.stroke();
  }
  ctx.restore();
  ctx.globalAlpha = 1;
}

// —— 手写矩形（四边抖动）——
function penRect(ctx, r, x, y, w, h, o = {}) {
  penLine(ctx, r, x, y, x + w, y, o);
  penLine(ctx, r, x + w, y, x + w, y + h, o);
  penLine(ctx, r, x + w, y + h, x, y + h, o);
  penLine(ctx, r, x, y + h, x, y, o);
}

// —— 文字（自动换行）——
function text(ctx, r, str, x, y, o = {}) {
  const size = o.size || 44, color = o.color || INK;
  ctx.font = `${o.weight || ''} ${size}px "LXGW WenKai"`.trim();
  ctx.fillStyle = color; ctx.textBaseline = 'top'; ctx.textAlign = o.align || 'left';
  const maxW = o.maxW || 0;
  let lines = [str];
  if (maxW) {
    lines = []; let cur = '';
    for (const ch of str) {
      if (ctx.measureText(cur + ch).width > maxW) { lines.push(cur); cur = ch; } else cur += ch;
    }
    if (cur) lines.push(cur);
  }
  const lh = size * (o.lineH || 1.25);
  lines.forEach((ln, i) => {
    ctx.save();
    ctx.translate(x, y + i * lh);
    if (o.jitter) ctx.rotate((r() - 0.5) * 0.012);
    ctx.fillText(ln, 0, 0);
    ctx.restore();
  });
  return lines.length * lh;
}

// —— 标题 + 波浪下划线 + 小字副题 ——
function title(ctx, r, x, y, main, o = {}) {
  const size = o.size || 96;
  const h = text(ctx, r, main, x, y, { size, color: INK, jitter: true });
  const w = (() => { ctx.font = `${size}px "LXGW WenKai"`; return ctx.measureText(main).width; })();
  penLine(ctx, r, x, y + size * 1.22, x + w, y + size * 1.22, { w: 6, color: o.underline || BLUE, wobble: 6 });
  if (o.sub) text(ctx, r, o.sub, x, y + size * 1.45, { size: size * 0.32, color: MUT, jitter: true });
  return h;
}

// —— 状态小票：圆角矩形 + 彩铅涂 + 墨框 + 字 ——
// box = {x,y,w,h,label,sub,color}
function ticket(ctx, r, box, o = {}) {
  const { x, y, w, h } = box;
  const color = box.color || BLUE;
  // 影：右下一道浅铅笔
  pencilFill(ctx, r, x + 10, y + 12, w, h, { color: '#8a8577', alpha: 0.10, gap: 26 });
  // 底涂
  pencilFill(ctx, r, x + 6, y + 6, w - 12, h - 12, { color, alpha: o.fillAlpha || 0.18, gap: o.gap || 20 });
  // 框
  penRect(ctx, r, x, y, w, h, { w: o.pen || 6, color: INK, wobble: o.wobble == null ? 4 : o.wobble });
  // 顶部“撕票线”虚线（可选）
  if (box.tab) penLine(ctx, r, x + 14, y + h * 0.26, x + w - 14, y + h * 0.26, { w: 3, color: MUT, wobble: 2 });
  const pad = Math.max(18, w * 0.06);
  text(ctx, r, box.label, x + w / 2, y + (box.tab ? h * 0.34 : h * 0.24), {
    size: box.labelSize || Math.min(52, (w - pad * 2) / Math.max(2, box.label.length) * 1.6),
    color: INK, align: 'center', maxW: w - pad * 2, jitter: true,
  });
  if (box.sub) text(ctx, r, box.sub, x + w / 2, y + h * 0.62, {
    size: 30, color: MUT, align: 'center', maxW: w - pad * 2, jitter: true,
  });
  if (box.note) text(ctx, r, box.note, x + w / 2, y + h - 58, {
    size: 26, color, align: 'center', maxW: w - pad, jitter: true,
  });
}

// —— 箭头：二次曲线抖动 + 开口 V 头；from/to=[x,y]，bend 弧度 ——
function arrow(ctx, r, from, to, o = {}) {
  const color = o.color || INK, bend = o.bend == null ? 0.12 : o.bend;
  const mx = (from[0] + to[0]) / 2, my = (from[1] + to[1]) / 2;
  const dx = to[0] - from[0], dy = to[1] - from[1];
  const cx = mx - dy * bend, cy = my + dx * bend;
  const segs = 14, wob = 3.5;
  for (const p of [0, 1]) { // 双遍
    ctx.strokeStyle = color; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.globalAlpha = p === 0 ? 0.92 : 0.3; ctx.lineWidth = p === 0 ? (o.w || 6) : (o.w || 6) * 0.55;
    ctx.beginPath();
    for (let i = 0; i <= segs; i++) {
      const t = i / segs, u = 1 - t;
      let x = u * u * from[0] + 2 * u * t * cx + t * t * to[0];
      let y = u * u * from[1] + 2 * u * t * cy + t * t * to[1];
      if (i > 0 && i < segs) { x += (r() - 0.5) * wob * 2; y += (r() - 0.5) * wob * 2; }
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  // 箭头头（沿曲线末段切线）
  const t2 = 0.93, u2 = 1 - t2;
  const px = u2 * u2 * from[0] + 2 * u2 * t2 * cx + t2 * t2 * to[0];
  const py = u2 * u2 * from[1] + 2 * u2 * t2 * cy + t2 * t2 * to[1];
  const ang = Math.atan2(to[1] - py, to[0] - px);
  const hl = o.head || 34;
  penLine(ctx, r, to[0], to[1], to[0] - hl * Math.cos(ang - 0.42), to[1] - hl * Math.sin(ang - 0.42), { w: o.w || 6, color, wobble: 2 });
  penLine(ctx, r, to[0], to[1], to[0] - hl * Math.cos(ang + 0.42), to[1] - hl * Math.sin(ang + 0.42), { w: o.w || 6, color, wobble: 2 });
  if (o.label) {
    const lm = { x: 0.25 * from[0] + 0.5 * cx + 0.25 * to[0], y: 0.25 * from[1] + 0.5 * cy + 0.25 * to[1] };
    text(ctx, r, o.label, lm.x, lm.y - 22, { size: o.labelSize || 30, color: o.labelColor || MUT, align: 'center', jitter: true });
  }
}

// —— 红铅笔批注（圈一圈 + 短句）——
function annotate(ctx, r, x, y, w, h, str) {
  const cx = x + w / 2, cy = y + h / 2, rx = w / 2 + 18, ry = h / 2 + 16;
  ctx.strokeStyle = RED; ctx.lineCap = 'round'; ctx.lineWidth = 5;
  for (let pass = 0; pass < 2; pass++) {
    ctx.globalAlpha = pass ? 0.35 : 0.85;
    ctx.beginPath();
    for (let i = 0; i <= 26; i++) {
      const a = (i / 26) * Math.PI * 2.12 - 0.5;
      const wob = 1 + (r() - 0.5) * 0.06;
      const px = cx + Math.cos(a) * rx * wob, py = cy + Math.sin(a) * ry * wob;
      i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
  if (str) text(ctx, r, str, x + w + 30, cy - 20, { size: 32, color: RED, jitter: true });
}

// —— 角落落款（日期 + 印章方框）——
function credit(ctx, r, size, o = {}) {
  text(ctx, r, o.str || '造纸局 · 艺术流程图', 72, size - 118, { size: 34, color: MUT, jitter: true });
  const s = 88, x = size - s - 72, y = size - s - 86;
  penRect(ctx, r, x, y, s, s, { w: 6, color: RED, wobble: 4 });
  text(ctx, r, o.stamp || '造紙', x + s / 2, y + 16, { size: 34, color: RED, align: 'center', jitter: true });
  penLine(ctx, r, x + s * 0.5, y + 8, x + s * 0.5, y + s - 8, { w: 3, color: RED, wobble: 3 });
  text(ctx, r, o.stamp2 || '局·印', x + s / 2, y + s / 2 + 4, { size: 34, color: RED, align: 'center', jitter: true });
}

// —— 存图 ——
function save(canvas, outPath) {
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, canvas.toBuffer('image/png'));
  return outPath;
}

const colors = { INK, PAPER, BLUE, RED, AMBER, GREEN, MUT };
export default { create, penLine, penPath, penRect, pencilFill, text, title, ticket, arrow, annotate, credit, save, colors, FONT };
