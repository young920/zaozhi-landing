'use strict'
// sca 适配层 —— 造纸局「艺术流程图」管线
// 底层是 kevintngo/statechart-art 的原版画具（MIT，见 LICENSE / ATTRIBUTION.md）：
// 纸纹、铅笔颗粒、钢笔抖动、小票+红绳图表、小人、店铺道具，全部是他们自己的代码。
// 本文件只做两件事：①注册中文楷体（LXGW WenKai）让 letter.write 用牙齿纹理落墨；
// ②flow() 用毫米坐标手工布图（不依赖 pele），让流程小票和场景画共存一张纸。
// 用法示例见 server/types.mjs 的 FLOWART_OUT。

const path = require('path')
const fs = require('fs')
const { GlobalFonts } = require('@napi-rs/canvas')
const SB = require('./lib/storybook')
const { layOut, mapper, contentBox } = require('./lib/layout')
const TC = require('./lib/tagchart')
const D = require('./lib/draw')
const Lt = require('./lib/letter')
const { person, POSES } = require('./lib/people')
const H = require('./scene')

const CN = 'LXGW WenKai'
GlobalFonts.registerFromPath(path.join(__dirname, '..', 'fonts', 'LXGWWenKai-Regular.ttf'), CN)

const PINS = ['#cf4e43', '#3f7fae', '#e0b04f', '#6f9a5c']

const CJK = /[\u2E80-\u303F\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uFF00-\uFFEF]/

// 216×216mm 热压水彩纸，ppm=10 → 2160px。坐标一律毫米，y 向下。
function plate(o = {}) {
  const seed = o.seed ?? 1
  const P = SB.plate({ w: 216, h: 216, ppm: 10, paper: 'hotpress', ...o, seed: 'kami-' + seed })
  // 道具库里 P.label 默认 Kevin 字体，遇到中文自动换楷体（否则画出来是豆腐块）
  const lb = P.label
  P.label = (t, x, y, o2 = {}) => lb(t, x, y, { face: CJK.test(t) ? CN : 'serif-bold', ...o2 })
  return P
}

// 左上标题区（和样张同款层级：小字眉题 / 大字标题 / 斜体副题）
function title(P, t, o = {}) {
  P.text(o.kicker || '造纸局 · 艺术流程图', 12.5, 13.6, { face: CN, size: o.kickerSize ?? 3.6 })
  P.text(t, 11, 30, { face: CN, size: o.size ?? 13 })
  if (o.sub) P.italic(o.sub, 12.5, 39.6, { face: CN, size: 4.4 })
}

// 通用中文文字（x 为左端，align:'center'/'right' 可选；size 毫米）
const text = (P, t, x, y, o = {}) => P.text(t, x, y, { face: CN, size: 4, ...o })

// 从票盒中心朝目标点方向，求射线与盒边（含少量出血）的交点
function anchor(n, ox, oy) {
  const dx = ox - n.cx, dy = oy - n.cy
  if (!dx && !dy) return [n.cx, n.cy]
  const hw = n.w / 2 + 1.2, hh = n.h / 2 + 1.4
  const t = Math.min(dx ? hw / Math.abs(dx) : Infinity, dy ? hh / Math.abs(dy) : Infinity)
  return [n.cx + dx * t, n.cy + dy * t]
}

// 手工流程图布局：nodes[{id,x,y,w=30,h=14,label,sub,no,pin,classes}]（x,y=中心）
// edges[{from,to,label,bug,via:[[x,y]..弯曲控制点],pts}]；starts[{x,y,to}]
// 返回 {L, m}，直接喂 tickets()。
function flow(spec) {
  const nodes = (spec.nodes || []).map((n, i) => ({
    id: n.id ?? 'n' + i, cx: n.x, cy: n.y, w: n.w ?? 30, h: n.h ?? 14, rx: 0,
    lines: (n.lines ?? (n.sub ? [n.label, n.sub] : [n.label])).filter(Boolean).map((t) => ({ text: t })),
    classes: n.classes || [], no: n.no, pin: n.pin,
  }))
  const byId = new Map(nodes.map((n) => [n.id, n]))
  const edges = [], labels = []
  const label = (edge, pt, t) => labels.push({ edge, x: pt[0], y: pt[1], w: 10, h: 4, lines: String(t).split('\n').map((s) => ({ text: s, x: pt[0], y: pt[1] })) })
  ;(spec.edges || []).forEach((e, i) => {
    const id = e.id ?? 'e' + i
    const a = byId.get(e.from), b = byId.get(e.to)
    let pts = e.pts
    if (!pts) {
      const outDir = e.via ? e.via[0] : [b ? b.cx : e.toX, b ? b.cy : e.toY]
      const inDir = e.via ? e.via[e.via.length - 1] : [a ? a.cx : e.fromX, a ? a.cy : e.fromY]
      const pa = a ? anchor(a, outDir[0], outDir[1]) : outDir
      const pb = b ? anchor(b, inDir[0], inDir[1]) : inDir
      pts = e.via && e.via.length ? D.curve([pa, ...e.via, pb], false, 0.35) : [pa, pb]
    }
    edges.push({ id, from: e.from, to: e.to, pts, bug: !!e.bug })
    if (e.label != null && e.label !== '') label(id, pts[Math.floor((pts.length - 1) / 2)], e.label)
  })
  const starts = (spec.starts || []).map((s, i) => {
    if (s.to && byId.has(s.to)) {
      const n = byId.get(s.to)
      edges.push({ id: 'se' + i, from: null, to: s.to, pts: [[s.x, s.y], anchor(n, s.x, s.y)] })
      if (s.label) label('se' + i, [s.x + 2.5, s.y - 2.5], s.label)
    }
    return { id: 's' + i, cx: s.x, cy: s.y, r: s.r ?? 1.1 }
  })
  const L = { nodes, edges, labels, starts, clusters: [], dividers: [] }
  return { L, m: { k: 1, P: (p) => [p[0], p[1]], X: (v) => v, Y: (v) => v } }
}

// 画红绳小票图。o.face 已是中文；票上文字自动加宽盒体适配。
// o 可覆盖任意 tagchart 选项（stateSize/labelSize/numbers/bugColor…）。
function tickets(P, F, o = {}) {
  return TC.draw(P, F.L, F.m, {
    style: 'ticket', labelsBeside: true, stopShort: 3.2, bounds: { x0: 5, x1: 211 },
    lineColor: '#a8443b', startColor: '#a8443b', condColour: '#b5453a',
    face: CN, labelFace: CN, stateSize: 4.3, labelSize: 3.3,
    pinColor: (n) => PINS[((n.pin ?? 0) + Math.round(Math.abs(n.cy))) % PINS.length],
    numbers: (n) => (n.no ? String(n.no) : ''),
    ...o,
  })
}

// 胶带便签卡（贴在场边的小纸条）
function note(P, o) {
  const x = o.x, y = o.y, w = o.w ?? 26, h = o.h ?? 16, R = P.R
  const tilt = R.range(-0.035, 0.035)
  const box = [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]]
  const shape = D.tf(box, { x, y, rot: tilt })
  P.hatch([D.tf(shape, { x: 0.9, y: 1.1 })], { cut: [shape], angle: 45, pitch: 0.45, nib: 0.09, color: '#4d4448' })
  P.paper([shape])
  P.colour([shape], o.color || '#fbf3dc', { pressure: 0.5, passes: 1 })
  P.outline([shape], { nib: 0.27 })
  for (const [tx, ty, ta] of [[x - w / 2 + 1.2, y - h / 2 + 0.4, -0.6], [x + w / 2 - 1.2, y - h / 2 + 0.4, 0.6]]) {
    const tape = D.tf(D.rrect(-2.2, -0.9, 2.2, 0.9, 0.2), { x: tx, y: ty, rot: ta + tilt })
    P.paper([tape]); P.colour([tape], '#e9e1c4', { pressure: 0.5, passes: 1 }); P.outline([tape], { nib: 0.09 })
  }
  Lt.block(P.S, o.lines || [], x, y + 0.4, { face: CN, size: o.size ?? 3.4, color: P.INK, lineGap: 1.25 })
}

// 出图：output/art.png（原尺寸）+ output/preview.png（1080）
async function finish(P, dir = './output') {
  fs.mkdirSync(dir, { recursive: true })
  const out = await P.finish(path.join(dir, 'art.png'), { sizes: [['-preview.png', 1080]] })
  fs.copyFileSync(out.replace(/\.png$/, '-preview.png'), path.join(dir, 'preview.png'))
  return out
}

module.exports = { CN, PINS, plate, title, text, note, flow, tickets, finish, person, POSES, H, C: H.C, SOFT: SB.SOFT, D, Lt, TC, layOut, mapper, contentBox }
