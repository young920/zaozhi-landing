# 来源与授权

`kit/`、`lib/`、`fonts/`、`scene.js` 复制自 https://github.com/kevintngo/statechart-art （MIT License，见同目录 LICENSE）。
Kevin Serif / Kevin Sans 字体随仓库一同 MIT 授权。

复制时仅做了一处改动：`scene.js`（原 business/art/shop.js）的 require 路径。
`index.js` 是我们写的中文适配层：注册 LXGW WenKai（SIL OFL，在 ../fonts/），
提供 `flow()/tickets()` 直接按毫米坐标布图，替代 pele 自动布局，让流程小票和场景道具可以共存于同一张纸。
