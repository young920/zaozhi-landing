# 造纸局 Windows 首启：检测缺啥 → 弹窗确认 → 一键补齐 → 起服务（全程幂等,已装的自动跳过）
$ErrorActionPreference = 'Continue'
$APP = $PSScriptRoot
$LOG = Join-Path $APP 'bootstrap.log'
function Say($m) { $t = "{0} {1}" -f (Get-Date -Format 'HH:mm:ss'), $m; Add-Content -Path $LOG -Value $t; Write-Host $t }

Say "=== 造纸局桌面版启动 APP=$APP ==="

# -1) 服务已经活着（窗口关了后台还在跑/双开）：直接退出；AUTO 模式（一键补依赖）放行到下面补齐
if ($env:ZAOZHIJU_AUTO -ne '1') {
  try {
    $ping = Invoke-WebRequest -Uri 'http://127.0.0.1:8712/api/types' -UseBasicParsing -TimeoutSec 3
    if ($ping.StatusCode -eq 200) { Say '服务已在运行，跳过全部'; exit 0 }
  } catch {}
}

# -0.5) 登记装机脚本与程序目录（「一键补依赖」「一键升级」靠这两个文件找到路）
$ZH = Join-Path $env:USERPROFILE '.zaozhiju'
New-Item -ItemType Directory -Force -Path $ZH | Out-Null
Set-Content (Join-Path $ZH 'setup.loc') (Join-Path $APP 'bootstrap.ps1') -Encoding utf8
Set-Content (Join-Path $ZH 'app.loc') $APP -Encoding utf8

function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') }
function Test-Interpreter($cmd) { try { & $cmd -c "import sys" 2>&1 | Out-Null; return ($LASTEXITCODE -eq 0) } catch { return $false } }
function Find-Python {
  Refresh-Path
  foreach ($c in 'python','py') { if (Get-Command $c -ErrorAction SilentlyContinue) { if (Test-Interpreter $c) { return $c } } }
  $roots = @((Join-Path $env:LOCALAPPDATA 'Programs\Python'), 'C:\Program Files\Python312') | Where-Object { Test-Path $_ }
  if ($roots) {
    $exe = Get-ChildItem -Path $roots -Filter python.exe -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($exe) { if (Test-Interpreter $exe.FullName) { return $exe.FullName } }
  }
  return $null
}
function Ensure-Winget($id, $what) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Say "缺 $what，但这台机器没有 winget：Microsoft Store 搜「App Installer」装上再重开造纸局"; return }
  Say "自动安装 $what（winget $id）……"
  winget install -e --id $id --scope user --silent --accept-source-agreements --accept-package-agreements 2>&1 | Add-Content $LOG
  Refresh-Path
}

# 0) 硬前提 Node（装过 claude CLI 就有）：没 Node 真跑不了
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Say "缺少 Node.js：请先装 claude CLI（或直接装 Node LTS：https://nodejs.org），装好重新打开造纸局"
  Start-Process 'https://nodejs.org/en/download'
  exit 1
}
if (-not (Get-Command claude -ErrorAction SilentlyContinue)) { Say '提醒：没找到 claude 命令——界面能开，但出单会失败。先跑 npm install -g @anthropic-ai/claude-code 并登录 claude' }

# 1) 体检：列出缺什么（已有的全部跳过）
$SK = Join-Path $env:USERPROFILE '.claude\skills'
$GZ = Join-Path $SK 'guizang-social-card-skill'
$WB = Join-Path $APP 'workbench'
$need = @()
$missingSkills = @('kami', 'guizang-social-card-skill', 'sweety-statechart-video') | Where-Object { -not (Test-Path (Join-Path $SK "$_\SKILL.md")) }
if ($missingSkills.Count -gt 0) { $need += "做法技能文件（出卡/出文档/出视频,共 $($missingSkills.Count) 个）" }
if (-not (Test-Path (Join-Path $WB 'node_modules\fflate'))) { $need += '服务端小依赖（npm,几十MB）' }
$PW = Join-Path $env:USERPROFILE '.cache\ms-playwright'
if (-not (Test-Path (Join-Path $GZ 'node_modules\playwright')) -or -not (Get-ChildItem $PW -Filter 'chromium*' -ErrorAction SilentlyContinue)) { $need += '出卡浏览器内核（约130MB）' }
$py = Find-Python
if (-not $py) { $need += 'Python（PDF/Word/PPT/视频必需,约25MB）' }
$hasFfmpeg = Get-Command ffmpeg -ErrorAction SilentlyContinue
if (-not $hasFfmpeg) { $need += 'ffmpeg（视频剪辑必需,约90MB）' }
# Word 需要的转换器 pandoc(装到 ~\.zaozhiju\bin,服务端自动可见)——2026-11-08 新增
$TOOLBIN = Join-Path $env:USERPROFILE '.zaozhiju\bin'
$hasPandoc = (Get-Command pandoc -ErrorAction SilentlyContinue) -or (Test-Path (Join-Path $TOOLBIN 'pandoc.exe'))
if (-not $hasPandoc) { $need += 'Word 转换工具 pandoc（约15MB）' }
# PPT 目检放映软件:PowerPoint/LibreOffice 有其一即可(都没有时 PPT 单会如实标注没做目检,不算崩)
$hasViewer = (Get-Command soffice -ErrorAction SilentlyContinue) `
  -or (Test-Path 'C:\Program Files\LibreOffice\program\soffice.exe') -or (Test-Path 'C:\Program Files (x86)\LibreOffice\program\soffice.exe') `
  -or (Test-Path 'C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE') -or (Test-Path 'C:\Program Files (x86)\Microsoft Office\root\Office16\POWERPNT.EXE')
if (-not $hasViewer) { $need += 'PPT 目检放映软件（PowerPoint/LibreOffice 任一）' }

# 2) 弹窗确认（检测不到东西就不打扰你；选过"先不装"记号在案不再问,设置页可重新打开询问）
$doInstall = $false
$skipMark = Join-Path $env:USERPROFILE '.zaozhiju\skip-setup'
if ($need.Count -gt 0) {
  if ($env:ZAOZHIJU_AUTO -eq '1') { $doInstall = $true; Remove-Item -Force -ErrorAction SilentlyContinue $skipMark; Say "体检缺项：AUTO 模式(一键补依赖)直接补齐" }
  elseif (Test-Path $skipMark) {
    Say "体检缺 $($need.Count) 项；之前选过先不装——跳过弹窗直接起服务(设置页可重新问)"
  } else {
  $list = $need -join "`n  · "
  $question = "造纸局体检：这台电脑还缺`n  · $list`n`n『是』= 一键装齐（约 10-20 分钟,期间别关窗口）`n『否』= 先不装（缺的功能暂不可用,其余照常；之后不再打扰,设置页可随时重新打开询问）"
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $r = [System.Windows.Forms.MessageBox]::Show($question, '造纸局 · 首次装机', 'YesNo', 'Question')
    $doInstall = ($r -eq 'Yes')
    Say "弹窗结果：$r"
    if (-not $doInstall) {
      New-Item -ItemType Directory -Force -Path (Split-Path $skipMark) | Out-Null
      Set-Content -Path $skipMark -Value 'skip' -Encoding ascii
      Say '已记住"先不装"：以后打开不再弹窗'
    }
  } catch {
    Say '弹窗不可用,默认直接装齐（无人值守模式）'
    $doInstall = $true
  }
  if ($doInstall) { Remove-Item -Force -ErrorAction SilentlyContinue $skipMark }
  }
} else {
  Say '体检：什么都不缺，直接起服务'
}

# 3) 按确认结果补齐（每项都先判有无,已有不重做）
if ($doInstall) {
  foreach ($s in $missingSkills) {
    $src = Join-Path $APP "skills\$s"
    if (-not (Test-Path $src)) { Say "安装包缺技能 $s（异常）"; continue }
    Copy-Item -Recurse $src (Join-Path $SK $s); Say "已安装技能 $s"
  }
  if (-not (Test-Path (Join-Path $WB 'node_modules\fflate'))) {
    Say '安装服务端依赖 npm install …'
    Push-Location $WB; npm install --no-audit --no-fund --loglevel=error 2>&1 | Add-Content $LOG; Pop-Location
    Say '服务端依赖完成'
  }
  if (-not (Test-Path (Join-Path $GZ 'node_modules\playwright'))) {
    Say '安装 guizang 技能依赖 …'
    Push-Location $GZ; npm install --no-audit --no-fund --loglevel=error 2>&1 | Add-Content $LOG; Pop-Location
  }
  if (-not (Get-ChildItem $PW -Filter 'chromium*' -ErrorAction SilentlyContinue)) {
    Say '下载 playwright chromium …'
    Push-Location $GZ; npx playwright install chromium 2>&1 | Add-Content $LOG; Pop-Location
    Say 'chromium 安装完成'
  }
  if (-not $py) { Ensure-Winget 'Python.Python.3.12' 'Python'; $py = Find-Python }
  if ($py) {
    Say "用 $py 安装/校验 Python 库（weasyprint pypdf pymupdf edge-tts python-pptx python-docx）…"
    & $py -m pip install --quiet --disable-pip-version-check weasyprint pypdf pymupdf edge-tts python-pptx python-docx 2>&1 | Add-Content $LOG
    Say 'Python 库完成'
  } else {
    Say 'Python 没装上：PDF/Word/PPT 文档与蜡笔视频暂不可用（其余照常）。手动补：winget install -e --id Python.Python.3.12'
  }
  if (-not $hasFfmpeg) { Ensure-Winget 'Gyan.FFmpeg' 'ffmpeg' }
  if (Get-Command ffmpeg -ErrorAction SilentlyContinue) { Say 'ffmpeg 就位' } else { Say 'ffmpeg 仍缺：蜡笔视频暂不可用（其余不受影响）。手动补：winget install -e --id Gyan.FFmpeg' }
  if (-not $hasPandoc) {
    Say '下载 pandoc(Word 转换) …'
    New-Item -ItemType Directory -Force -Path $TOOLBIN | Out-Null
    $zip = Join-Path $env:TEMP 'zaozhiju-pandoc.zip'
    $dir = Join-Path $env:TEMP 'zaozhiju-pandoc'
    try {
      Invoke-WebRequest -Uri 'https://github.com/jgm/pandoc/releases/download/3.13/pandoc-3.13-windows-x86_64.zip' -OutFile $zip -UseBasicParsing -TimeoutSec 300
      Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $dir
      Expand-Archive -Path $zip -DestinationPath $dir -Force
      $exe = Get-ChildItem -Path $dir -Filter pandoc.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($exe) {
        Copy-Item $exe.FullName (Join-Path $TOOLBIN 'pandoc.exe') -Force
        # 持久化进用户 PATH(engineEnv 本来就会带上这个目录,这里顺手让其他工具也能找到)
        $up = [Environment]::GetEnvironmentVariable('Path','User')
        if ($up -notlike "*$TOOLBIN*") { [Environment]::SetEnvironmentVariable('Path', "$TOOLBIN;$up", 'User') }
        Refresh-Path
        Say "pandoc 就位($(Join-Path $TOOLBIN 'pandoc.exe'))"
      } else { Say '解压后没找到 pandoc.exe：Word 单会如实报缺' }
    } catch { Say "pandoc 下载失败：Word 单会如实报缺。手动补:https://github.com/jgm/pandoc/releases 下载 windows zip,把 pandoc.exe 放进 $TOOLBIN" }
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $zip, $dir
  }
  if (-not $hasViewer) {
    Ensure-Winget 'TheDocumentFoundation.LibreOffice' 'LibreOffice（PPT 目检放映,较大）'
    if (Get-Command soffice -ErrorAction SilentlyContinue) { Say 'LibreOffice 就位' } else { Say '放映软件仍缺：PPT 单仍出,但目检环节会如实标注' }
  }
}

# 4) Pexels 配图钥匙空文件占位（不联网、不弹窗；想要配图把 Mac 上的内容粘进来即可）
$LAP = Join-Path $env:USERPROFILE '.lapian'
New-Item -ItemType Directory -Force -Path $LAP | Out-Null
$KEY = Join-Path $LAP 'pexels_key'
if (-not (Test-Path $KEY)) { Set-Content -Path $KEY -Value ''; Say "已建空 $KEY ：把 Mac 上同名文件的内容粘进去,出卡即自动配实拍图（不粘=纯排版交付,不算故障）" }

# 5) 起服务（隐藏窗口、输出落 server.err.log；服务常驻后台,下次开秒进；AUTO 补依赖时服务已在跑就不重复起）
$alive = $false
try { $p2 = Invoke-WebRequest -Uri 'http://127.0.0.1:8712/api/types' -UseBasicParsing -TimeoutSec 3; $alive = ($p2.StatusCode -eq 200) } catch {}
if ($alive) { Say '服务已在运行（本次只补齐依赖,不重复起）'; exit 0 }
Say '启动造纸局服务 http://127.0.0.1:8712'
$srv = Start-Process -FilePath 'node' -ArgumentList "`"$WB\server\server.mjs`"" -WorkingDirectory $WB -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $APP 'server.out.log') -RedirectStandardError (Join-Path $APP 'server.err.log')
if ($srv) { Set-Content (Join-Path $ZH 'server.pid') $srv.Id -Encoding ascii }
