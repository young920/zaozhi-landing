# Paper Brief (Mode F)

Paper Brief 是一张「学术情报摘要」风格的单卡信息卡（3:4 · 1080×1440），灵感来自小红书"经济学周刊·论文快报"的视觉系统。它是 5 段固定结构的"单一固定风格"——不像 Mode A/B/C 那样换 accent palette，整套配色和节奏不能改。

## 什么时候用 Paper Brief

✅ **适合**：

- 单篇论文 / 期刊文章的「一句话情报卡」摘要
- arXiv / 单篇深读的快速视觉化
- 研究周报中的"本周推荐 1 篇"
- 学术播客 / 论文分享的封面卡
- 任何想用"论文卡片"代替"文字海报"的内容

❌ **不适合**：

- 多篇论文综述（用 Mode D Newspaper Weekly）
- 工具 / 方法论 / 教程（用 Mode C Neo-Brutalist）
- 访谈 / 双语（用 Mode E Dialogue）
- 单纯的数据可视化（用 Mode B Swiss）

## 视觉锚点（7 个识别符 · 缺一不可）

1. **米白纸底** `#F1ECDD`（不纯白）+ 轻量 radial 颗粒
2. **黑色顶 header 块 + 右上斜切角**（`clip-path: polygon(0 0, 100% 0, 100% 64%, 78% 100%, 0 100%)`，识别符 1）
3. **暖琥珀黄三角 ▶**（`#F2C94C`，出现在英文 title 前）
4. **ABSTRACT 框**（白底 + 1px 黑细边 + 顶部「ABSTRACT」标签条 + 右上三圆点）
5. **KEY FINDINGS 编号 01/02/03 块**（黑底白字圆形数字 + 粗体标签 + 解释）
6. **一句话总结黑底白字横条**
7. **底部 Footer**（条码「PAPER BRIEF」+ DOI + VOL，顶部黑细线分割）

## 8 色限定色板（整组卡只能用 8 色 + 1 个强调橙可选）

| 角色 | 色值 | 用途 |
|---|---|---|
| 纸 | `#F1ECDD` | 主背景 |
| 副纸 | `#E8E2CF` | KEY FINDINGS 区底 / 分隔带 |
| 墨 | `#141414` | header 块 / footer 块 / 主文字 |
| 奶白 | `#F7F2DF` | 微对比背景（极少用） |
| 线 | `#1A1A1A` | ABSTRACT 框线 / 分隔细线 |
| 深灰 | `#2A2A2A` | 次要文字 |
| 浅褐灰 | `#8A8576` | metadata / 副信息 |
| 暖琥珀黄 | `#F2C94C` | 三角 ▶ / 编号块底（唯一 accent） |
| 强调橙（可选） | `#FF6B1A` | 仅限"警告/重音"单次出现 |

**所有颜色必须从这 9 个变量里选。** 不允许"看起来差不多"的米、棕、灰等过渡色。

## 字号体系（密 → 疏 → 密）

| 角色 | 大小 | 字重 | 字体 |
|---|---|---|---|
| Brand name（顶 header） | 64px | 900 | Inter |
| Header subbrand | 24px | 500 | Noto Serif SC |
| Issue / N | 22px | 700 mono | JetBrains Mono |
| Date strip | 16px | 700 mono | JetBrains Mono |
| Title（英文） | 46px | 900 italic | Playfair Display |
| Journal meta | 14px | 700 mono | JetBrains Mono |
| Authors meta | 14px | 500 | Inter |
| Abstract body | 18px | 400 | Noto Serif SC |
| Abstract label | 14px | 700 mono | JetBrains Mono |
| Finding num | 13px | 700 mono | JetBrains Mono |
| Finding body | 17px | 400 | Noto Serif SC |
| Takeaway | 20px | 500 | Noto Serif SC |
| Footer DOI | 13px | 500 mono | JetBrains Mono |
| Footer VOL | 22px | 800 | Inter |

## 5 段固定结构（按顺序，不能调换）

```
1. HEADER       黑色顶块 · 斜切角 · Brand + Issue + Subbrand
2. DATE STRIP   米色日期条 + 横划线
3. TITLE        ▶ 三角 + 英文斜体大标 + 期刊/作者 meta 横划线
4. ABSTRACT     白底 1px 黑边框 + 顶部「ABSTRACT」标签 + 三圆点 + 中文摘要
5. KEY FINDINGS 01/02/03 编号圆形块 + 粗体短标签 + 解释文字（3 条）
6. TAKEAWAY    黑底白字横条（收束）
7. FOOTER       条码 PAPER BRIEF + DOI + VOL（顶部黑细线）
```

> 注意是 **5 个内容段 + Header + Footer = 7 块视觉元素**。
> Header 和 Footer 是"骨架固定"，5 个内容段是"数据驱动"。

## 数据字段定义（page() 入参）

```js
{
  brandName:     'PAPER BRIEF',                              // 顶 header 大字
  issueLabel:    '/ 15',                                     // 顶 header 期号
  subbrand:      '经济学周刊 · 论文快报',                    // header 底部副品牌
  dateLabel:     '2026.08.05 WED',                           // 日期条
  title:         'Beyond Anthropomorphism: Social Presence…',// 英文斜体大标
  journalMeta:   'JMS 63(2) · 2026 · pp. 515–560',           // 期刊号 meta
  authors:       'Dominik Siemon / Edona Elshan / et al.',   // 作者 meta
  abstractHTML:  '我们常把 AI 做得更像人...<span class="pb-mark">高亮</span>...',
  findings: [
    { label: '作用路径', body: '社会临场感通过团队承诺和相互依赖意愿影响协作动机' },
    { label: '熟悉程度', body: '熟悉 AI 时，社会临场感对协作的作用更强' },
    { label: '设计重点', body: 'AI 可理解性与拟人化外表同影响人机协作质量' },
  ],
  takeawayLabel: '一句话总结：',
  takeawayBody:  '让 AI 看起来像人只是起点...',
  doi:           '10.1111/joms.70000',
  volLabel:      'VOL.63 · NO.2',
  barcodeSeed:   '15',                                       // 条码随机种子
}
```

### abstractHTML 的 `<span class="pb-mark">` 用法

摘要中需要重点突出的关键词用 `<span class="pb-mark">高亮</span>`，会渲染为下划线 + 琥珀黄底色。
**每张卡建议高亮 2-4 个关键词**——过多 = 没有重点，过少 = 视觉平淡。

## 快速上手（5 步）

### Step 1 · 建项目目录

```bash
mkdir -p /Users/yang/.openclaw/workspace/local-tests/<slug>/output
mkdir -p /Users/yang/.openclaw/workspace/local-tests/<slug>/assets
```

### Step 2 · 复制 build.mjs 模板

```bash
cp /Users/yang/.claude/skills/guizang-social-card-skill/assets/paper-brief-templates/build.mjs \
   /Users/yang/.openclaw/workspace/local-tests/<slug>/build.mjs
```

### Step 3 · 填数据

打开 `build.mjs`，按真实论文填 6 个字段：
- `title`（必填英文 · 不能写中文标题）
- `journalMeta`（必填期刊号）
- `authors`（必填作者）
- `abstractHTML`（必填中文摘要，可含 `<span class="pb-mark">高亮</span>`）
- `findings`（必填 3 条，每条 1 个短标签 + 1 行解释）
- `takeawayBody`（必填 1 句总结，< 35 字）

### Step 4 · 渲染

```bash
cd /Users/yang/.openclaw/workspace/local-tests/<slug>
node build.mjs
```

输出在 `output/paper-brief-001.png`。

### Step 5 · 发飞书

```bash
cd output
lark-cli im +messages-send --user-id <ou_xxx> --image ./paper-brief-001.png --as bot
```

## Identity test（一张卡是 Paper Brief 当且仅当全部成立）

1. ✅ 米白纸底 `#F1ECDD` + 黑色顶 header 块（带斜切角）
2. ✅ 暖琥珀黄三角 ▶ 装饰出现在 title 前
3. ✅ ABSTRACT 框存在：1px 黑边 + 顶部「ABSTRACT」标签条 + 右上三圆点
4. ✅ KEY FINDINGS 区有 01/02/03 编号圆形块（黑底白字）
5. ✅ 一句话总结是黑底白字横条
6. ✅ 颜色仅从 8 色色板里取（+ 可选 1 个橙 #FF6B1A 单次警告）
7. ✅ 字体只用 Inter + Noto Serif SC + JetBrains Mono + Playfair Display 4 个家族

## 复用保证（重要）

**下次复用与本次一致**：
- 8 色色板变量必须保留（不改成近似色）
- 字号体系必须保留（64/46/24/22/20/18/17/16/14/13）
- 5 段结构顺序不能调换（Header → Date → Title → Abstract → Findings → Takeaway → Footer）
- 工具函数签名（`page` / `chrome` / `render` / `generateBarcodeBars`）不能改
- 共享脚本路径（`shared.css` / `tools.js` / `build.mjs`）必须保留

## 沉淀资产

- 共享 CSS：`assets/paper-brief-templates/shared.css`（完整 8 色色板 + 字号体系 + 节奏规则）
- 共享工具：`assets/paper-brief-templates/tools.js`（`page` / `chrome` / `render` / `generateBarcodeBars` + `renderIllustration` / `renderCoverHero` / `renderCoverSteps`）
- 项目入口：`assets/paper-brief-templates/build.mjs`（数据字段填法 + 渲染示例）
- 使用文档：`references/template-paper-brief.md`（本文件）

---

## 教程内容版 · 6 步课程拓展（2026-08-06 沉淀）

项目场景：「Claude Code Deep Dive · Eval Engineering」（飞书 wiki · 原文 6 节方法论）。由 1 封面 + 6 内容卡组成。**Paper Brief 5 段结构不变**，拓展为「多字段扩充实心度」+ 「封面 / 内容卡 2 布局」。

### 为什么是 Paper Brief 而不是 Mode C Neo-Brutalist

- 内容偏论文引用风格（Zheng 2023 / Goodhart's Law / ArenaHard / ICLR 2024） → Paper Brief 的学术情报感更贴
- 单篇深读 / 逐步拆解 → Paper Brief 的静态 5 段是「每步 1 张」的最佳载体
- 需要保持 6 张的视觉一致性 → Paper Brief 单一固定风格（不换 accent palette）正好

### 拓展 1 · 2 种布局（isCover 切摸）

| 模式 | 启用条件 | 布局顺序 |
|---|---|---|
| Content Card（默认） | `isCover: false` 或不填 | date+chip → title → meta → abstract → **illustration** → findings → sources → takeaway |
| Cover | `isCover: true` | date+chip → title → meta → **coverDeck 金句** → **coverHero 大图** → **coverSteps 索引** → abstract（短）→ sources → takeaway |

**isCover 控制 brandName 字号**：内容卡 64px，封面 52px（避免「EVAL ENGINEERING」溢出到第 2 行）。

### 拓展 2 · 顶部 chip 横排（stats 字段）

每张卡顶部一行 4 个数字 chip，吞掉 header 下方原本 280px 留白。3 色 tone：

| tone | 样式 | 用途 |
|---|---|---|
| `accent` | 黑底黄字 | 最重要 1 个数字（第一步选 accent） |
| `yellow` | 黄底黑字 | 次要重要 1 个数字 |
| `default` | 白底黑边 | 普通 1-2 个 |

```js
stats: [
  { value: '06', label: 'STEPS',              tone: 'accent' },
  { value: '6',  label: 'TAKEAWAY LINES',     tone: 'yellow' },
  { value: 'GATE', label: 'CENTRAL METAPHOR', tone: 'default' },
]
```

### 拓展 3 · SOURCES strip（学术出处条）

```js
sources: [
  { tag: 'ZHENG 2023',  text: 'Berkeley · GPT-4 vs 人类 80% 一致率' },
  { tag: '2026 BENCH',  text: 'GPT-5.2 / Gemini 3.1 / Opus 4.7 自评胜率' },
]
```

渲染为胶囊虚线条状，与 stat strip（实色 chip）形成节奏对比。

### 拓展 4 · Mini SVG Illustration（内页卡 mini · 96px）

`pb-illustration` 容器是 96px 高的 inline SVG 区域，flex-shrink: 0（不被 flex column 压缩）。**5 类设计模式**：

| 模式 | 适用场景 | 示例 |
|---|---|---|
| 散点图 | 数据偏差 / 多个量同时出现 | 卡 01：评委 A/B/C/D 散点 + 93.3% / 39.5% 高亮 |
| 流程图 | 概念路径变化 / 前后对比 | 卡 02：温度计 → 恒温器 → 控制路径 |
| 堆栈图 | 多层结构 / 层次关系 | 卡 03：L1 端到端 / L2 轨迹 / L3 组件三层栈 |
| 表格 / 追踪记录 | 多行重复结构 / 文本到代码转换 | 卡 04：4 行追踪记录，输入 / 调用 / 评审 判定 |
| 时间线 / 版本 | 过程版本依赖 / 顺序演进 | 卡 05：v3.0 / v3.1 / v3.2 评审模型版本 |
| 多级闸门 | 多级分类 / 颜色 × 状态 | 卡 06：T1/T2/T3 三级通道 · 黄/米/黑 |

### 拓展 5 · Cover Hero（封面 240px 大图）

`pb-cover-hero` 容器是 240px 高的 inline SVG 区域，flex-shrink: 0。设计三联式：

```
[左 1/3 · 评审输入] → [中 1/3 · 闸门主角] → [右 1/3 · 通道输出 + 绿盾]
```

底部加虚线连接箭头形成「输入 → 闸门 → 输出」的完整隐喻。

### 拓展 6 · 6 步索引（coverSteps 字段）

封面专属「STEP 01-06」chip 横排，6 列 grid：

```js
coverSteps: [
  { num: '01', title: '评审偏差' },
  { num: '02', title: '进生产' },
  { num: '03', title: '三层评估' },
  { num: '04', title: '日志挖测试' },
  { num: '05', title: '固定版本' },
  { num: '06', title: '影响范围' },
],
```

### 拓展 7 · KEY FINDINGS 空时不渲染

`findings: []` 或不填 → 该块 `display: none`，避免封面出现「KEY FINDINGS」空头。

### 坑位记忆（不能重犯）

| 坑 | 原因 | 修正 |
|---|---|---|
| flex column 里 SVG 被压缩到 0 高度 | flex-shrink: 1 | `.pb-illustration` / `.pb-cover-hero` 加 `flex-shrink: 0` |
| 黑顶 brandName 64px 在「EVAL ENGINEERING」溢出成 2 行 | 默认字号不适合长 brand | isCover: true 切 52px |
| `findings: []` 时渲染一个空 KEY FINDINGS 块 | 没控制渲染条件 | tools.js page() 里加空检查 + display:none |
| 用户误把封面图当风格图 → 整套模板重做了 | 没先问「素材 vs 风格图」 | Step 1 前先问 · 2026-08-06 教训 |

### 可复用 build 模板（封面 + 内容卡）

```
项目根/
├── build-cover.mjs     # 封面专用
├── build-01.mjs        # 6 张内容卡
├── build-02.mjs
├── build-03.mjs
├── build-04.mjs
├── build-05.mjs
├── build-06.mjs
├── output/
│   ├── cover-00-eval-engineering.png
│   ├── card-01-eval-bias.png
│   ├── ...
│   └── card-06-impact-scope.png
└── text-bank.md        # 所有生成文本（封面+6 卡）的沉淀文本
```

### 发飞书批量脚本（验证可用）

```bash
for n in 01 02 03 04 05 06; do
  lark-cli im +messages-send --user-id <ou_xxx> --image ./output/card-$n-*.png --as bot
done
lark-cli im +messages-send --user-id <ou_xxx> --image ./output/cover-00-*.png --as bot
```