# Dialogue Poster Template

对话 / 访谈 / 播客 栏目系列封面 + 高密度双语内容页的视觉模板。

## 视觉签名

- **浅荧光绿色块** `#d6f5b8` 作为"品牌签名"——不切换颜色，绿块就是品牌
- **中英双语对照**：英文用 Inter Black（900）+ 中文用 Noto Serif SC（中粗 500）
- **强网格**：hairline 分隔线 + 严格的 column 拆分 + mono uppercase 标签
- **零图标**：只用文字 + 几何形状（矩形色块、hairline、单字字符）
- **页面导航锚点**：顶部 + 底部 `page-chrome` 栏带栏目名 + Episode + 页码

## 何时用

- 嘉宾访谈 / 圆桌对谈 / 播客节目 封面（D01 dialogue-cover）
- 论点正文页（500-1000 字双语对照，D02 高密度双语对照 + marginalia 引文侧栏）
- 议题清单 / 时间线 / 章节地图（D03 ledger 议题清单 / 编号清单）
- 公众号宽屏 banner（21:9 wechat-21x9 大标题 + 引文区）
- 微信公众号封面预览对（左 21:9 + 右 1:1）

## 何时不用

- 单一静态卡片（如产品发布、单图小红书图文）——用 editorial-card / swiss-card 更合适
- 旅行 / 生活方式 / 推荐类图文——气质不符
- 需要大幅图片证据的卡片——dialogue-poster 是"文字+网格"为骨架，图片是辅助

## 三种比例

| 比例       | 类名                    | 尺寸             | 用途                                |
| ---------- | ----------------------- | ---------------- | ----------------------------------- |
| 3:4        | `.poster.xhs`           | 1080 × 1440      | 小红书图文主图                      |
| 1:1        | `.poster.square`        | 1080 × 1080      | 公众号方形封面 / 卡片分享预览      |
| 21:9       | `.poster.wide`          | 2100 × 900       | 公众号头图 / 微信文章宽屏 banner   |
| 预览对     | `.pair-preview`         | 3000 × 1100      | 公众号 21:9 + 1:1 同时预览          |

## Layout Recipes

模板预置 3 个 recipe（`<!-- POSTERS_HERE -->` 区域放置）：

### D01 — Dialogue Cover（对话封面）

适合栏目首期 / 单期封面 / 海报分发。

```
<section class="poster xhs" id="xhs-01">
  <div class="content">
    <div class="color-block"></div>
    <div class="dialogue-cover">
      <h1 class="head-en">Conversations<br>on<br>Contemporary<br>Art<br>and<br>Context</h1>
      <div class="head-zh"><p class="head-zh-inner">关于<br>当代艺术与语境的对话</p></div>
      <div class="episode-block">…</div>
      <div class="people-block">…</div>
    </div>
  </div>
</section>
```

关键 class：

- `.color-block` 浅荧光绿矩形，**4 周留白**（left:16% / right:5% / top:3% / bottom:3%），默认位置
- `.head-en` 英文标题（左 0~48% 区域，Inter 900，5 行起，每行单字/单词）
- `.head-zh` 中文标题（绝对定位到绿块右下角，Serif SC 500，右对齐）
- `.episode-block` 横跨全宽双语（Episode 编号 + 副标）
- `.people-block` 横跨全宽双栏（INTERVIEWER 左 / GUEST 右）+ hairline 顶分隔

字号档（XHS 比例）：

| 元素                | 字号  | 字重 |
| ------------------- | ----- | ---- |
| `.head-en` 英文标题 | 92px  | 900  |
| `.head-zh-inner` 中文标题 | 64px | 500 |
| `.episode-block .body-en` | 22px | 400 / 700（标题） |
| `.people-block .name-en` | 36px | 800 |
| `.people-block .name-zh` | 40px | 500 |

### D02 — High-density Bilingual Content（高密度双语对照正文页）

适合栏目正文页（500-1000 字双语对照）、论点页、嘉宾对谈记录。

结构（自上而下）：

1. **顶部** `.page-chrome` running header（栏目名 + Episode + 页码）
2. **标题区** 双语大标题 + 双语副标/导语
3. **主体** 60/40 双栏：左主栏双语对照 6 段正文（约 500-1000 字/语），右 marginalia 侧栏 4 条嘉宾引文双语对照
4. **底部** `.page-chrome` footer（嘉宾姓名 + 01/03 页码）

字号档：

| 元素                       | 字号  |
| -------------------------- | ----- |
| 主标题 EN/ZH               | 28px  |
| 副标 EN/ZH                 | 11px mono / Serif SC |
| 正文 EN                    | 13px / 1.5 行距     |
| 正文 ZH                    | 13px / 1.7 行距（中文行距宽一点） |
| 引文 EN                    | 15px  |
| 引文 ZH                    | 12px  |
| footer label               | 14px mono uppercase |

### D03 — Ledger / Thread Map（议题清单 / 章节地图）

适合多议题清单、章节列表、时间线锚点、5 条线索、3 个观点对比。

结构：

1. **顶部** 大标题双语对照 + 副标标签（如"A MAP OF THE CONVERSATION"）
2. **主体** `.ledger.ledger-tight` 5 行 ledger：编号 col（mono 24px）+ EN head col + ZH col + gloss 注释（斜体小字）
3. **底部** footer

每行 ledger 结构：

```
<div class="ledger-row">
  <div class="ledger-num">01</div>
  <div class="ledger-stack">
    <div class="ledger-en">Cross-cultural translation</div>
    <div class="ledger-zh">跨文化翻译</div>
    <div class="ledger-gloss">A bilingual practice as a method, not a feature.</div>
  </div>
</div>
```

字号档：

| 元素             | 字号  |
| ---------------- | ----- |
| 大标题 EN/ZH     | 140px / 96px |
| ledger-num       | 24px mono |
| ledger-en        | 26px Inter 800 |
| ledger-zh        | 22px Serif SC 500 |
| ledger-gloss     | 16px Inter italic muted |

### Pair Preview（公众号封面预览对）

```
<section class="pair-preview" id="pair-1">
  <div>
    <p class="preview-label">WeChat 21:9 — Wide Cover</p>
    <div class="poster wide" id="preview-wide" style="margin:0;width:1860px;height:796px;">…</div>
  </div>
  <div>
    <p class="preview-label">WeChat 1:1 — Square Cover</p>
    <div class="poster square" id="preview-square" style="margin:0;width:1000px;height:1000px;">…</div>
  </div>
</section>
```

**注意：pair-preview 必须用 `overflow: hidden`**——容器宽度 3000px 才不会越界。

## Design Tokens

在 `[data-style="dialogue-poster"]` 作用域下定义：

```css
:root,
[data-style="dialogue-poster"] {
  --block:      #d6f5b8;   /* 浅荧光绿主色 */
  --block-2:    #c9ec9a;   /* 备用更饱和绿 */
  --on-block:   #0a0a0b;   /* 块上文字一律黑 */
  --block-left:   16%;
  --block-right:  5%;
  --block-top:     3%;
  --block-bottom:  3%;
}
```

字体栈（继承 swiss-card / editorial-card）：

```css
--sans:     "Inter", "Helvetica Neue", "Noto Sans SC", -apple-system, "PingFang SC", sans-serif;
--sans-zh:  "Noto Sans SC", "PingFang SC", "Microsoft YaHei UI", sans-serif;
--serif-zh: "Noto Serif SC", "Songti SC", "STSong", serif;
--mono:     "IBM Plex Mono", ui-monospace, "SF Mono", Consolas, monospace;
```

## CSS Hook 完整清单

模板预置以下 class，写到 HTML 里就能用，不用写内联样式（除非要覆盖默认）：

- `.color-block` 浅荧光绿矩形（默认 4 周留白，可用 `.full` / `.right-only` / inline style 覆盖）
- `.dialogue-cover` D01 容器
- `.head-en / .head-zh / .head-zh-inner` D01 双语标题
- `.episode-block` D01 Episode 行（横跨全宽）
- `.people-block` D01 INTERVIEWER / GUEST 双栏
- `.page-chrome` 顶部/底部 running label（mono uppercase + letter-spacing）
- `.bilingual-row` 双语对照行（head + body 双栏）
- `.block-fill` 实心绿块容器
- `.quote-column` 引文列（hairline 左 border + 4 条双语引文 + attribution）
- `.content-grid-3 / .content-grid-4` 三/四栏内容网格
- `.ledger / .ledger-row / .ledger-num / .ledger-en / .ledger-zh / .ledger-stack / .ledger-gloss / .ledger-tight` ledger 密集表格
- `.hd-page` D02 高密度正文容器
- `.pair-preview` 公众号封面预览对（容器）

## 快速开始

1. **复制模板到任务目录**：

```bash
cp /Users/yang/.claude/skills/guizang-social-card-skill/assets/template-dialogue-poster.html \
   <你的任务目录>/index.html
```

2. **替换数据**：找到 `<!-- POSTERS_HERE -->` 区域，删掉默认的 xhs-01 / xhs-02 / xhs-03 / wechat-1x1 / wechat-21x9 / pair-preview，按你的内容重新写：

   - D01 封面：填入栏目名 / 期号 / 标题（中英）/ 嘉宾姓名
   - D02 正文：填入双语正文段落（500-1000 字/语）+ marginalia 引文
   - D03 ledger：填入 3-7 行议题条目

3. **渲染**：用 Playwright 打开 `<你的任务目录>/index.html`，按 `.poster.xhs / .poster.square / .poster.wide / .pair-preview` 的 bounding rect 截图，输出 PNG。

   可参考 swiss-card / editorial-card 模板里的 render 脚本（playwright + file:// URL + page.screenshot）。

4. **检查**：每张 PNG 用 image 工具肉眼检查，重点看：
   - 绿块不与文字重叠
   - 字号不溢出 column
   - 双语中英文水平/垂直对齐
   - 顶部 running header + 底部 footer 不被正文覆盖

## 调整清单

| 想要…                                       | 改什么                                              |
| ------------------------------------------- | --------------------------------------------------- |
| 颜色更浅 / 更深                              | `--block` / `--block-2` 的 hex 值                    |
| 绿块位置（左半 / 右半 / 全宽 / 四角留白）   | `.color-block` 的 inline style `left/right/top/bottom` |
| 英文标题字号                                 | `.poster.xhs .dialogue-cover .head-en` font-size    |
| 中文标题位置（绿块右下 / 右下 / 居中）      | `.dialogue-cover .head-zh` bottom/left/right        |
| D02 正文密度（更紧 / 更松）                 | 各处 font-size（13-15px 区间）+ line-height          |
| D03 ledger 行数（3-7 行）                   | 增删 `.ledger-row` 节点                             |
| Ledger gloss 注释风格（去掉 / 改用别的）     | 删 `.ledger-gloss` 节点或换 mono uppercase          |
| Pair preview 容器宽度                       | `.pair-preview` 的 width（≤ 3000，不要超过 viewport）|

## 沉淀历史

- 2026-08-04：v6 封面定稿（绿块色值 #d6f5b8 + 4 周留白矩形 + 92px 英文标题 + 中文标题在绿块右下角）
- 2026-08-04：D02 高密度正文页 v2（13px 字号 + 6 段双语对照 + 4 条 marginalia 引文侧栏）
- 2026-08-04：D03 ledger 议题清单 + wechat-21x9 衍生版 + pair-preview
- 2026-08-04：模板与使用说明沉淀进 skill

参考对话封面参考图：浅荧光绿矩形 + 中英双语对照 + INTERVIEWER/GUEST 双栏。