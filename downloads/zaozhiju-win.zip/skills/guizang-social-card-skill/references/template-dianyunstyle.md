# Template · Dianyunstyle

A Mode B (Swiss International) sub-style focused on a dense **bitmap-cluster SVG hero** — every glyph is a "cloud of dots" built from thousands of small letters at the top of each poster page. Built for 1080×1440 vertical social cards where the page is read as "one big central glyph + supporting ledger content."

Source-of-truth assets:

- Template: `assets/dianyunstyle-templates/template-dianyunstyle.html`
- Hero generator: `scripts/typogram/dianyunstyle-batch.mjs`
- Style identity: `references/style-system.md` → **Mode B: Swiss International** + this sub-style

## When to use

Pick dianyunstyle when the content reads as **central + supporting**, not as a comparison matrix or release-note flow. Specifically:

- Topic has **one dominant concept** (a project, a tool, a system) that the user needs to remember.
- You have **3–6 supporting items** that read like footnotes to that concept, not parallel to it.
- Editorial intent: "feature story" with one glyph as anchor, not "release note" with bullets.

**Do not use** for: comparison posts (use the standard Swiss card), pure news/announcement formats (use dialogue-poster), editorial-magazine content (use Editorial template).

## Visual rules

- **Mode B rules apply** — Inter + Noto Sans SC + IBM Plex Mono, hairline rules, no shadows, no rounded cards, no glassmorphism, single accent palette.
- **Palette**: paper `#f0ede5`, ink `#2a2825`. This template ships with the **Ink Classic (warm paper)** palette by default. The accent variable is `--ink`; do not introduce a colored accent unless the topic needs it (rare for this template).
- **No serif font**. Display titles use `Noto Sans SC` weight 900 (this template intentionally deviates from the standard Swiss "weight 200–400 hero" rule — the bitmap hero carries the visual weight, not the display title).
- **Hero size**: 580×580 px centered. SVG viewBox is 1000×1000; it scales into the container.
- **Page chrome**: same masthead (top), folio (bottom), `--line` rules as the other Swiss templates.

## Three hero variants — pick per page

The bitmap hero is **not** a one-shape-fits-all. Each page in a 3-page set should use a different variant so the reader senses progression:

| Variant | Function | Use on |
|---|---|---|
| `variantCover({ innerWord, ghostWord, arms })` | Central dense glyph + ghost halo + 4 radial arms | **P01 cover / opening** — the dominant concept |
| `variantCompare({ quads, centerLabel })` | 4 bitmap blocks in 4 quadrants meeting at a center "VS" badge | **P02 compare / tradeoffs** — "this set vs alternatives" |
| `variantStaircase({ steps, kws, heights, headerTop, headerBig })` | N bitmap columns of decreasing height with captions and pixel trails | **P03 exec / runbook** — numbered steps, sequence, checklist |

**Why three variants instead of one repeated**: a set of 3 cards with identical bitmap heroes reads as "one trick repeated three times" — visually monotonous and feels like a template glitch. The variant trio (central → compare → staircase) reads as "introduction → discussion → execution" and gives the set a clear three-act structure.

## Anatomy of a poster page

```
┌─ .upper ─────────────────────────────┐
│  .masthead          (kicker line)    │
│  .bitmap-hero        (580×580 SVG)    │  ← hero variant from table above
│  .upper-side        (right column    │
│                      or under hero)  │
├─ .lower ─────────────────────────────┤
│  .kicker / .h-step / .lead          │  ← title + lead paragraph
│  .db-list (or .step-grid)           │  ← supporting ledger
│  .why-now / .legend-strip / etc.    │  ← optional supporting strips
│  .folio             (page number)    │
└──────────────────────────────────────┘
```

`upper` uses `flex: 0 0 auto` (content-sized), `lower` uses `flex: 1 1 auto` (fills remaining space). This means **lower absorbs any leftover vertical space**, so the folio always lands at the page bottom regardless of how much supporting content you add. Do not re-introduce `flex: 1 1 50%` on `.upper`; it caused the "upper-half looks empty" regression in earlier drafts.

## Hero SVG parameters — when to tune what

Defaults are tuned for a 3-page set on the topics "AI tools / engineering workflows / dev workflows". For other topics, tune these in this order:

1. **`innerWord`** (cover/compare/staircase) — the head term the reader remembers. Should be 4–7 letters. Avoid 1–2 letter words (look like abbreviations, not glyphs).
2. **`ghostWord`** (cover only) — a near-synonym or category word, 4–6 letters, that sets context. Slightly bigger and fainter than `innerWord`.
3. **`arms[].kw`** (cover only) — 3–4 letter related keywords, one per corner. The angle direction matters: keep one per quadrant.
4. **`quads[].kw`** (compare only) — 4–7 letter words per quadrant. First quad reads as "this set", the other three as alternatives — keep the first slightly bolder (this is automatic).
5. **`steps[]`** (staircase only) — pass them as `'01'`, `'02'`... `'09'`, `'10'`. Bitmap font supports 0–9.
6. **`heights[]`** (staircase only) — must be strictly descending for the "progress" reading. Same height per column reads as "parallel", not "sequence".

**Don't tune** unless you have a reason:

- `innerCell / clusterSize / tinyFont` — these control bitmap density. Default `clusterSize: 6` (cover/compare) and `clusterSize: 4` (staircase). Going lower makes the glyph look hollow; going higher makes the SVG very large without much visual gain.
- `tinyFont: 4` — fixed. Lower makes individual characters unreadable; higher just inflates the SVG.
- ViewBox is always `1000×1000`. Do not change.

## Generation workflow

```bash
# 1) Generate the 3 hero SVGs
cd /your/project
node ~/.claude/skills/guizang-social-card-skill/scripts/typogram/dianyunstyle-batch.mjs
# writes: typo-p01.svg, typo-p02.svg, typo-p03.svg in CWD

# 2) Render via Playwright
node render-info-graph.mjs   # per-project script; not part of skill
```

For custom topics (not the default "MEMORY / CLAUDE-MEM etc."), edit `dianyunstyle-batch.mjs` CLI block or import the functions and pass your own words.

## Identity test for this template

Passes the standard Swiss identity test (`style-system.md`) with one deviation documented:

- ✅ Inter/Noto Sans SC/IBM Plex Mono only, no serif.
- ✅ Hairline rules (`.line`, `.line-dash`), no shadows.
- ✅ Single accent (Ink Classic — `--ink` on warm paper).
- ⚠️ Display title weight is **900**, not the standard Swiss 200–400. This is an intentional deviation because the **bitmap hero** carries the visual weight (it's a dense bitmap of thousands of small letters, which already reads as "the heavy thing on the page"). If you lower the title weight to 300, the bitmap hero becomes the only heavy element and the page reads as "two heroes competing." If you want true Swiss weight, use the standard `template-swiss-card.html` instead.

## Known limitations

- The 5×7 bitmap font is hand-built; non-Latin characters are not supported. Pass English / pinyin / 0-9 digits only.
- Variant `staircase` is currently tuned for 7 steps. For 4 steps or 12 steps, adjust `heights` array length and the `colWidth` calc accordingly.
- Variant `compare` currently uses 4 quadrants. For 3-way or 6-way comparisons, edit `variantCompare()` directly — there's no parameter for quadrant count.

## Example projects that use this template

- `~/.openclaw/workspace/info-graph-codex/` — 3-page set on "multi-machine multi-agent memory" (Aug 2026, validated by yang).

When you build a new project with this template, drop a one-line note here so the next user can see prior art.