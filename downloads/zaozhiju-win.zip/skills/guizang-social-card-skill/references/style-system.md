# Style System

This skill extracts Guizang PPT visual principles for static social images. It does not depend on the original PPT templates.

## Shared Rules

- Content shape decides layout. Do not pick a pretty layout first and invent content to fit it.
- Use strong hierarchy: title, hook, evidence, caption, metadata.
- Use real images as evidence or atmosphere, not decoration.
- Avoid visible clutter: no random SVG circles, oval drops, blobs, bokeh, ornamental stickers, fake diagram decorations, or decorative gradients.
- Keep all pages in a package visually related through grid, typography, palette, and recurring metadata.
- Every page should have a clear focal point.

## Style ↔ content type are decoupled

The two modes below are **visual stances, not content categories**. Any topic can be rendered in either mode — what changes is the page's feel and which structural devices are available (ledger / marginalia / pull quote vs matrix / KPI tower / h-bar). Pick by editorial intent ("feature story" vs "release note" / "system explainer"), not by topic lookup. The lists below are *good fits*, not exhaustive.

## Mode A: Editorial Magazine x E-ink

Good fits: outdoor, lifestyle, reflective, humanistic, cultural, narrative — but also workplace essays, AI think-pieces, product retrospectives, anything that wants a slow magazine-feature pace.

Visual anchors:

- Serif or Songti-like display title plus quiet sans-serif body text.
- Warm paper, deep ink, refined greys, restrained color.
- WebGL or procedural ink/contour atmosphere, especially on covers, dividers, pull quotes, and sparse pages.
- Documentary photography, field-note captions, issue labels, page numbers.
- Large but purposeful whitespace.
- Fine rules, magazine columns, image captions, pull quotes, and editorial contrast.
- Subtle paper texture is allowed; it must not lower text readability.

Use one of the 6 magazine palettes in `theme-presets.md`. Do not improvise arbitrary warm paper colors. Five palettes are light (paper-and-ink); one — **Midnight Ink** — is the only sanctioned dark variant, reserved for content where the source imagery is already dark (game art, night photography, cinematic covers). Do not invent a second dark palette.

**Typography stance — "the larger, the lighter."** This rule is non-negotiable for Editorial. Display titles run at **weight 500** with **wide tracking** (`+.03em` to `+.04em`). Small text (kicker, meta, label) is the *only* place where weight 500 is paired with mono uppercase and wide letter-spacing (`+.20em` to `+.22em`). Body uses **serif-zh**, not sans. The anti-pattern — 700 to 900 weight display, sans body, negative tracking — collapses Editorial into a generic "infographic banner" look. If a page feels heavy or shouty, the title is too bold or the body switched to sans. See `local-tests/demo-showcase/editorial.html` for source-of-truth.

Layout patterns:

- Cover: big title top or left, large photo/image evidence, bottom checklist or issue-strip.
- Feature page: one large image plus a narrow column of compressed explanation.
- Checklist page: editorial header, numbered items, one supporting image crop or icon-free diagram.
- Quote/takeaway page: large pull quote with small source/context row.
- Comparison page: two-column tension, simple labels, one visual anchor.

Background rule:

- A flat paper color is not enough for this mode. Use a layered background from `background-systems.md`: paper base, subtle grain, ink wash or contour field, and optional WebGL canvas. The background should create atmosphere while keeping text readable.

## Mode B: Swiss International

Good fits: AI tools, product updates, engineering workflows, software explainers, release notes, comparison posts — but also travel ledgers, expense logs, fitness data, recipe step counts, anything that wants a engineered/quantified pace. Topic is not the gate; visual stance is.

Visual anchors:

- Inter, Helvetica Neue, Noto Sans SC feeling.
- Very light display weights for huge type; stronger weights for small labels.
- Strict 12/16-column grid, left alignment, asymmetric whitespace.
- White/off-white, black, refined greys, exactly one high-saturation accent.
- Straight modules, hairline rules, no rounded cards, no shadows, no glassmorphism.

Use one of the 4 Swiss accent palettes in `theme-presets.md`. One package gets exactly one accent.

Rules:

- Use one accent only. Do not mix blue, yellow, green, and orange.
- Avoid gradients. Use pure color blocks, hairline rules, and grid modules.
- Headings usually sit on the top-left content axis, not center, except special square covers or explicit poster compositions.
- Huge text should be lighter; small text should be heavier.
- Images are proof blocks. Use straight edges and stable aspect-ratio containers.

Typography guidance:

| Role | Size Guidance | Weight |
| --- | --- | --- |
| Main cover title | 84-128px on 1080x1440 | 200-400 |
| Page title | 52-82px | 300-500 |
| Body copy | 28-42px | 400-500 |
| Captions/meta | 20-28px | 500-650 |

Chinese titles are visually dense. Shorten first, then reduce size. Do not solve overflow by shrinking body text below readability.

### Sub-style: Dianyunstyle

A Mode B derivative where the page's visual weight lives in a **bitmap-cluster SVG hero** (every glyph is literally a "cloud of dots" built from thousands of small characters), not in the display title. The hero comes in **three variants** — `cover` (central glyph + ghost halo + 4 radial arms), `compare` (4 quadrant blocks meeting at a VS badge), `staircase` (N bitmap columns of decreasing height) — so a 3-page set reads as introduction → discussion → execution instead of "one trick repeated three times."

See `template-dianyunstyle.md` for the template spec, hero parameters, when-to-tune-what, and the Swiss identity test deviation note (display title weight is intentionally 900 here, not 200–400, because the bitmap hero already carries the visual weight).

Assets: `assets/dianyunstyle-templates/template-dianyunstyle.html` + `scripts/typogram/dianyunstyle-batch.mjs`.

## Mode C: Neo-Brutalist Yingce

Good fits: 工具/方法论/教程/产品评测/复杂概念拆解/系统设计 — 任何需要"高信息密度 + 强视觉冲击 + 强观点"的场景。也可用于情绪化宣言、品牌主张、风格化叙述。**Topic 不是门槛，视觉立场是。**

视觉锚点（5 个识别符，缺一不可）：

- **米黄纸底 + 点阵底纹**（`#FAF3E0` 纸 + `#E8DCC0` 点阵 18×18px），纸面不纯白
- **3-4px 黑色硬描边** + **6-8px 6-8px 0 ink 硬阴影**（零圆角、零模糊）
- **错位色块标题**（±5-10px 旋转、两个色块错位叠在标题上方/侧）
- **签名装饰**（▲ 黄色三角 / ⭐ 5 角星 / 蓝色斜纹方块 / 粉色破洞圆环）
- **6 色高饱和限定色板**（不允许出现"近似色"过渡）

### 6 色限定色板（整组卡只用 6 色）

| 角色 | 色值 | 用途 |
|---|---|---|
| 纸 | `#FAF3E0` | 背景底色 |
| 副纸 | `#F0E5C8` | 表格奇行 / 浅块 |
| 墨 | `#1A1A1A` | 描边 / 正文 / 黑底块 |
| 黄 | `#FFD60A` | 主 accent / 数字标签 / 高亮 |
| 粉 | `#FF3D7F` | 强对比 accent / 警告 |
| 蓝 | `#0027D6` | 数据 / 链接 / 第三 accent |
| 绿 | `#1FE0A8` | 强调 / 成功 / 第四 accent |
| 橙 | `#FF6B1A` | 警告 / 危险 / 第五 accent |
| 白 | `#FFFFFF` | 黑底上的文字 / 副 accent |

**所有颜色必须从这 9 个变量里选。** 不允许"看起来差不多"的灰、米、棕等过渡色——所有颜色必须从色板里精确取色。

### 字号体系（密→疏→密节奏）

| 角色 | 大小 | 字重 | 字体 |
|---|---|---|---|
| Mega 标题（封面） | 96px | 900 | Noto Sans SC |
| XL 标题 | 64-78px | 900 | Noto Sans SC |
| L 段标题 | 44px | 900 | Noto Sans SC |
| M 卡片主数字 | 28-54px | 900 | Inter |
| 副数字 | 24-34px | 900 | Inter |
| S 标签 / kicker | 10-14px | 600-700 | IBM Plex Mono |
| 正文 | 13-15px | 500-700 | Noto Sans SC |

**字号反差必须强。** 不允许所有字号都接近 14-18px。

### 节奏规则

- **每张卡 = 完整小故事**：钩子（HEADER）→ 论证（主体）→ 收束（TAKEAWAY）
- **节奏密→疏→密**：HEADER 密、主体中等、TAKEAWAY 密收
- **每张卡 1 个主命题**：不允许多主命题堆叠
- **不偷懒的 typography**：不允许字号一致 / 行高一致 / 字重一致
- **错位色块**：标题上下各 5-10px 错位、旋转 -1.5°~1.5°

### Layout patterns

| Pattern | 用途 | 例子 |
|---|---|---|
| HEADER + 数字瀑布 | 起点事实 | Karpathy 3 文件 / 630 行 / 700 实验 |
| HEADER + 4 列对照 | 对比 / 分类 | 4 类循环 / 4 笔账 |
| HEADER + 决策矩阵 | 选择决策 | 4 类循环对照 / DO/DON'T |
| HEADER + 主线 + 旁线 | 双论证 | 原文金句 + 新员工类比 |
| HEADER + 数字带 | 关键数据 | 8 个数字瀑布 |
| HEADER + 索引网格 | 总览导览 | 7 卡索引 |
| HEADER + 4 层级 | 抽象分级 | 提示词/上下文/Harness/循环 |

### 何时用 Neo-Brutalist Yingce

✅ **适合**：
- 内容是工具/方法论/教程/产品评测
- 需要高信息密度（漏信息 = 失败）
- 主命题需要"强观点"传达
- 想做风格化、不"AI 感"的内容
- 配合案例 / 数字 / 流程图

❌ **不适合**：
- 哲学 / 思辨 / 文学 — 用 Mode A
- 单纯数据展示 / 流水账 — 用 Mode B
- 期刊 / 周报 / 多论文综述 — 用 Mode D
- 访谈 / 双语 / 时序 — 用 Dialogue Poster
- 需要"柔和、高级感"的内容

### Identity test

一张卡是 Neo-Brutalist Yingce 当且仅当 **全部成立**：

1. 纸底 `#FAF3E0` + 点阵底纹（不纯白）
2. 至少 1 个元素有 3-4px 黑边 + 6px 硬阴影
3. 标题字号 ≥64px + 至少 1 个错位色块
4. 至少 1 个签名装饰（▲ / ⭐ / 斜纹方块 / 破洞圆环）
5. 颜色仅从 6 色色板里取（+ 纸/副纸/白/黑 = 9 色）
6. 每张卡只服务 1 个主命题

### 复用保证（重要）

**下次复用与本次一致**：
- 6 色色板变量必须保留（不改成近似色）
- 字号体系必须保留（96/64/44/28/18/14/13/11）
- 节奏规则必须保留（密→疏→密）
- 工具函数（`page` / `chrome` / `deco` / `render`）签名必须不变
- 共享脚本路径（`shared.css` / `tools.js` / `build.mjs`）必须保留

**结构根据内容来**：模板提供骨架，**不强加固定结构**——下次内容不同，卡片数 / 分块方式自然不同。

### 沉淀资产

- 共享 CSS：`assets/neo-brutalist-yingce-templates/shared.css`（7185 B · 完整视觉规则）
- 共享工具：`assets/neo-brutalist-yingce-templates/tools.js`（7387 B · `page` / `chrome` / `deco` / `render`）
- 项目入口：`assets/neo-brutalist-yingce-templates/build.mjs`（760 B · 渲染入口模板）
- 使用文档：`references/template-neo-brutalist-yingce.md`（沉淀后）

## Mode D: Newspaper Weekly (报纸风格 · 单一固定)

Good fits: 周报 / 多论文综述 / 期刊 / arXiv 论文解读 / 阶段总结 — 任何需要"一期周刊"感的内容。**Topic 不是门槛，视觉立场是。**

**单一固定模板**——不像 Mode A/B/C 那样换 accent palette。报纸风的红色 accent 是身份识别符，不允许换色。

视觉锚点：

- **DM Serif Display italic**（主标题 / 报头）+ **Noto Serif SC**（中文正文）+ **JetBrains Mono**（元数据 / 期号 / 版次）
- **米色报纸底** `#f5f1e6` + **墨黑** `#1a1a1a` + **错红** `#c53f3f`（**唯一 accent**，不允许换）
- **报头 / 期号 / 版本 / metadata 保留英文作为格式感骨架**；arXiv ID 必须配中文一句话机制概括
- **论文 № + arXiv ID + 中文副标** 的三段式
- **三列双线报头 + 2×2 paper grid + 3-up figure strip + editor's note** 的版面

**核心规则（2026-07-30 用户约束）**：

- ★★★ **中文优先**：主标题/副标/论文标题/摘要/editor's note **必须中文**；报头/线程号/期号/版次/metadata 保留英文作为格式感骨架
- ★★★ **内容必须干**：每篇 paper 至少要有一个具体数字（×X% / +X 分 / 8K 等）、一个机制名、一个对比或一个关键发现

### 配色（单 accent，不允许换）

| 角色 | 色值 |
|---|---|
| 报纸底 | `#f5f1e6` |
| 墨黑 | `#1a1a1a` |
| 错红（accent） | `#c53f3f` |

红色用于：星标 / kicker / figure numbers / 签名 / paper № / `.tag` 边框。

### 字号体系

| 角色 | 大小 | 字重 | 字体 |
|---|---|---|---|
| 主标题 | 56-72 px | 700-900 italic | DM Serif Display |
| 论文 h2 标题 | 22-28 px | 700 | Noto Serif SC |
| 摘要正文 | 14-15 px | 400-500 | Noto Serif SC |
| 报头 / 期号 / 版次 | 10-13 px | 600-700 mono | JetBrains Mono |
| Tag / 机制 / 数字 | 11-13 px | 700 | Noto Sans SC / mono |

### Layout patterns

- **v14 单列流**（2026-07-30 推荐默认）：报头 → 顶部块（headline + deck + 1 张主题 hero）→ 4 篇论文**纵向单列**。每篇 paper 内部用 3 行 body：**机制 ▸ / 数据 ▸ / 影响 ▸**（mono 红色标签 + 中文一行）。底部只放黑底 footer，**不放 3 张 figures 墙**。
- **旧 2×2 grid**：仅在"展示卡片而非阅读"场景用（如杂志封面 / 内页卡片墙）。

### 4 张内容卡的论文分配（避免重复）

每张 4 格里 = 2 真论文 + 2 经验笔记（最常见）/ 4 真论文（理想）。当多张卡都涉及同一主题时（如模型 / 评测），把"经验笔记"分配到不同的卡里，让论文不重复出现。

### 何时用 v14 vs 旧 2×2

| 用 v14 单列流 | 用旧 2×2 grid |
|---|---|
| 4 篇以上论文 | 展示卡片而非阅读 |
| 中文长摘要 | 杂志封面 / 内页卡片墙 |
| 想强调"读物感" | |

**默认就用 v14 单列流。**

### 沉淀资产

- 模板：`assets/template-newspaper-weekly.html`
- 单 accent：`#c53f3f` 红色，不允许换
- 中文优先 / 内容必须干 是硬约束

## Mode E: Dialogue / Interview Column (荧光绿 · 单一固定风格)

Good fits: 访谈专栏 / 对话节目 / 双语对照 / 时序叙事 / 名人问答。**单一固定的品牌识别风格**——不像 Mode A/B/C 那样换 accent palette。

视觉锚点：

- **pale lime 荧光绿块** `#d6f5b8`（**品牌签名色，不允许换**）
- **Noto Serif SC + Inter + JetBrains Mono** 的中英文混排
- **强网格**（双列、双段、左侧宣言 + 右侧详述）
- **双语对照**（中英并列，左中右英）

**核心规则**：

- pale lime `#d6f5b8` 是品牌签名，**永远不换成别的绿**
- 双语是核心识别符，**不能去掉英文只剩中文**
- 访谈时间轴 / 问题编号 / 引用块 是必须有的视觉元素

### Recipes

参考 `references/template-dialogue-poster.md`：

- **D01 封面**（cover）：单色 lime 块 + 大标题 + 嘉宾照
- **D02 高密度双语内容**（500-1000 字论证页）
- **D03 时序 / 线索地图**（ledger / thread map）

### 配色（单 accent，不允许换）

| 角色 | 色值 |
|---|---|
| Lime 块（主品牌色） | `#d6f5b8` |
| 墨黑 | `#1a1a1a` |
| 背景 | `#FAFAF7` 或 `#FFFFFF` |
| 副 accent | `#FF6B1A` 橙（可选，少量） |

### 沉淀资产

- 模板：`assets/template-dialogue-poster.html`
- 使用文档：`references/template-dialogue-poster.md`

## Mode F: Paper Brief (论文快报 · 单一固定)

Good fits: 单篇论文 / 期刊文章的「一句话情报卡」/ arXiv 单篇深读 / 研究周报「本周推荐 1 篇」 / 学术播客封面 — 任何想用"论文卡片"代替"文字海报"的内容。**Topic 不是门槛，视觉立场是。** **单一固定模板**——不像 Mode A/B/C 那样换 accent palette。整组卡只能用 8 色限定色板 + 5 段固定结构。

视觉锚点（7 个识别符，缺一不可）：

- **米白纸底** `#F1ECDD` + 轻量 radial 颗粒（不纯白）
- **黑色顶 header 块** + **右上斜切角**（`clip-path: polygon(0 0, 100% 0, 100% 64%, 78% 100%, 0 100%)`）
- **暖瑰珀黄三角 ▶** `#F2C94C` accent（出现在英文 title 前）
- **ABSTRACT 框**：白底 + 1px 黑细边 + 顶部「ABSTRACT」标签条 + 右上三圆点
- **KEY FINDINGS 区**：01/02/03 黑底白字圆形编号 + 粗体短标签 + 解释文字（3 条）
- **一句话总结黑底白字横条**（收束段）
- **底部 Footer**：条码「PAPER BRIEF」+ DOI + VOL，顶部黑细线分割

**核心规则**：

- ★ 标题必须用**英文**（Playfair Display italic 900），不是中文（abstract body 才用中文）
- ★ KEY FINDINGS 必须是**中文**短标签 + 解释（1 行 / 条，3 条）
- ★ 一句话总结必须中文、< 35 字
- ★ 暖瑰珀黄三角是身份识别符，**不允许换成其他色**
- ★ 黑色顶块斜切角是身份识别符，**不允许去掉**

### 配色（8 色 + 可选 1 个强调橙）

| 角色 | 色值 |
|---|---|
| 纸 | `#F1ECDD` |
| 副纸 | `#E8E2CF` |
| 墨 | `#141414` |
| 奶白 | `#F7F2DF` |
| 线 | `#1A1A1A` |
| 深灰 | `#2A2A2A` |
| 浅褐灰 | `#8A8576` |
| 暖瑰珀黄（唯一 accent） | `#F2C94C` |
| 强调橙（可选，仅警告） | `#FF6B1A` |

**所有颜色必须从这 9 个变量里精确取色。** 不允许「看起来差不多」的过渡米/灰。

### 字体体系（4 个家族 · 不能加新）

| 角色 | 字体 |
|---|---|
| Brand name / Footer VOL / Authors meta | Inter |
| Header subbrand / Abstract body / Finding body / Takeaway | Noto Serif SC |
| Issue / Date strip / Journal meta / Abstract label / Finding num / Footer DOI / Barcode text | JetBrains Mono |
| Title（英文斜体大字） | Playfair Display italic 900 |

### 字号体系（密 → 疏 → 密）

| 角色 | 大小 | 字重 | 字体 |
|---|---|---|---|
| Brand name | 64px | 900 | Inter |
| Header subbrand | 24px | 500 | Noto Serif SC |
| Issue / N | 22px | 700 mono | JetBrains Mono |
| Date strip | 16px | 700 mono | JetBrains Mono |
| Title（英文） | 46px | 900 italic | Playfair Display |
| Journal meta | 14px | 700 mono | JetBrains Mono |
| Authors meta | 14px | 500 | Inter |
| Abstract body | 18px | 400 | Noto Serif SC |
| Abstract label | 14px | 700 mono | JetBrains Mono |
| Finding num | 13px | 700 mono | JetBrains Mono |
| Finding body | 17px | 400 | Noto Serif SC |
| Takeaway | 20px | 500 | Noto Serif SC |
| Footer DOI | 13px | 500 mono | JetBrains Mono |
| Footer VOL | 22px | 800 | Inter |

### 5 段固定结构（顺序不能调换）

1. **HEADER** — 黑色顶块 + 斜切角 + Brand + Issue + Subbrand（3 行）
2. **DATE STRIP** — 米色日期条 + 横划线（左右各一个 - 装饰）
3. **TITLE** — 三角 ▶ + 英文斜体大标 + 期刊号/作者 meta 横划线
4. **ABSTRACT** — 白底 1px 黑边框 + 顶部「ABSTRACT」标签条 + 三圆点 + 中文摘要（可含 `<span class="pb-mark">高亮</span>`）
5. **KEY FINDINGS** — 01/02/03 编号圆形块 + 粗体短标签 + 解释文字（固定 3 条）
6. **TAKEAWAY** — 黑底白字横条（收束）
7. **FOOTER** — 条码「PAPER BRIEF」+ DOI + VOL

> 实际是 5 段内容 + Header/Footer 骨架 = **7 块视觉元素**。
> 5 段是数据驱动（填什么出什么），Header/Footer 是骨架固定（必须保留）。

### 何时用 Paper Brief vs 其他 Mode

| 用 Paper Brief | 用其他 Mode |
|---|---|
| 单篇论文情报卡 | 多论文综述 → Mode D Newspaper Weekly |
| arXiv 单篇深读 | 工具 / 方法论 → Mode C Neo-Brutalist |
| 期刊文章快读 | 访谈 / 双语 → Mode E Dialogue |
| 研究周报「本周 1 篇」 | 简单数据可视化 → Mode B Swiss |

### Identity test

一张卡是 Paper Brief 当且仅当 **全部成立**：

1. 米白纸底 `#F1ECDD` + 黑色顶 header 块（带斜切角）
2. 暖瑰珀黄三角 ▶ 装饰出现在 title 前
3. ABSTRACT 框存在：1px 黑边 + 顶部「ABSTRACT」标签条 + 右上三圆点
4. KEY FINDINGS 区有 01/02/03 编号圆形块（黑底白字）
5. 一句话总结是黑底白字横条
6. 颜色仅从 8 色色板里取（+ 可选 1 个橙 `#FF6B1A` 单次警告）
7. 字体只用 Inter + Noto Serif SC + JetBrains Mono + Playfair Display 4 个家族

### 复用保证（重要）

**下次复用与本次一致**：

- 8 色色板变量必须保留（不改成近似色）
- 字号体系必须保留（64/46/24/22/20/18/17/16/14/13）
- 5 段结构顺序不能调换
- 4 字体家族不能加新
- 工具函数（`page` / `chrome` / `render` / `generateBarcodeBars`）签名必须不变
- 共享脚本路径（`shared.css` / `tools.js` / `build.mjs`）必须保留

### 沉淀资产

- 共享 CSS：`assets/paper-brief-templates/shared.css`（完整 8 色色板 + 字号体系 + 节奏规则）
- 共享工具：`assets/paper-brief-templates/tools.js`（`page` / `chrome` / `render` / `generateBarcodeBars`）
- 项目入口：`assets/paper-brief-templates/build.mjs`（数据字段填法 + 渲染示例）
- 使用文档：`references/template-paper-brief.md`（完整 spec + identity test）

## Image Rules

- Photos: crop with intent. Keep faces, hands, products, and main objects in safe areas.
- Product screenshots: preserve text; use `object-fit:contain` when detail matters.
- Hardware photos: make the object a first-viewport signal. The photo should be large enough to inspect.
- Generated images: generate only the image content, not the final poster with text.
- Do not make generated images include page chrome, titles, borders, captions, or fake UI unless required by the concept.

## Bad Smells

Revise if you see:

- A page that looks like a generic template with the article pasted in.
- Large empty lower area across multiple pages.
- Decorative shapes that do not explain anything.
- Screenshots too small to read.
- Inconsistent margins between pages.
- Blue text on black or dark photo with poor contrast.
- A 1:1 cover that is a cramped crop of a 21:9 cover.

## Style Identity Test

A poster compiles cleanly long before its style identity is right. Run this test on every page before delivering.

### Swiss identity test

A poster is Swiss only if **all four** hold:

1. Every large display title (>=72px on 1080x1440) uses a typed class from `components.md` (`.h-hero` / `.h-statement` / `.h-xl` / `.num-mega`). Its computed `font-weight` is `<=300`.
2. No serif family is loaded in the document head. No element uses `font-family: serif` or `Noto Serif SC` / `Playfair Display`.
3. Section separators are hairline rules (1-2px) or grid gutters, not card borders + drop shadows.
4. Exactly one accent palette is in use. No mixed accents across pages.

If any one of these fails, the poster is not Swiss — it is generic editorial or "Swiss-flavored card". Fix it or relabel the package.

### Editorial identity test

A poster is Editorial only if **all three** hold:

1. The background has at least one atmosphere layer beyond a flat fill: paper grain, ink wash, frozen WebGL canvas, or contour field (see `background-systems.md`). A page-wide solid `#f3f0e8` with nothing on top is not Editorial.
2. The display title uses a serif-zh / serif-en family (`Noto Serif SC` / `Songti SC` / `Playfair Display`).
3. The poster contains at least one of: a large photo well, a serif pull-quote with em-italic English, a left/right marginalia column, or a ledger with real magazine row hierarchy.

If a poster has a serif title, mono labels everywhere, structured pill grids, and a flat paper background — it is **Swiss-with-a-serif**, not Editorial. Either add atmosphere + magazine structure, or switch the package to Swiss honestly.

## Anti-Patterns From Real Demos

These all rendered without errors and looked plausible in isolation, but failed once compared against a clean reference.

### Anti-pattern A: thick big title in Swiss

```html
<!-- WRONG: inline 700-800 weight on a huge title -->
<h1 style="font-size: 92px; font-weight: 800">如果只能留 5 个,我留这些。</h1>

<!-- RIGHT: typed class, automatic 200-300 weight -->
<h1 class="h-statement">如果只能<br>留 <em>5 个</em>,<br>我留这些。</h1>
```

"The larger, the lighter" is a hard rule. A 90px h1 at weight 700+ instantly downgrades the design from Swiss International to generic landing-page editorial. Always reach for `.h-hero` / `.h-statement` / `.h-xl` / `.num-mega`. Do not bypass them with inline `font-size` + `font-weight`.

### Anti-pattern B: Editorial without atmosphere

A page with all of the following looks Swiss-in-disguise even if you intended Editorial:

- Single flat paper color, no grain, no ink wash, no WebGL,
- Mono labels (`IBM Plex Mono uppercase`) on every kicker, foot, pill, and row label,
- A serif headline floating alone with no large image, pull quote, or marginalia column.

Fix by **one** of:

- Add the paper grain + ink-wash background per `background-systems.md`.
- Replace mono labels with serif / italic micro copy.
- Introduce a large photo or serif pull quote with column structure.
- Switch the package to Swiss honestly — the content might want Swiss.

### Anti-pattern C: footer overlap (closing essay collides with `.foot`)

When `.foot` or `.issue-strip` is positioned with `position: absolute; bottom: ...`, any content above that grows past its expected height crashes through the footer. Use one of these safe patterns instead:

```css
/* Pattern A — flex column. Foot is the last child, pushed by margin-top: auto. */
.poster .pad { display: flex; flex-direction: column; height: 100%; }
.poster .foot { margin-top: auto; }

/* Pattern B — grid with fixed footer row. */
.poster .pad { display: grid; grid-template-rows: auto 1fr auto; height: 100%; }
```

Both seed templates already use Pattern A. Preserve it. If a recipe truly needs an absolutely-positioned foot, reserve `padding-bottom: <foot-height + 24px>` on the content container.

### Anti-pattern D: full-bleed photo with title crossing the subject

The poster looks dramatic at 100% zoom and unreadable at thumbnail size. Two common subfailures:

- A hero photo covers the entire poster, the title sits directly on whatever pixel happens to be behind it. The image's own brightness varies across the canvas, so the title is legible in some bands and invisible in others.
- A mask layer is present but only on one band (bottom), while the subject's face was pushed to the top by `object-position: center top`. The display title lands across the face.

Both pass HTML linting; both fail the thumbnail readability test.

Fix by following `image-overlay.md`:

1. **Qualify the photo first.** It needs a low-detail quiet zone and restrained light. If it fails, switch to a framed-photo recipe instead of forcing text on top.
2. **Map the subject before placing the title.** Read the image, describe in plain language where the face/focal feature sits, record the subject map as an HTML comment next to the hero block. Place text only in documented safe zones.
3. **Match `object-position` to subject location** — see the table in `image-overlay.md`. Never leave it at default for face / hero shots.
4. **Thumbnail test** — render the PNG, downscale to 360 px wide, and look at the title. If it fights the photo, add a localized, image-toned tint only around the title area; if the photo looks dead, the tint is too heavy or the photo is wrong.

This anti-pattern survives almost every other check because the HTML is valid, the image loads, and the title renders. The only way to catch it is to look at the rendered output at the size readers will actually see it.
