# Template · Neo-Brutalist Yingce (Mode C)

A standalone social card style characterized by **5 identity markers + 6-color palette + high information density + strong opinions**. Built for 1080×1440 vertical social cards (Rednote/Xiaohongshu 3:4) and other vertical-first platforms.

Source-of-truth assets:

- Shared CSS: `assets/neo-brutalist-yingce-templates/shared.css` (7185 B)
- Shared tools: `assets/neo-brutalist-yingce-templates/tools.js` (7387 B)
- Project entry: `assets/neo-brutalist-yingce-templates/build.mjs` (760 B)
- Style identity: `references/style-system.md` → **Mode C: Neo-Brutalist Yingce**
- Content summarization flow: `references/content-summarization-flow.md`
- Content prerequisite: `references/content-summarization-prerequisite.md`

## When to use

Pick Neo-Brutalist Yingce when the content needs **high information density + strong visual impact + strong opinions**. Specifically:

- Topic is **tool / methodology / tutorial / product review / concept decomposition / system design**.
- Reader needs **every key number / name / quote** preserved (missing = failure).
- Editorial intent: "强观点 + 高密度" rather than "柔和 / 高级感 / 哲学".
- Want a **non-AI-feel** style — the 6-color palette + hard edges + 错位色块 reads as "designed by hand", not "AI generated".

**Do not use** for:
- Philosophical / literary content → use Mode A (Editorial).
- Pure data display / release notes → use Mode B (Swiss).
- Periodical / weekly digest / multi-paper → use Mode D (Newspaper Weekly).
- Interview / bilingual / time-series → use Dialogue Poster.
- When the content needs to feel "soft, premium, restrained" → Mode C is **the opposite** of that stance.

## Visual identity — 5 mandatory markers

A card is Neo-Brutalist Yingce **only when all 5 hold**:

1. **米黄纸底 + 点阵底纹** — `#FAF3E0` paper + `#E8DCC0` 18×18 px dot grid. Never pure white.
2. **3-4px 黑色硬描边 + 6-8px 6-8px 0 ink 硬阴影** — zero radius, zero blur.
3. **错位色块标题** — ±5-10 px offset, rotate -1.5°~1.5°, two color blocks stacked beside/over the title.
4. **签名装饰** — at least one of: ▲ yellow triangle, ⭐ 5-point star, blue/white diagonal stripe block, pink broken ring.
5. **6 色高饱和限定色板** — every color from the palette below, no "close enough" greys / beiges / browns.

### 6-color palette (only these colors allowed)

```
--paper:   #FAF3E0   paper / background
--paper-2: #F0E5C8   alt rows / light blocks
--ink:     #1A1A1A   borders / body text / black blocks
--yellow:  #FFD60A   primary accent / number tags / highlights
--pink:    #FF3D7F   strong contrast accent / warnings
--blue:    #0027D6   data / links / tertiary accent
--green:   #1FE0A8   emphasis / success / quaternary
--orange:  #FF6B1A   warning / danger / fifth accent
--white:   #FFFFFF   text on black / tertiary accent
```

**All colors must be taken from these 9 variables.** No arbitrary `#ccc` / `#eee` / `#888` etc.

## Type system

| Role | Size | Weight | Family |
|---|---|---|---|
| Mega title (cover) | 96 px | 900 | Noto Sans SC |
| XL title | 64-78 px | 900 | Noto Sans SC |
| L section title | 44 px | 900 | Noto Sans SC |
| M card primary number | 28-54 px | 900 | Inter |
| Secondary number | 24-34 px | 900 | Inter |
| S label / kicker | 10-14 px | 600-700 | IBM Plex Mono |
| Body | 13-15 px | 500-700 | Noto Sans SC |

**Strong size contrast required.** No "all 14-18 px" pages.

## Rhythm rules

- **Each card = complete mini-story**: hook (HEADER) → argument (body) → closure (TAKEAWAY).
- **密→疏→密 rhythm**: HEADER dense, body medium, TAKEAWAY dense.
- **Each card serves exactly 1 主命题**. No multi-thesis stacking.
- **Typography 不偷懒**: vary sizes / line-heights / weights throughout. No uniformity.
- **错位色块**: title flanked by 2 color blocks, offset 5-10 px, rotated -1.5°~1.5°.

## Anatomy of a card page

```
┌──────────────────────────────────────────┐
│  [黑色硬边 PAGE CHROME]  ← chrome()    │  ← 54 px top, kerning 0.22em
│                                          │
│  HEADER                                  │
│    - 错位色块 (黄色/粉色块, ±5-10px)     │
│    - kicker (§ 01 / 主命题)             │
│    - 标题 (60-78px 黑体加粗)            │
│    - 主旨条 (黑底白字, 加粗)            │
│                                          │
│  BODY (按主命题分块)                     │
│    - 数字瀑布 / 对照表 / 决策矩阵       │
│    - 主线 + 旁线 / 原文金句             │
│    - DO/DON'T / 4 笔账 / 4 层级         │
│                                          │
│  TAKEAWAY (黑底黄字/粉字收尾)            │
│                                          │
│  [黑色硬边 PAGE CHROME 底]              │  ← 64 px bottom, page number
└──────────────────────────────────────────┘
```

## 7 Layout patterns (examples, not exhaustive)

| Pattern | Function | Example |
|---|---|---|
| HEADER + 数字瀑布 | 起点事实 | Karpathy 3 文件 / 630 行 / 700 实验 |
| HEADER + 4 列对照 | 对比 / 分类 | 4 类循环 / 4 笔账 |
| HEADER + 决策矩阵 | 选择决策 | 4 类循环对照 / DO/DON'T |
| HEADER + 主线 + 旁线 | 双论证 | 原文金句 + 新员工类比 |
| HEADER + 数字带 | 关键数据 | 8 个数字瀑布 |
| HEADER + 索引网格 | 总览导览 | 7 卡索引 |
| HEADER + 4 层级 | 抽象分级 | 提示词 / 上下文 / Harness / 循环 |

**Structure follows content.** Don't force a fixed layout — pick the pattern that fits the 主命题.

## Tools API

### `page({ num, title, body, kicker, back })`

Wraps the card body into a complete HTML document (1080×1440 paper, font preloading, shared.css).

```js
import { page } from './tools.js';

const html = page({
  num: 1,
  title: '01 / 起点事实',
  kicker: 'LOOP ENGINEERING · Karpathy',
  back: '详解 Claude 的循环工程 · 7 张卡',
  body: `<div>...</div>`,
});
```

### `chrome({ num, kicker, author, back })`

Renders the top + bottom black chrome (header bar + footer bar with page number). Used internally by `page()`.

### `deco.star(size, color)` / `deco.triangle(size, color)` / `deco.diagBlock(size, c1, c2)` / `deco.ringBroken(size, color)`

Inline SVG decorations. Insert anywhere in the body.

```js
import { deco } from './tools.js';

const body = `
  <div>${deco.star(28, '#FFD60A')}</div>
  <div>${deco.triangle(18, '#FFD60A')}</div>
`;
```

### `render(cards, outDir)`

Playwright-based renderer. Takes an array of `{ num, html }` and writes `card-NN.png` to `outDir`.

```js
import { render } from './tools.js';

await render([
  { num: 1, html: card01Html },
  { num: 2, html: card02Html },
  // ...
], './output');
```

## Project setup (3 files minimum)

```
my-cards/
├── scripts/
│   ├── build.mjs          ← import { render } from './tools.js'; import cards
│   ├── tools.js           ← from skill (copy or symlink)
│   ├── card-01.mjs ~ card-NN.mjs
└── output/                 ← render target
```

### `card-01.mjs` skeleton

```js
import { page, deco } from './tools.js';

const body = `
  <div class="flex col" style="height:100%; gap:18px; padding:8px 0;">

    <!-- HEADER -->
    <div style="position:relative; padding:12px 20px;">
      <div style="position:relative; height:22px; margin-bottom:12px;">
        <div style="position:absolute; top:0; left:0; width:160px; height:18px;
                    background:#FFD60A; border:3px solid #1A1A1A; transform:rotate(-1.4deg);"></div>
        <div style="position:absolute; top:4px; left:150px; width:90px; height:18px;
                    background:#FF3D7F; border:3px solid #1A1A1A; transform:rotate(1.6deg);"></div>
      </div>
      <div class="kicker" style="color:#FF3D7F; margin-bottom:8px; font-size:13px;">§ 01 / 主命题</div>
      <h1 class="title-xl" style="margin:0; font-size:72px; line-height:1.05;">
        一句话核心<span style="color:#FF3D7F;">↘</span>
      </h1>
    </div>

    <!-- BODY blocks -->
    ...

    <!-- TAKEAWAY -->
    <div class="card-hd card-hd-black" style="padding:14px 20px;">
      <div class="mono" style="color:#FFD60A; font-size:12px;">§ TAKEAWAY</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-weight:900; font-size:16px; line-height:1.5; color:#FAF3E0;">
        一句话总结
      </div>
    </div>

  </div>
`;

export const card01 = page({
  num: 1,
  title: '01 / 起点事实',
  kicker: 'LOOP ENGINEERING · 主命题',
  back: '整套主题 · N 张卡',
  body,
});
```

### `build.mjs` skeleton

```js
import { render } from './tools.js';
import { card01 } from './card-01.mjs';
// import { card02 } from './card-02.mjs';
// ...

const cards = [
  { num: 1, html: card01 },
  // { num: 2, html: card02 },
];

render(cards).catch(e => { console.error(e); process.exit(1); });
```

## Generation workflow

```bash
# 1) Setup project
mkdir -p my-cards/scripts
cp ~/.claude/skills/guizang-social-card-skill/assets/neo-brutalist-yingce-templates/shared.css my-cards/
cp ~/.claude/skills/guizang-social-card-skill/assets/neo-brutalist-yingce-templates/tools.js my-cards/scripts/
cp ~/.claude/skills/guizang-social-card-skill/assets/neo-brutalist-yingce-templates/build.mjs my-cards/scripts/

# 2) Install playwright in the project (or use the skill's node_modules)
cd my-cards && npm install playwright

# 3) Write card-XX.mjs (see skeleton above)

# 4) Render
cd scripts && node build.mjs
# → output/card-01.png ~ card-NN.png

# 5) Send to Feishu chat (NOT MEDIA directive!)
cd ../output
lark-cli im +messages-send --user-id <ou_xxx> --image ./card-01.png --as bot
```

## Identity test (must pass all 6)

1. ✅ Paper `#FAF3E0` + 18×18 px dot grid
2. ✅ At least one element has 3-4 px black border + 6 px hard shadow
3. ✅ Title ≥64 px + at least one offset color block
4. ✅ At least one signature decoration (▲ / ⭐ / diagBlock / ringBroken)
5. ✅ Colors only from 6-color palette (no greys / beiges / browns)
6. ✅ Each card serves exactly 1 主命题

If any fails, the card is not Neo-Brutalist Yingce — fix or pick a different Mode.

## Reuse guarantee (important)

**Next-time reuse stays identical to this-time**:

- 6-color palette variables preserved (no color swapping)
- Type system preserved (96 / 64 / 44 / 28 / 18 / 14 / 13 / 11)
- Rhythm rules preserved (密→疏→密)
- Tool function signatures unchanged (`page` / `chrome` / `deco` / `render`)
- Shared script paths preserved (`shared.css` / `tools.js` / `build.mjs`)

**Structure follows content** — template provides skeleton, doesn't impose fixed structure. Different content → different card count and different block layout.

## Known limitations

- 6-color constraint may feel limiting for content that needs finer color differentiation (use Mode B for that).
- High density may overwhelm readers — gauge by user's context (小红书 feed scrolling vs deep-reading).
- Hard shadows + dot grid = strong visual stance — not appropriate for "soft / premium" brands.
- Default body Chinese font is `Noto Sans SC` weight 500-700. For 文学 / 哲学 content, switch to `Noto Serif SC` (loses some Neo-Brutalist feel).

## Provenance

- First created: 2026-08-05, for the 7-card set **详解 Claude 的循环工程**
- Derived from: `loop-engineering-cards` project (in user workspace)
- Skill location: `~/.claude/skills/guizang-social-card-skill/assets/neo-brutalist-yingce-templates/`
- See `references/content-summarization-prerequisite.md` and `references/content-summarization-flow.md` for the content workflow this style was designed to support.