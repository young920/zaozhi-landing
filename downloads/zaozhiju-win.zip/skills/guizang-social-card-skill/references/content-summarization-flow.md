# Content Summarization · 7-Step Flow

> 必读前置：[`content-summarization-prerequisite.md`](./content-summarization-prerequisite.md)
>
> 核心原则：**结构根据内容来，不强加固定结构。**

## 总览

```
Step 0 · 读前提（prerequisite.md）
   ↓
Step 1 · 拿到原文 + 8 种场景识别
   ↓
Step 2 · 列骨架（章节/段落/信息点）
   ↓
Step 3 · 信息地图 → 卡片分配
   ↓
Step 4 · 选风格 Mode（根据内容主命题）
   ↓
Step 5 · 写卡片脚本（结构根据内容来）
   ↓
Step 6 · 渲染 → 验收 → 发飞书
   ↓
Step 7 · 用户反馈 + 沉淀
```

---

## Step 0 · 读前提

读完 [`content-summarization-prerequisite.md`](./content-summarization-prerequisite.md)。重点是：
- 8 种输入场景（A~H）
- `image` 工具调用格式
- 验收标准（信息覆盖清单）

**没读完不开始 Step 1。**

---

## Step 1 · 拿到原文 + 8 种场景识别

### 1.1 拿到原文

来源可能是：
- 用户直接发的文本 / wiki 链接 / 文件
- 飞书 wiki / 飞书文档
- 网页 URL（用 `web_fetch` 拉）
- 视频（用 `ffmpeg` 抽帧 + `image` 读）
- 语音（用 `whisper` 或类似工具转文字）

### 1.2 场景识别

对照 prerequisite 的 8 种场景，**明确说出**当前任务是哪种：
- A 文章+图 / B 文章+配图素材 / C 纯图 / D 截图
- E 视频 / F 长视频 / G 链接 / H 语音转文字

如果是混合（如 G 文章里有 E 视频），每种都做。

### 1.3 必做动作

**读完全文。** 不跳读，不只读标题。读完立刻产出：

```markdown
## 原文骨架
- 全文共 N 章 / M 段 / X 张图 / Y 段视频
- 核心命题：<一句话>
- 涉及人物：<列出所有出现的人名>
- 关键数字：<列出所有数字 + 出处>
- 核心金句：<列出值得保留的原文表达>
```

---

## Step 2 · 列骨架

把原文按章节 / 段落 / 信息点拆开。

### 2.1 章节拆分

对长文，按章节列出（每章标出核心信息点）：

```markdown
## 章节骨架
- § 1: <标题> → 信息点 A, B
- § 2: <标题> → 信息点 C
- § 3: <标题> → 信息点 D, E, F
...
```

### 2.2 图骨架

每张图单独列出（必须用 `image` 读过）：

```markdown
## 图骨架
- 图 1: <位置> / <图注> / 提取信息 X, Y / 舍弃 Z（理由）
- 图 2: <位置> / <图注> / 提取信息 A / 不确定 B（备注）
...
```

**这一步是关键。** 跳过这一步 = 漏信息。

### 2.3 信息点类型清单

把所有信息点分类：

| 类型 | 例子 |
|---|---|
| 人物 | Karpathy / Peter Steinberger / Cherny |
| 数字 | 3 文件 / 630 行 / 700 实验 / 20 改进 |
| 出处 | Anthropic 工程博客 / arXiv 论文 |
| 流程 | ① PICK → ② RUN → ③ SCORE → ④ KEEP |
| 金句 | 原文保留的表达 |
| 对比 | X vs Y |
| 警告 | 流传数字不可信 |
| 类比 | GAN / 银行转账 / 写作者重读草稿 |

---

## Step 3 · 信息地图 → 卡片分配

### 3.1 决定卡片数

**卡片数根据内容来。** 常用区间：
- 3 张（核心三章 / 三角结构）
- 5 张（标准 5 段式）
- 7 张（完整章节对应）
- 9 张（深度内容）

**不固定为 7 张。** 7 张只是因为 loop-engineering-cards 那次是 7 张——下次可能是 3 张或 12 张。

### 3.2 每张卡一个主命题

**每张卡只能服务 1 个主命题。** 多主命题会乱。

主命题类型：
- 概念（评估器 GAN = 独立怀疑者）
- 流程（构建循环 4 步）
- 数字（4 笔账）
- 对比（4 类循环对照）
- 索引（总览导览）
- 行动（今晚从哪里开始）

### 3.3 信息点分配表

```markdown
| 卡 | 主命题 | 信息点 | 必含 | 可舍 |
|---|---|---|---|---|
| 01 | <主命题> | A, B, C | A, B | C |
| 02 | <主命题> | D, E | D | E |
...
```

**关键数字 / 人物 / 出处 → 必含。**
**辅助例子 / 二手引述 → 可舍。**

### 3.4 总览卡

如果卡片数 ≥ 5，**最后一张通常是总览卡**：
- 一句话核心
- 卡片索引
- 关键数字带
- 闭环引用

---

## Step 4 · 选风格 Mode

### 4.1 风格选型

根据内容主命题选 Mode，**不按主题选**。

| 内容主命题 | 适合 Mode |
|---|---|
| 概念 / 哲学 / 思辨 | Editorial Magazine x E-ink（Mode A） |
| 数据 / 系统 / 流程 / 对比 | Swiss International（Mode B） |
| 强视觉 / 风格化 / 教程 / 高饱和情绪 | Neo-Brutalist Yingce（Mode C） |
| 期刊 / 周报 / 多论文综述 | Newspaper Weekly（Mode D） |
| 访谈 / 双语 / 时序 | Dialogue / Interview Column |

### 4.2 配色选型

**一整套只 1 个 accent。** 在 Mode 内选 1 套限定色板。

Neo-Brutalist Yingce 的 6 色色板：
- 黄 `#FFD60A`
- 粉 `#FF3D7F`
- 克莱因蓝 `#0027D6`
- 荧光绿 `#1FE0A8`
- 警示橙 `#FF6B1A`
- 黑 `#1A1A1A`

**整组卡只用 6 色。** 不允许出现"看起来差不多"的灰、米、棕等过渡色——所有颜色必须从 6 色里选。

### 4.3 字号体系

- 标题：`h1` 64-78px
- 主旨条：18-22px
- 卡片主数字：42-54px
- 卡片次数字：24-34px
- 卡片正文：13-15px
- 标签 / kicker：10-12px mono

**字号反差要强**（密→疏→密节奏）。

---

## Step 5 · 写卡片脚本

### 5.1 模板选择

每个 Mode 有对应模板：
- Mode A: `assets/template-editorial-card.html`
- Mode B: `assets/template-swiss-card.html` 或 `assets/dianyunstyle-templates/template-dianyunstyle.html`
- Mode C: `assets/neo-brutalist-yingce-templates/template-neo-brutalist-yingce.html`
- Mode D: `assets/template-newspaper-weekly.html`

**复制模板到项目目录，不要在 skill 根目录写项目。**

### 5.2 脚本结构

```js
import { page, deco } from './tools.js'; // 共享工具

const body = `
  <!-- HEADER -->
  <!-- 主体内容（按主命题分块） -->
  <!-- TAKEAWAY -->
`;

export const card01 = page({
  num: 1,
  title: '01 / <主命题>',
  body,
  kicker: '<KICKER>',
});
```

### 5.3 节奏原则

**结构根据内容来。** 不强加固定结构：
- 短卡（信息少）→ 单列流
- 中卡（信息中）→ 2 列 / 4 列
- 长卡（信息多）→ 多层 grid + 主线 + 旁线

**判断标准**：每张卡看下来像一个完整的小故事（钩子 → 论证 → 收束），不堆砌。

### 5.4 拉松 vs 压缩（用户反馈后）

| 反馈 | 真实意图 | 改法 |
|---|---|---|
| "挤在顶部" | 内容缺 / 框太小 | 拉松：padding 加大 / 字号放大 / 框独立 |
| "底部空白大" | 内容真的少 | 拉松：每个框的展示空间加大 |
| "信息不够" | 漏信息 | 诚实审计原文 + 补回 |
| "差不多" | 收工信号 | 收工 |

**不要凭"看到空白大"就推断"要压缩"。** 先确认空白是"内容缺"还是"被挤压的余白"。

---

## Step 6 · 渲染 → 验收 → 发飞书

### 6.1 渲染

```bash
cd <项目目录>/scripts
node build.mjs
```

`build.mjs` 调 `tools.js` 共享工具 + 每张卡的 `card-XX.mjs` 脚本。

### 6.2 验收清单

**每张图必查**：
- [ ] 尺寸正确（1080×1440 / 3:4）
- [ ] 字号清晰可读（最小 ≥ 11px）
- [ ] 框无重叠 / 溢出
- [ ] 配色只用 1 个 accent（6 色内）
- [ ] 底部空白 < 15% 画布高度
- [ ] 不空也不挤，节奏均匀

**底部空白**：
- < 80px ✅ 优秀
- 80-150px ✅ 良好
- 150-250px ⚠️ 可接受
- 250-380px ❌ 拉松布局
- > 380px ❌ 严重问题

### 6.3 发飞书

**必用 bot 身份 + 相对路径**：

```bash
cd <图所在目录>
lark-cli im +messages-send --user-id <ou_xxx> --image ./card-XX.png --as bot
```

返回 `message_id` 形如 `om_x100b...` = 真正发到聊天。

**反例**（都失败）：
- `MEDIA:/path/to/file.png` ← 飞书不渲染
- 绝对路径 ← 被拒
- `image` 工具返回 ← 用户看不到
- `--as user` ← 默认 scope 不够

详见 `MEMORY.md`（用户工作区）"飞书发图正确姿势"。

---

## Step 7 · 用户反馈 + 沉淀

### 7.1 用户反馈处理

| 反馈 | 处理 |
|---|---|
| "哪里不对" | 先理解意图（挤/漏/拉松/压缩） |
| "差不多" | 收工，**敢停** |
| "漏信息" | 诚实审计原文 → 重写 |
| "再调" | 按反馈调，不擅自扩 |
| "换风格" | 回到 Step 4 选型 |

### 7.2 沉淀时机

**用户说"沉淀"** 时开始：
1. 写前提文档（`content-summarization-prerequisite.md`）
2. 写流程文档（本文件）
3. 写 Mode C 模板（HTML + 配色 + 字号 + 节奏）
4. 抽项目共享脚本到 skill（`shared.css` / `tools.js` / `build.mjs`）
5. 更新 `SKILL.md` 顶部"Core Principle"后插入引用

### 7.3 沉淀的"复用保证"

**下次复用与这次一致**：
- 配色色板变量必须保留（不改成近似色）
- 字号体系必须保留
- 节奏规则必须保留
- 工具函数（`page` / `deco`）签名必须不变

**结构根据内容来**：模板提供骨架，**不强加固定结构**——下次内容不同，卡片数 / 分块方式自然不同。

---

## 决策点速查

| 时刻 | 决策 |
|---|---|
| 拿到输入 | 8 种场景里是哪一种 |
| 读完原文 | 列骨架 + 信息点 |
| 决定卡片数 | 内容决定（3/5/7/9/12） |
| 选风格 | 按主命题选 Mode |
| 写卡片 | 每张 1 个主命题 |
| 渲染后 | 验收清单 6 项 |
| 用户说"差不多" | **收工** |
| 用户说"漏信息" | 诚实审计原文 |
| 用户说"沉淀" | 写前提 + 流程 + 模板 |

---

## 相关文档

- [Prerequisite](./content-summarization-prerequisite.md) — 必读第一份
- [Style System](./style-system.md) — 4 个 Mode 的视觉规则
- [Layout Recipes](./layout-recipes.md) — M01-M16 / S01-S12 卡片结构
- [Production Workflow](./production-workflow.md) — HTML/CSS 渲染和图片处理
- [QA Checklist](./qa-checklist.md) — 最终验收
