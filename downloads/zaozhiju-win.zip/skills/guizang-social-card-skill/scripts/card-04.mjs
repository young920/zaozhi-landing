const card04Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>Neon Nights · 4 区同时在跑</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=JetBrains+Mono:wght@400;700&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    position: relative;
    width: 1080px;
    height: 1440px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    overflow: hidden;
  }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div style="position:absolute; top:48px; left:60px; right:60px; display:flex; justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · Neon Nights 实战</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">04 · 4 区界面</div>
  </div>

  <!-- 主标题 -->
  <div style="position:absolute; top:130px; left:60px; right:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:60px; line-height:1.18; color:#1A1A1A; letter-spacing:-0.02em;">
      Neon Nights<br><span style="color:#E63946;">4 区同时在跑</span>
    </div>
  </div>

  <!-- 副标题 + 红线 -->
  <div style="position:absolute; top:280px; left:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:22px; color:#1A1A1A; margin-bottom:14px;">MCP 实战拆解 · 14696006_1080_1920_24fps.mp4</div>
    <div style="width:200px; height:4px; background:#E63946;"></div>
  </div>

  <!-- 主图 · 不裁切 · 完整展示 · 独立行 · 给够高度 -->
  <div style="position:absolute; top:380px; left:60px; right:60px;">
    <img src="../assets-rendered/11-neon-nights-full.png" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-size:12px; color:#888; letter-spacing:0.06em; margin-top:10px;">▸ Neon Nights · OpenChatCut MCP Demo</div>
  </div>

  <!-- 4 区标注 2×2 · 主图下方独立行 · 间距松 -->
  <div style="position:absolute; top:800px; left:60px; right:60px; display:grid; grid-template-columns:1fr 1fr; gap:18px;">
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="display:flex; align-items:center; gap:6px; margin-bottom:10px;">
        <div style="width:6px; height:6px; background:#888;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#888; letter-spacing:0.12em;">[ A ] LEFT</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:19px; color:#1A1A1A; line-height:1.3; margin-bottom:8px;">Agent workspace</div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#666; line-height:1.6;">edit_item / read_timeline<br>read_project</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="display:flex; align-items:center; gap:6px; margin-bottom:10px;">
        <div style="width:6px; height:6px; background:#888;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#888; letter-spacing:0.12em;">[ B ] CENTER</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:19px; color:#1A1A1A; line-height:1.3; margin-bottom:8px;">素材库 + 工具</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:12px; color:#666; line-height:1.6;">My Media · Library<br>Transcripts · 转场</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A; box-shadow:8px 8px 0 0 #E63946;">
      <div style="display:flex; align-items:center; gap:6px; margin-bottom:10px;">
        <div style="width:6px; height:6px; background:#E63946;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em;">[ C ] RIGHT ★</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:19px; color:#E63946; line-height:1.3; margin-bottom:8px;">预览 + 属性</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:12px; color:#1A1A1A; line-height:1.6;">霓虹夜景渲染<br>1080×1920 · 24fps</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="display:flex; align-items:center; gap:6px; margin-bottom:10px;">
        <div style="width:6px; height:6px; background:#888;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#888; letter-spacing:0.12em;">[ D ] TIMELINE</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:19px; color:#1A1A1A; line-height:1.3; margin-bottom:8px;">4 轨 + 关键帧</div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#666; line-height:1.6;">V2 / V1 / A1 / A2<br>Neon Title · Glitch</div>
    </div>
  </div>

  <!-- PROJECT META 黑底数据带 · 独立行 · 间距松 -->
  <div style="position:absolute; top:1130px; left:60px; right:60px; padding:18px 22px; background:#1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:12px;">▸ PROJECT META</div>
    <div style="display:flex; gap:36px; font-family:'JetBrains Mono',monospace; font-size:13px; color:#F5F5F5; line-height:1.5;">
      <div><span style="color:#888;">FRAME</span> <span style="color:#E63946;">00:03.90</span> / 02:31.46</div>
      <div><span style="color:#888;">RES</span> <span style="color:#E63946;">1080×1920</span></div>
      <div><span style="color:#888;">FPS</span> <span style="color:#E63946;">24</span></div>
      <div><span style="color:#888;">SAFE</span> <span style="color:#E63946;">AREA</span> on</div>
    </div>
  </div>

  <!-- 5 个 stat 横排 · 独立行 · 间距松 -->
  <div style="position:absolute; top:1240px; left:60px; right:60px; padding:16px 0; border-top:1px solid #C8C8C8; border-bottom:1px solid #C8C8C8;">
    <div style="display:flex; gap:32px;">
      <div style="flex:1;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 4 区</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">同时运行</div>
      </div>
      <div style="flex:1;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 3 MCP</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">工具</div>
      </div>
      <div style="flex:1;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 4 轨</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">V2/V1/A1/A2</div>
      </div>
      <div style="flex:1;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> ↩∞</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">HISTORY</div>
      </div>
      <div style="flex:1;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 24fps</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">电影级</div>
      </div>
    </div>
  </div>

  <!-- 底部 -->
  <div style="position:absolute; bottom:48px; left:60px; right:60px; display:flex; justify-content:flex-end; align-items:center; gap:10px; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">04 / 06 · Neon Nights 实战</div>
    <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
  </div>

</div>
</body>
</html>`;

export const card04 = card04Html;
