const card05Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>生成 CounterDown 霓虹倒计时</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=JetBrains+Mono:wght@400;700&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    width: 1080px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    padding: 48px 60px 48px;
    display: flex;
    flex-direction: column;
    gap: 26px;
  }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · CounterDown 实战</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">05 · 霓虹动效</div>
  </div>

  <!-- 主标题 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:72px; line-height:1.18; color:#1A1A1A; letter-spacing:-0.02em;">
      <span style="color:#E63946;">CounterDown</span><br>霓虹倒计时
    </div>
  </div>

  <!-- 副标题 + 红线 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:22px; color:#1A1A1A; margin-bottom:14px;">一句 prompt · 8 秒写进时间线</div>
    <div style="width:200px; height:4px; background:#E63946;"></div>
  </div>

  <!-- USER PROMPT 黑底气泡 -->
  <div style="padding:18px 22px; background:#1A1A1A; border-left:5px solid #E63946;">
    <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:10px;">▸ USER PROMPT</div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:17px; color:#F5F5F5; line-height:1.55;">「生成一个霓虹风格的倒计时 · 100 帧 · 城市天际线背景」</div>
  </div>

  <!-- 主图：完整展示 -->
  <div>
    <img src="../assets-rendered/10-effects-library-counterdown.jpg" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-size:12px; color:#888; letter-spacing:0.06em; margin-top:10px;">▸ Effects Library · CounterDown 预览</div>
  </div>

  <!-- 代码块 + zoom 双图：横向 flex row -->
  <div style="display:flex; gap:24px;">
    <div style="flex:1.4; padding:18px 22px; background:#1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:12px;">▸ TOOL CALL</div>
      <pre style="margin:0; font-family:'JetBrains Mono',monospace; font-size:13px; line-height:1.75; color:#F5F5F5;">name<span style="color:#888;">=</span><span style="color:#E63946;">"Counter 0~99"</span>
style<span style="color:#888;">=</span><span style="color:#E63946;">"neon pink glow"</span>
duration<span style="color:#888;">=</span><span style="color:#F5F5F5;">120</span>
position<span style="color:#888;">=</span><span style="color:#E63946;">"V1:0"</span></pre>
    </div>
    <div style="flex:1; border:1.5px solid #1A1A1A;">
      <img src="../assets-rendered/06-zoom.png" style="display:block; width:100%; height:auto;">
    </div>
  </div>

  <!-- 6 个 stat 横排 -->
  <div style="display:flex; gap:30px; padding:20px 0; border-top:1px solid #C8C8C8; border-bottom:1px solid #C8C8C8;">
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 100</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">帧数</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 120</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">fps · 霓虹</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> WebGL</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">渲染引擎</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 12</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">内置动效</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 8秒</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">改完</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:18px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 3 步</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:10px; color:#666; letter-spacing:0.06em;">开始</div>
    </div>
  </div>

  <!-- 底部 -->
  <div style="display:flex; justify-content:flex-end; align-items:center; gap:10px; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">05 / 06 · CounterDown</div>
    <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
  </div>

</div>
</body>
</html>`;

export const card05 = card05Html;
