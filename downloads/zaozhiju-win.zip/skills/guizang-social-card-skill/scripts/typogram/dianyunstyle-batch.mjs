// typogram-batch.mjs — generate typogram SVG pages for the "typogram-card" template.
//
// Three variants share the same 5×7 bitmap font and the `renderWordBitmap` / `arm`
// helpers. Each variant is the visual centerpiece of one poster page:
//
//   variantCover({ innerWord, ghostWord, arms })
//     Central dense bitmap + ghost halo + 4 radial arms.
//     Use as P01 (COVER) or any "focus / headline" page.
//
//   variantCompare({ quads, centerLabel })
//     4 bitmap blocks in 4 quadrants, meeting at a center "VS" badge.
//     Use as P02 (COMPARE) or any "versus / tradeoffs" page.
//
//   variantStaircase({ steps, kws, heights, headerTop, headerBig })
//     N vertical bitmap columns of decreasing height, captioned with a keyword.
//     Use as P03 (EXEC) or any "sequence / runbook" page.
//
// ViewBox is always 1000×1000. The .typogram-hero container in the template
// is 580×580 — the SVG is scaled to fit. cx=cy=500 throughout.

import { writeFileSync } from 'node:fs';

// ===== 5×7 bitmap font =====
const FONT = {
  A: { glyph: ['01110','10001','10001','11111','10001','10001','10001'], char: 'a' },
  G: { glyph: ['01110','10001','10000','10111','10001','10001','01110'], char: 'g' },
  E: { glyph: ['11111','10000','10000','11110','10000','10000','11111'], char: 'e' },
  N: { glyph: ['10001','11001','10101','10101','10101','10011','10001'], char: 'n' },
  T: { glyph: ['11111','00100','00100','00100','00100','00100','00100'], char: 't' },
  M: { glyph: ['10001','11011','10101','10101','10001','10001','10001'], char: 'm' },
  O: { glyph: ['01110','10001','10001','10001','10001','10001','01110'], char: 'o' },
  R: { glyph: ['11110','10001','10001','11110','10100','10010','10001'], char: 'r' },
  Y: { glyph: ['10001','10001','01010','00100','00100','00100','00100'], char: 'y' },
  S: { glyph: ['01111','10000','10000','01110','00001','00001','11110'], char: 's' },
  H: { glyph: ['10001','10001','10001','11111','10001','10001','10001'], char: 'h' },
  I: { glyph: ['11111','00100','00100','00100','00100','00100','11111'], char: 'i' },
  C: { glyph: ['01110','10001','10000','10000','10000','10001','01110'], char: 'c' },
  D: { glyph: ['10000','10000','11110','10001','10001','10001','11110'], char: 'd' },
  X: { glyph: ['10001','01010','01010','00100','01010','01010','10001'], char: 'x' },
  V: { glyph: ['10001','10001','10001','10001','10001','01010','00100'], char: 'v' },
  P: { glyph: ['11110','10001','10001','11110','10000','10000','10000'], char: 'p' },
  L: { glyph: ['10000','10000','10000','10000','10000','10000','11111'], char: 'l' },
  F: { glyph: ['11111','10000','10000','11110','10000','10000','10000'], char: 'f' },
  U: { glyph: ['10001','10001','10001','10001','10001','10001','01110'], char: 'u' },
  B: { glyph: ['11110','10001','10001','11110','10001','10001','11110'], char: 'b' },
  K: { glyph: ['10001','10010','10100','11000','10100','10010','10001'], char: 'k' },
  W: { glyph: ['10001','10001','10001','10101','10101','10101','01010'], char: 'w' },
  Q: { glyph: ['01110','10001','10001','10001','10101','10010','01101'], char: 'q' },
  Z: { glyph: ['11111','00001','00010','00100','01000','10000','11111'], char: 'z' },
  J: { glyph: ['00001','00001','00001','00001','00001','10001','01110'], char: 'j' },
  '0': { glyph: ['01110','10001','10001','10001','10001','10001','01110'], char: '0' },
  '1': { glyph: ['00100','01100','00100','00100','00100','00100','01110'], char: '1' },
  '2': { glyph: ['01110','10001','00001','00010','00100','01000','11111'], char: '2' },
  '3': { glyph: ['11110','00001','00001','01110','00001','00001','11110'], char: '3' },
  '4': { glyph: ['00010','00110','01010','10010','11111','00010','00010'], char: '4' },
  '5': { glyph: ['11111','10000','11110','00001','00001','10001','01110'], char: '5' },
  '6': { glyph: ['00110','01000','10000','11110','10001','10001','01110'], char: '6' },
  '7': { glyph: ['11111','00001','00010','00100','01000','01000','01000'], char: '7' },
  '8': { glyph: ['01110','10001','10001','01110','10001','10001','01110'], char: '8' },
  '9': { glyph: ['01110','10001','10001','11111','00001','00010','01100'], char: '9' },
};

// ===== Render a word as a bitmap typogram =====
function renderWordBitmap({
  word, x0, y0,
  cellSize = 22,
  clusterSize = 6,
  tinyFont = 4,
  fill = '#2a2825',
  opacityBase = 0.92,
  opacityVar = 0.08,
  letterGap = 1,
} = {}) {
  const parts = [];
  word.split('').forEach((letter, lIdx) => {
    const glyphDef = FONT[letter];
    if (!glyphDef) return;
    const glyph = glyphDef.glyph;
    const char = glyphDef.char;
    const letterOffsetX = x0 + lIdx * (5 + letterGap) * cellSize;

    glyph.forEach((row, rowIdx) => {
      row.split('').forEach((bit, colIdx) => {
        if (bit === '1') {
          const cellX = letterOffsetX + colIdx * cellSize;
          const cellY = y0 + rowIdx * cellSize;
          const step = cellSize / clusterSize;
          for (let cy = 0; cy < clusterSize; cy++) {
            for (let cx = 0; cx < clusterSize; cx++) {
              const x = cellX + (cx + 0.5) * step;
              const y = cellY + (cy + 0.5) * step;
              const op = opacityBase + (((cx + cy + lIdx + colIdx + rowIdx) % 5) / 5) * opacityVar;
              parts.push(
                `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" ` +
                `font-family="Inter, sans-serif" font-weight="800" ` +
                `font-size="${tinyFont}" fill="${fill}" ` +
                `opacity="${op.toFixed(2)}" ` +
                `text-anchor="middle" dominant-baseline="central">${char}</text>`
              );
            }
          }
        }
      });
    });
  });
  return parts.join('\n');
}

// ===== Radial arc of fading keywords =====
function arm({ cx, cy, kw, fromR, toR, baseAngle, sweep, count = 14, sizeStart = 18, sizeEnd = 7, opacityStart = 0.85, opacityEnd = 0.0 }) {
  const a = [];
  for (let i = 0; i < count; i++) {
    const t = count === 1 ? 0.5 : i / (count - 1);
    const r = fromR + (toR - fromR) * t;
    const angle = baseAngle - sweep / 2 + sweep * t;
    const x = cx + r * Math.cos(angle);
    const y = cy + r * Math.sin(angle);
    const size = sizeStart + (sizeEnd - sizeStart) * Math.pow(t, 0.7);
    const op = opacityStart + (opacityEnd - opacityStart) * Math.pow(t, 1.5);
    a.push(
      `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" ` +
      `font-family="Inter, sans-serif" font-weight="800" ` +
      `font-size="${size.toFixed(1)}" fill="#2a2825" ` +
      `opacity="${op.toFixed(2)}" ` +
      `text-anchor="middle" dominant-baseline="central">${kw}</text>`
    );
  }
  return a.join('\n');
}

// =================================================================
// Variant 1 · COVER — central dense + ghost halo + 4 radial arms
// =================================================================
export function variantCover({
  innerWord, innerCell = 22, innerCluster = 6, innerTiny = 4, innerOpacity = 0.92,
  ghostWord, ghostCell = 44, ghostTiny = 22, ghostOpacity = 0.10,
  arms = [],   // [{ kw, fromR, toR, baseAngle, sweep, count?, sizeStart?, sizeEnd?, opacityStart?, opacityEnd? }]
} = {}) {
  const W = 1000, H = 1000;
  const cx = W / 2, cy = H / 2;

  const ghostW = (ghostWord.length * 5 + (ghostWord.length - 1) * 1) * ghostCell;
  const ghostH = 7 * ghostCell;
  const ghost = renderWordBitmap({
    word: ghostWord, x0: cx - ghostW / 2, y0: cy - ghostH / 2,
    cellSize: ghostCell, clusterSize: 1, tinyFont: ghostTiny,
    opacityBase: ghostOpacity, opacityVar: 0.04,
  });

  const innerW = (innerWord.length * 5 + (innerWord.length - 1) * 1) * innerCell;
  const innerH = 7 * innerCell;
  const inner = renderWordBitmap({
    word: innerWord, x0: cx - innerW / 2, y0: cy - innerH / 2,
    cellSize: innerCell, clusterSize: innerCluster, tinyFont: innerTiny,
    opacityBase: innerOpacity, opacityVar: 0.08,
  });

  const armParts = arms.map(a => arm({ cx, cy, ...a })).join('\n');

  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">\n${ghost}\n${armParts}\n${inner}\n</svg>`;
}

// =================================================================
// Variant 2 · COMPARE — 4 quadrant blocks + center VS badge
// =================================================================
export function variantCompare({
  quads,            // [{ kw, ox, oy }] — kw is the keyword, (ox, oy) is quadrant center in 1000×1000 coords
  centerLabel = 'vs',
  blockSize = 360,  // square area each quadrant bitmap occupies (px)
} = {}) {
  const W = 1000, H = 1000;
  const cx = W / 2, cy = H / 2;

  const parts = quads.map((q, idx) => {
    const len = q.kw.length;
    const cellSize = Math.floor(blockSize / (len * 5 + (len - 1))) - 1;
    const w = (len * 5 + (len - 1)) * cellSize;
    const h = 7 * cellSize;
    const x0 = q.ox - w / 2;
    const y0 = q.oy - h / 2;
    // First quadrant slightly bolder to read as "this set"
    const opBase = 0.55 + (idx === 0 ? 0.4 : 0);
    return renderWordBitmap({
      word: q.kw, x0, y0, cellSize, clusterSize: 6, tinyFont: 4,
      opacityBase: opBase, opacityVar: 0.10,
    });
  });

  // Hairline cross at center
  parts.push(`<line x1="0" y1="${cy}" x2="${W}" y2="${cy}" stroke="#2a2825" stroke-opacity="0.18" stroke-width="1.2"/>`);
  parts.push(`<line x1="${cx}" y1="0" x2="${cx}" y2="${H}" stroke="#2a2825" stroke-opacity="0.18" stroke-width="1.2"/>`);

  // Center VS badge
  parts.push(
    `<rect x="${cx-46}" y="${cy-46}" width="92" height="92" fill="#f0ede5" stroke="#2a2825" stroke-width="1.5"/>` +
    `<text x="${cx}" y="${cy+2}" font-family="Inter, sans-serif" font-weight="900" font-size="38" fill="#2a2825" letter-spacing="0" text-anchor="middle" dominant-baseline="central">${centerLabel}</text>`
  );

  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">\n${parts.join('\n')}\n</svg>`;
}

// =================================================================
// Variant 3 · STAIRCASE — N columns of decreasing bitmap height
// =================================================================
export function variantStaircase({
  steps,            // ['01', '02', ...]
  kws,              // ['AUDIT', 'INSTALL', ...] — caption under each column
  heights,          // [380, 340, ...] — column height in px, descending reads as "progress"
  headerTop,        // small uppercase mono label (e.g. '7 STEPS · EXECUTION')
  headerBig,        // big Chinese/English title (e.g. '从零搭建 → 交付')
  paperFill = '#2a2825',
  trailCount = 14,
} = {}) {
  const W = 1000, H = 1000;
  const cx = W / 2, cy = H / 2;

  const parts = [];

  // Ruler line + ticks at column baseline
  const baseline = cy + 220;
  parts.push(`<line x1="60" y1="${baseline}" x2="${W - 60}" y2="${baseline}" stroke="${paperFill}" stroke-opacity="0.35" stroke-width="1.2"/>`);
  for (let i = 0; i < 30; i++) {
    const x = 60 + i * ((W - 120) / 29);
    parts.push(`<line x1="${x}" y1="${baseline - 2}" x2="${x}" y2="${baseline + 4}" stroke="${paperFill}" stroke-opacity="0.25" stroke-width="1"/>`);
  }

  const colWidth = (W - 120) / steps.length;
  steps.forEach((s, idx) => {
    const colCx = 60 + colWidth * (idx + 0.5);
    const h = heights[idx];
    const cellSize = Math.floor(colWidth / 4);
    const stepW = (2 * 5 + 1) * cellSize;
    const x0 = colCx - stepW / 2;
    const y0 = baseline - h;

    parts.push(renderWordBitmap({
      word: s, x0, y0, cellSize, clusterSize: 4, tinyFont: 4,
      opacityBase: 0.88 - idx * 0.05, opacityVar: 0.10,
    }));

    parts.push(
      `<text x="${colCx}" y="${baseline + 30}" font-family="Inter, sans-serif" font-weight="800" ` +
      `font-size="14" fill="${paperFill}" text-anchor="middle" letter-spacing="0.12em">${kws[idx]}</text>`
    );

    // Pixel trail beneath each column — fading dots
    for (let i = 0; i < trailCount; i++) {
      const ty = baseline + (i + 1) * 10;
      if (ty > H - 30) break;
      const t = i / trailCount;
      const op = (1 - t) * 0.65;
      const size = 4 - t * 2;
      parts.push(
        `<circle cx="${colCx}" cy="${ty}" r="${Math.max(0.5, size / 2).toFixed(1)}" ` +
        `fill="${paperFill}" opacity="${op.toFixed(2)}"/>`
      );
    }
  });

  // Header strip
  parts.push(
    `<text x="${cx}" y="80" font-family="Inter, sans-serif" font-weight="800" font-size="22" ` +
    `fill="${paperFill}" letter-spacing="0.3em" text-anchor="middle" opacity="0.85">${headerTop}</text>`
  );
  parts.push(
    `<text x="${cx}" y="120" font-family="Inter, sans-serif" font-weight="900" font-size="44" ` +
    `fill="${paperFill}" text-anchor="middle" letter-spacing="0.06em">${headerBig}</text>`
  );
  parts.push(`<line x1="${cx - 200}" y1="150" x2="${cx + 200}" y2="150" stroke="${paperFill}" stroke-opacity="0.45" stroke-width="1.5"/>`);

  return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">\n${parts.join('\n')}\n</svg>`;
}

// ===== CLI: emit the canonical 3-page set under the current directory =====
if (import.meta.url === `file://${process.argv[1]}`) {
  const p01 = variantCover({
    innerWord: 'MEMORY',
    ghostWord: 'AGENT',
    arms: [
      { kw: 'CLI', fromR: 380, toR: 490, baseAngle: -Math.PI / 4,     sweep: Math.PI / 4, count: 14, sizeStart: 18, sizeEnd: 7, opacityStart: 0.85, opacityEnd: 0.0 },
      { kw: 'IDE', fromR: 380, toR: 490, baseAngle:  Math.PI / 4,     sweep: Math.PI / 4, count: 14, sizeStart: 18, sizeEnd: 7, opacityStart: 0.85, opacityEnd: 0.0 },
      { kw: 'APP', fromR: 380, toR: 490, baseAngle:  3 * Math.PI / 4, sweep: Math.PI / 4, count: 14, sizeStart: 18, sizeEnd: 7, opacityStart: 0.85, opacityEnd: 0.0 },
      { kw: 'WEB', fromR: 380, toR: 490, baseAngle: -3 * Math.PI / 4, sweep: Math.PI / 4, count: 14, sizeStart: 18, sizeEnd: 7, opacityStart: 0.85, opacityEnd: 0.0 },
    ],
  });

  const p02 = variantCompare({
    quads: [
      { kw: 'CLAUDE', ox: 250, oy: 250 },
      { kw: 'MEM0',   ox: 750, oy: 250 },
      { kw: 'GRAPH',  ox: 250, oy: 750 },
      { kw: 'CMEM',   ox: 750, oy: 750 },
    ],
    centerLabel: 'vs',
  });

  const p03 = variantStaircase({
    steps: ['01', '02', '03', '04', '05', '06', '07'],
    kws:   ['AUDIT', 'INSTALL', 'MCP', 'USERID', 'SYNC', 'RULES', 'TEST'],
    heights: [380, 340, 300, 260, 220, 180, 140],
    headerTop: '7 STEPS · EXECUTION',
    headerBig: '从零搭建 → 交付',
  });

  writeFileSync('typo-p01.svg', p01);
  writeFileSync('typo-p02.svg', p02);
  writeFileSync('typo-p03.svg', p03);
  console.log('written 3 typogram SVGs (P01 cover / P02 compare / P03 staircase)');
}