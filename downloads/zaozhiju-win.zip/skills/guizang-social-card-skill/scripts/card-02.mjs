const card02Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>不是聊天框出片 · 是真实工程文件</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=JetBrains+Mono:wght@400;700&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    position: relative;
    width: 1080px;
    height: 1440px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    overflow: hidden;
  }
  .row { display: flex; gap: 32px; }
  .stat { flex: 1; }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div style="position:absolute; top:48px; left:60px; right:60px; display:flex; justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · 范式对比</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">02 · 三种编辑器</div>
  </div>

  <!-- 主标题 -->
  <div style="position:absolute; top:130px; left:60px; right:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:58px; line-height:1.2; color:#1A1A1A; letter-spacing:-0.02em;">
      不是<span style="color:#E63946;">聊天框出片</span><br>是<span style="color:#E63946;">真实工程文件</span>
    </div>
  </div>

  <!-- 副标题 + 红线 -->
  <div style="position:absolute; top:300px; left:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:22px; color:#1A1A1A; margin-bottom:14px;">Premiere · Veo · OpenChatCut · 三种范式</div>
    <div style="width:120px; height:4px; background:#E63946;"></div>
  </div>

  <!-- 三栏对比 · 各栏独立完整 · C 栏用 ::after 模拟硬阴影 -->
  <div style="position:absolute; top:380px; left:60px; right:60px;" class="row">

    <div style="flex:1; padding:24px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:18px;">
        <div style="width:8px; height:8px; background:#888;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:12px; color:#888; letter-spacing:0.12em;">A · 传统剪辑</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:22px; color:#1A1A1A; line-height:1.3; margin-bottom:18px;">
        拖时间线<br>手动精控
      </div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#666; line-height:1.85; margin-bottom:16px;">
        Premiere · Final Cut<br>DaVinci Resolve
      </div>
      <div style="padding-top:16px; border-top:1px solid #E0E0E0; font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#666; line-height:1.6;">
        全靠手 · 学习曲线高<br>无 AI 协助
      </div>
    </div>

    <div style="flex:1; padding:24px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:18px;">
        <div style="width:8px; height:8px; background:#888;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:12px; color:#888; letter-spacing:0.12em;">B · 一次性 AI</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:22px; color:#1A1A1A; line-height:1.3; margin-bottom:18px;">
        出片即结束<br>不可改
      </div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#666; line-height:1.85; margin-bottom:16px;">
        Veo · Sora · Runway<br>可灵 · Pika
      </div>
      <div style="padding-top:16px; border-top:1px solid #E0E0E0; font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#666; line-height:1.6;">
        一句话生成 · 4 秒<br>输出即死
      </div>
    </div>

    <div style="flex:1; padding:24px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A; box-shadow:8px 8px 0 0 #E63946;">
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:18px;">
        <div style="width:8px; height:8px; background:#E63946;"></div>
        <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:12px; color:#E63946; letter-spacing:0.12em;">C · OpenChatCut ★</div>
      </div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:22px; color:#1A1A1A; line-height:1.3; margin-bottom:18px;">
        <span style="color:#E63946;">真实工程文件</span><br>可改 · 可撤销
      </div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#1A1A1A; line-height:1.85; margin-bottom:16px;">
        Remotion · Agent<br>MCP · 本地优先
      </div>
      <div style="padding-top:16px; border-top:1px solid #E0E0E0; font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#1A1A1A; line-height:1.6;">
        每帧可改 · 可逆<br>时间线即文件
      </div>
    </div>

  </div>

  <!-- 主图 · 不裁切 · 限高避免压底部 -->
  <div style="position:absolute; top:760px; left:60px; right:60px;">
    <img src="../assets-rendered/03-agent-transitions.png" style="display:block; width:100%; max-height:280px; object-fit:contain; border:1.5px solid #1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-size:12px; color:#888; letter-spacing:0.06em; margin-top:10px;">▸ Agent 操作转场 · 真实时间线</div>
  </div>

  <!-- 6 个 stat 横排 · 给独立行 · 松散 -->
  <div style="position:absolute; top:1080px; left:60px; right:60px; padding:20px 0; border-top:1px solid #C8C8C8; border-bottom:1px solid #C8C8C8;">
    <div class="row" style="gap:28px;">
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 100%</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">操作可逆</div>
      </div>
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> $0<span style="font-size:14px; color:#666;">/月</span></div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">本地优先</div>
      </div>
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> ↩∞</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">HISTORY</div>
      </div>
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 24fps</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">电影级</div>
      </div>
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 4 轨</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">V2/V1/A1/A2</div>
      </div>
      <div class="stat">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> MCP</div>
        <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">3 工具</div>
      </div>
    </div>
  </div>

  <!-- ONE LINE -->
  <div style="position:absolute; top:1230px; left:60px; right:60px; padding-left:20px; border-left:4px solid #E63946;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:20px; color:#1A1A1A; line-height:1.55;">
      <span style="color:#E63946;">聊天框告诉你答案</span>——<span style="color:#E63946;">真实工程文件</span>让你继续改
    </div>
  </div>

  <!-- 底部 -->
  <div style="position:absolute; bottom:48px; left:60px; right:60px; display:flex; justify-content:flex-end; align-items:center; gap:10px; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">02 / 06 · 范式对比</div>
    <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
  </div>

</div>
</body>
</html>`;

export const card02 = card02Html;
