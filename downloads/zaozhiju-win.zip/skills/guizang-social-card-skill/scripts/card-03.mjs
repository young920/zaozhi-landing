const card03Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>一句话 → Agent 写入时间线</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=JetBrains+Mono:wght@400;700&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    width: 1080px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    padding: 48px 60px 48px;
    display: flex;
    flex-direction: column;
    gap: 26px;
  }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div style="display:flex; justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · Agent 操作</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">03 · 一句话 → 时间线</div>
  </div>

  <!-- 主标题 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:64px; line-height:1.18; color:#1A1A1A; letter-spacing:-0.02em;">
      一句话<br>→ <span style="color:#E63946;">Agent 写入时间线</span>
    </div>
  </div>

  <!-- 副标题 + 红线 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:24px; color:#1A1A1A; margin-bottom:14px;">它改视频 · 不是出片</div>
    <div style="width:200px; height:4px; background:#E63946;"></div>
  </div>

  <!-- 对话示例：双气泡 -->
  <div style="display:flex; flex-direction:column; gap:14px;">
    <div style="padding:18px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#888; letter-spacing:0.12em; margin-bottom:8px;">▸ USER · 19:24</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:17px; color:#1A1A1A; line-height:1.55;">「把素材池里的「验收生成图」添加到视频 2 轨末尾」</div>
    </div>
    <div style="padding:18px 22px; background:#1A1A1A; border-left:5px solid #E63946;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:8px;">▸ AGENT · 8 秒</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:17px; color:#F5F5F5; line-height:1.55;">✓ 已写入 · V2 当前末尾在 390 帧 · 追加到该位置 · 时长 90 帧（3 秒）</div>
    </div>
  </div>

  <!-- 主图：完整展示 + 自适应高度 -->
  <div>
    <img src="../assets-rendered/04-motion-graphics.png" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-size:12px; color:#888; letter-spacing:0.06em; margin-top:10px;">▸ Motion Graphics · WebGL 动效库</div>
  </div>

  <!-- MCP 工具调用链：左代码 + 右工具列 -->
  <div style="display:flex; gap:24px;">
    <div style="flex:1.4; padding:18px 22px; background:#1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:12px;">▸ TOOL CALL · submit_motion_graphic</div>
      <pre style="margin:0; font-family:'JetBrains Mono','IBM Plex Mono',monospace; font-size:13px; line-height:1.75; color:#F5F5F5;">name<span style="color:#888;">=</span><span style="color:#E63946;">"Counter 0~99"</span>
style<span style="color:#888;">=</span><span style="color:#E63946;">"neon pink glow"</span>
duration<span style="color:#888;">=</span><span style="color:#F5F5F5;">120</span>
position<span style="color:#888;">=</span><span style="color:#E63946;">"V1:0"</span></pre>
    </div>
    <div style="flex:1; padding:18px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#1A1A1A; letter-spacing:0.12em; margin-bottom:12px;">▸ 3 MCP TOOLS</div>
      <div style="font-family:'JetBrains Mono',monospace; font-size:14px; color:#1A1A1A; line-height:1.95;">
        <span style="color:#E63946;">●</span> edit_item<br>
        <span style="color:#E63946;">●</span> read_timeline<br>
        <span style="color:#E63946;">●</span> submit_motion
      </div>
    </div>
  </div>

  <!-- 5 个 stat 横排 -->
  <div style="display:flex; gap:36px; padding:20px 0; border-top:1px solid #C8C8C8; border-bottom:1px solid #C8C8C8;">
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 12</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">内置动效</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 3</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">MCP 工具</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 8秒</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">改完一段</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> 24fps</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">帧级修改</div>
    </div>
    <div style="flex:1;">
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1; margin-bottom:6px;"><span style="color:#E63946;">●</span> ↩∞</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:11px; color:#666; letter-spacing:0.06em;">HISTORY</div>
    </div>
  </div>

  <!-- 底部 -->
  <div style="display:flex; justify-content:flex-end; align-items:center; gap:10px; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">03 / 06 · Agent 操作</div>
    <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
  </div>

</div>
</body>
</html>`;

export const card03 = card03Html;
