const card06Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>4 类人 · 3 步开始</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=JetBrains+Mono:wght@400;700&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    position: relative;
    width: 1080px;
    height: 1440px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    overflow: hidden;
  }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div style="position:absolute; top:48px; left:60px; right:60px; display:flex; justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · Takeaway</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">06 · 谁该用</div>
  </div>

  <!-- 主标题 -->
  <div style="position:absolute; top:130px; left:60px; right:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:72px; line-height:1.18; color:#1A1A1A; letter-spacing:-0.02em;">
      4 <span style="color:#E63946;">类人</span><br>+ 3 <span style="color:#E63946;">步开始</span>
    </div>
  </div>

  <!-- 副标题 + 红线 · 拉大距离 -->
  <div style="position:absolute; top:310px; left:60px;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:22px; color:#1A1A1A; margin-bottom:14px;">谁该用 · 谁不必 · 怎么开始</div>
    <div style="width:120px; height:4px; background:#E63946;"></div>
  </div>

  <!-- 上半：双缩略图（LUT + Effects）· 独立行 · 不裁切 -->
  <div style="position:absolute; top:410px; left:60px; right:60px; display:flex; gap:24px;">
    <div style="flex:1;">
      <img src="../assets-rendered/07-lut.png" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
      <div style="padding:8px 4px 0; font-family:'Inter',sans-serif; font-size:12px; color:#666; letter-spacing:0.06em;">▸ LUT 调色板</div>
    </div>
    <div style="flex:1;">
      <img src="../assets-rendered/05-effects.png" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
      <div style="padding:8px 4px 0; font-family:'Inter',sans-serif; font-size:12px; color:#666; letter-spacing:0.06em;">▸ EFFECTS 12 种</div>
    </div>
  </div>

  <!-- 4 类读者 2×2 · 独立行 · 间距松 · ✓A ✓B 红色阴影 -->
  <div style="position:absolute; top:780px; left:60px; right:60px; display:grid; grid-template-columns:1fr 1fr; gap:18px;">
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #E63946; box-shadow:8px 8px 0 0 #E63946;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:13px; color:#E63946; letter-spacing:0.12em; margin-bottom:8px;">✓ A · 适用</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1.3; margin-bottom:8px;">Codex / Claude 用户</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#666; line-height:1.6;">工作流搬到视频<br>已经习惯用 Agent</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #E63946; box-shadow:8px 8px 0 0 #E63946;">
        <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:13px; color:#E63946; letter-spacing:0.12em; margin-bottom:8px;">✓ B · 适用</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:20px; color:#1A1A1A; line-height:1.3; margin-bottom:8px;">Premiere 老用户</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#666; line-height:1.6;">加 AI 不放弃精控<br>保留专业编辑权</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:13px; color:#888; letter-spacing:0.12em; margin-bottom:8px;">✗ C · 不必</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:20px; color:#888; line-height:1.3; margin-bottom:8px;">只想一句话出片</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#888; line-height:1.6;">用 Veo / Sora / Runway<br>更适合</div>
    </div>
    <div style="padding:20px 22px; background:#FFFFFF; border:1.5px solid #1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:13px; color:#888; letter-spacing:0.12em; margin-bottom:8px;">⚠ D · 等</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:20px; color:#888; line-height:1.3; margin-bottom:8px;">企业法务</div>
      <div style="font-family:'Noto Sans SC',sans-serif; font-size:13px; color:#888; line-height:1.6;">等 v1.0 + 商业协议<br>目前 AGPL</div>
    </div>
  </div>

  <!-- 3 步开始（左命令行 + 右 ONE LINE）· 独立行 -->
  <div style="position:absolute; top:1180px; left:60px; right:60px; display:flex; gap:24px;">
    <div style="flex:1.2; padding:18px 22px; background:#1A1A1A;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:12px;">▸ 3 STEPS · 5 MINUTES</div>
      <pre style="margin:0; font-family:'JetBrains Mono',monospace; font-size:12px; line-height:1.9; color:#F5F5F5;"><span style="color:#E63946;">$ 01</span>  git clone github.com/0xsaline/OpenChatCut
<span style="color:#E63946;">$ 02</span>  cd OpenChatCut && npm install
<span style="color:#E63946;">$ 03</span>  接 Codex 或 Claude MCP</pre>
    </div>
    <div style="flex:1; padding-left:20px; border-left:5px solid #E63946;">
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:11px; color:#E63946; letter-spacing:0.12em; margin-bottom:10px;">§ ONE LINE</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:18px; color:#1A1A1A; line-height:1.55;">
        <span style="color:#E63946;">ChatGPT 改视频</span> ——从聊天框搬进真实时间线编辑器，每一帧可改、可撤销、可继续
      </div>
    </div>
  </div>

  <!-- 底部 -->
  <div style="position:absolute; bottom:48px; left:60px; right:60px; display:flex; justify-content:space-between; align-items:center; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'JetBrains Mono',monospace; font-size:12px; color:#666; letter-spacing:0.06em;">
      ★ github.com/0xsaline/OpenChatCut
    </div>
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">边学 · 边造 · 边验证</div>
      <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
    </div>
  </div>

</div>
</body>
</html>`;

export const card06 = card06Html;
