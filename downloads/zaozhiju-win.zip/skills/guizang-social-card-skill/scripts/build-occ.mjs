import { render } from '../assets/neo-brutalist-yingce-templates/tools.js';
import { card01 } from './card-01.mjs';
import { card02 } from './card-02.mjs';
import { card03 } from './card-03.mjs';
import { card04 } from './card-04.mjs';
import { card05 } from './card-05.mjs';
import { card06 } from './card-06.mjs';

const cards = [
  { num: 1, html: card01 },
  { num: 2, html: card02 },
  { num: 3, html: card03 },
  { num: 4, html: card04 },
  { num: 5, html: card05 },
  { num: 6, html: card06 },
];

render(cards, '/Users/yang/.openclaw/workspace/openchatcut-rec-2026-08-11/output').catch(e => { console.error(e); process.exit(1); });