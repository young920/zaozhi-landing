const card01Html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>把 ChatGPT 装进真实时间线</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Noto+Sans+SC:wght@400;500;700;900&display=swap">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #1A1A1A; display: flex; justify-content: center; padding: 16px; font-family: 'Noto Sans SC', 'Inter', sans-serif; }
  #card {
    width: 1080px;
    background-color: #F5F5F5;
    background-image:
      linear-gradient(to right, #D8D8D8 1px, transparent 1px),
      linear-gradient(to bottom, #D8D8D8 1px, transparent 1px);
    background-size: 40px 40px;
    padding: 48px 60px 48px;
    display: flex;
    flex-direction: column;
    gap: 28px;
  }
  .row { display: flex; gap: 24px; }
</style>
</head>
<body>
<div id="card">

  <!-- 顶部 -->
  <div class="row" style="justify-content:space-between; align-items:center;">
    <div style="display:flex; align-items:center; gap:10px;">
      <div style="width:10px; height:10px; background:#E63946;"></div>
      <div style="font-family:'Inter',sans-serif; font-weight:700; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">OpenChatCut · 一个项目讲明白</div>
    </div>
    <div style="padding:8px 16px; border:1.5px solid #1A1A1A; font-family:'Inter',sans-serif; font-weight:600; font-size:13px; color:#1A1A1A; letter-spacing:0.04em;">Agent · 第一次办事</div>
  </div>

  <!-- 品牌行 -->
  <div style="display:flex; align-items:baseline; gap:14px;">
    <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:32px; color:#1A1A1A; letter-spacing:0.02em;">OPENCHATCUT</div>
    <div style="font-family:'Noto Sans SC',sans-serif; font-weight:500; font-size:14px; color:#1A1A1A; letter-spacing:0.04em;">埃仑瓦 · 我从 0 拆解 Agent 视频编辑器的过程笔记</div>
  </div>

  <!-- 主标题 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:78px; line-height:1.15; color:#1A1A1A; letter-spacing:-0.02em;">
      把 ChatGPT<br>装进<span style="color:#E63946;">真实时间线</span>
    </div>
  </div>

  <!-- 副标题 + 红线 -->
  <div>
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:500; font-size:30px; color:#1A1A1A; margin-bottom:14px;">Agent 改视频 · 不是出片</div>
    <div style="width:120px; height:4px; background:#E63946;"></div>
  </div>

  <!-- 副副标 -->
  <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:400; font-size:18px; color:#1A1A1A; line-height:1.5;">它不会回答"现在几点"——但它会自己去找答案</div>

  <!-- 三个 stat 横排 -->
  <div class="row" style="gap:48px;">
    <div>
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:38px; color:#1A1A1A; line-height:1; margin-bottom:6px;">984<span style="color:#E63946;">★</span></div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:12px; color:#666; letter-spacing:0.06em;">GitHub Stars</div>
    </div>
    <div>
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:38px; color:#1A1A1A; line-height:1; margin-bottom:6px;">v 0.4.2</div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:12px; color:#666; letter-spacing:0.06em;">TypeScript · AGPL</div>
    </div>
    <div>
      <div style="font-family:'Inter',sans-serif; font-weight:900; font-size:38px; color:#1A1A1A; line-height:1; margin-bottom:6px;">$ 0<span style="font-size:22px; color:#666;"> /月</span></div>
      <div style="font-family:'Inter',sans-serif; font-weight:500; font-size:12px; color:#666; letter-spacing:0.06em;">本地优先 · 不上传</div>
    </div>
  </div>

  <!-- 主图：完整展示 · 实际高度自适应 -->
  <div>
    <img src="../assets-rendered/11-neon-nights-full.png" style="display:block; width:100%; height:auto; border:1.5px solid #1A1A1A;">
    <div style="font-family:'Inter',sans-serif; font-size:12px; color:#888; letter-spacing:0.06em; margin-top:10px;">▸ Project Dashboard · OpenChatCut UI</div>
  </div>

  <!-- 这一篇讲什么 + 关键词列表 -->
  <div>
    <div style="display:flex; align-items:flex-start; gap:18px; margin-bottom:16px;">
      <div style="color:#E63946; font-family:'Inter',sans-serif; font-size:28px; font-weight:700; line-height:1; flex-shrink:0;">→</div>
      <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:900; font-size:24px; color:#1A1A1A; padding-top:2px;">这一篇讲什么</div>
    </div>
    <div style="margin-left:46px; font-family:'Noto Sans SC','Inter',sans-serif; font-weight:600; font-size:20px; color:#1A1A1A; line-height:1.6;">
      <span style="color:#E63946;">真实时间线</span> · <span style="color:#E63946;">Agent 操作</span> · <span style="color:#E63946;">MCP 实战</span> · <span style="color:#E63946;">CounterDown 动效</span>
    </div>
  </div>

  <!-- 底部收尾 -->
  <div style="display:flex; justify-content:flex-end; align-items:center; gap:10px; padding-top:20px; border-top:1px solid #C8C8C8;">
    <div style="font-family:'Noto Sans SC','Inter',sans-serif; font-weight:700; font-size:15px; color:#1A1A1A; letter-spacing:0.08em;">边学 · 边造 · 边验证</div>
    <div style="width:8px; height:8px; background:#E63946; border-radius:50%;"></div>
  </div>

</div>
</body>
</html>`;

export const card01 = card01Html;
