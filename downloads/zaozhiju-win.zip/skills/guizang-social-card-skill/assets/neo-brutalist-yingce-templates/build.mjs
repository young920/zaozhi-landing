// build.mjs — neo-brutalist-yingce 项目渲染入口(模板)
// 复制此文件到项目目录,改 import 的 card-XX.mjs 路径即可
// 用法:node build.mjs
//
// 项目结构示例:
//   my-cards/
//     scripts/
//       build.mjs          ← 此文件
//       tools.js           ← 从 skill 软链或复制
//       card-01.mjs ~ card-07.mjs
//     output/              ← 渲染产物
//
// 执行:cd my-cards/scripts && node build.mjs
// 结果:output/card-01.png ~ output/card-NN.png

import { render } from './tools.js';
import { card01 } from './card-01.mjs';
// import { card02 } from './card-02.mjs';
// import { card03 } from './card-03.mjs';
// ... 按需打开注释

const cards = [
  { num: 1, html: card01 },
  // { num: 2, html: card02 },
  // { num: 3, html: card03 },
  // ...
];

render(cards).catch(e => { console.error(e); process.exit(1); });
