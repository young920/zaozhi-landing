// tools.js — neo-brutalist-yingce 共享工具函数
// 2026-08-05 从 loop-engineering-cards 项目抽到 skill
// 风格定义完整保留,下次复用与本次一致
// 用法:import { page, deco, render, chrome } from './tools.js';

import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * 加载 playwright(从 skill 的 node_modules)
 * 使用方需要先 npm install playwright
 */
function loadPlaywright() {
  const require = createRequire(join(__dirname, '..', '..', 'package.json'));
  return require('playwright');
}

// ===== Decorative SVG snippets (inlined into cards) =====
export const deco = {
  // 5-pointed star (yellow filled)
  star: (size = 22, color = '#FFD60A') => {
    const p = `M${size/2},0 L${size*0.61},${size*0.38} L${size},${size*0.38} L${size*0.66},${size*0.6} L${size*0.79},${size} L${size/2},${size*0.76} L${size*0.21},${size} L${size*0.34},${size*0.6} L0,${size*0.38} L${size*0.39},${size*0.38} Z`;
    return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><path d="${p}" fill="${color}" stroke="#1A1A1A" stroke-width="1.5" stroke-linejoin="miter"/></svg>`;
  },
  // warning triangle ▲
  triangle: (size = 18, color = '#FFD60A') =>
    `<svg width="${size}" height="${size*0.86}" viewBox="0 0 18 15"><polygon points="9,0 18,15 0,15" fill="${color}" stroke="#1A1A1A" stroke-width="1.5" stroke-linejoin="miter"/></svg>`,
  // diagonal-stripe block (blue / white)
  diagBlock: (size = 60, color1 = '#0027D6', color2 = '#FFFFFF') =>
    `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><defs><pattern id="p${size}" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="7" height="14" fill="${color1}"/><rect x="7" width="7" height="14" fill="${color2}"/></pattern></defs><rect width="${size}" height="${size}" fill="url(#p${size})" stroke="#1A1A1A" stroke-width="3"/></svg>`,
  // broken pink ring (cos cup stamp feel)
  ringBroken: (size = 60, color = '#FF3D7F', startDeg = 30, endDeg = 330) => {
    const r = size / 2 - 4;
    const cx = size / 2, cy = size / 2;
    const s = polar(cx, cy, r, startDeg);
    const e = polar(cx, cy, r, endDeg);
    const large = endDeg - startDeg > 180 ? 1 : 0;
    return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <path d="M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}"
            stroke="${color}" stroke-width="6" fill="none" stroke-linecap="butt"/>
    </svg>`;
  },
  // arrow →
  arrow: (size = 18, color = '#1A1A1A') =>
    `<svg width="${size}" height="${size*0.6}" viewBox="0 0 18 11"><path d="M0 5 L13 5 M9 0 L14 5 L9 10" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="square"/></svg>`,
  // small clip icon (paperclip)
  clip: (size = 24) =>
    `<svg width="${size*0.5}" height="${size}" viewBox="0 0 12 24"><path d="M6 2 Q2 2 2 6 L2 16 Q2 22 8 22 Q14 22 14 16 L14 8 Q14 6 12 6 Q10 6 10 8 L10 16 Q10 18 8 18 Q6 18 6 16 L6 6" fill="none" stroke="#1A1A1A" stroke-width="1.6"/></svg>`,
  // clipboard w/ check
  clipboardCheck: (size = 32, color = '#1A1A1A') =>
    `<svg width="${size}" height="${size}" viewBox="0 0 32 32"><rect x="6" y="6" width="20" height="24" fill="#FAF3E0" stroke="${color}" stroke-width="2"/><rect x="11" y="2" width="10" height="6" fill="${color}"/><path d="M11 17 L15 21 L22 13" fill="none" stroke="${color}" stroke-width="3" stroke-linecap="square"/></svg>`,
};

function polar(cx, cy, r, deg) {
  const rad = (deg - 90) * Math.PI / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

// ===== Page chrome (header / footer) shared by all cards =====
// 用法:chrome({ num: 1, kicker: 'LOOP ENGINEERING · 评估器', back: '详解 Claude 的循环工程 · 7 张卡' })
export function chrome({ num, kicker = 'LOOP ENGINEERING · EXPLAINED', author = 'NEO-BRUTALIST YINGCE', back = 'CARD' }) {
  return `
  <div style="position:absolute; top:0; left:0; right:0; height:54px; background:#1A1A1A; color:#FAF3E0;
              display:flex; align-items:center; justify-content:space-between; padding:0 36px;
              font-family:'IBM Plex Mono',monospace; font-weight:700; font-size:14px;
              letter-spacing:0.22em; text-transform:uppercase; border-bottom:4px solid #FFD60A;">
    <span style="display:flex; align-items:center; gap:10px;">
      ${deco.triangle(14, '#FFD60A')}
      <span>${kicker}</span>
    </span>
    <span style="opacity:0.85;">${author}</span>
  </div>
  <div style="position:absolute; bottom:0; left:0; right:0; height:64px;
              display:flex; align-items:center; justify-content:space-between; padding:0 36px;
              border-top:4px solid #1A1A1A;
              font-family:'IBM Plex Mono',monospace; font-weight:700; font-size:13px;
              letter-spacing:0.18em; text-transform:uppercase; color:#1A1A1A;">
    <span>${back}</span>
    <span style="display:flex; align-items:center; gap:14px;">
      <span style="opacity:0.55;">${String(num).padStart(2, '0')} / ${String(num).padStart(2, '0')}</span>
      <span style="background:#FFD60A; padding:3px 9px; border:3px solid #1A1A1A; box-shadow:3px 3px 0 #1A1A1A;">${String(num).padStart(2, '0')}</span>
    </span>
  </div>
  `;
}

// ===== Page wrapper =====
// 用法:page({ num: 1, title: '...', body: '...', kicker: '...', back: '...' })
// body 会被包在 1080×1440 paper 内,自动应用 shared.css 样式
export function page({ num, title, body, kicker, back = 'CARD' }) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800;900&family=Noto+Sans+SC:wght@400;500;700;900&family=IBM+Plex+Mono:wght@400;600;700&display=swap">
<link rel="stylesheet" href="${join('file://' + __dirname, 'shared.css')}">
<style>
  body { margin:0; padding:32px; background:#1A1A1A; display:flex; justify-content:center; }
  .stage { position:relative; }
  .stage .paper { margin:0; }
</style>
</head>
<body>
<div class="stage">
  <div class="paper" id="card">
    ${chrome({ num, kicker, back })}
    <div style="position:absolute; top:54px; left:0; right:0; bottom:64px; padding:54px 64px 36px 64px; overflow:hidden;">
      ${body}
    </div>
  </div>
</div>
</body>
</html>`;
}

// ===== Render all cards → PNGs =====
// 用法:import { render } from './tools.js';
//      render([{ num: 1, html: card01Html }, ...], './output')
export async function render(cards, outDir = './output') {
  mkdirSync(outDir, { recursive: true });
  const { chromium } = loadPlaywright();
  const browser = await chromium.launch();
  const pageObj = await browser.newPage({ viewport: { width: 1200, height: 1560 } });
  for (const { num, html } of cards) {
    const tmp = join(outDir, `_tmp-${num}.html`);
    writeFileSync(tmp, html);
    await pageObj.goto('file://' + tmp);
    await pageObj.waitForLoadState('networkidle');
    await pageObj.waitForTimeout(400);
    const target = pageObj.locator('#card');
    const out = join(outDir, `card-${String(num).padStart(2, '0')}.png`);
    await target.screenshot({ path: out });
    console.log('✓', out);
  }
  await browser.close();
}
