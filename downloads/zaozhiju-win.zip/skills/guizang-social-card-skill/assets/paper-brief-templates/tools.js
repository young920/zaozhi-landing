/* ============================================================
   PAPER BRIEF (Mode F) — tools.js
   ------------------------------------------------------------
   共享工具: page / chrome / render / barcode / escape
   page() 返回完整的 5 段结构 HTML（Header + Date + Title +
   Abstract + Findings + Takeaway + Footer），只需传 6 个数据字段。
   ============================================================ */

/**
 * @typedef {Object} PaperBriefData
 * @property {string} brandName       - 顶部 brand 名（如 "PAPER BRIEF"）
 * @property {string} issueLabel      - 顶部右侧期号（如 "/ 15"）
 * @property {string} subbrand        - header 底部副品牌（如 "经济学周刊 · 论文快报"）
 * @property {string} dateLabel       - 日期条（如 "2026.08.05 WED"）
 * @property {string} title           - 英文斜体标题
 * @property {string} journalMeta     - 期刊号 meta（如 "JMS 63(2) · 2026 · pp. 515-560"）
 * @property {string} authors         - 作者 meta（如 "Dominik Siemon / Edona Elshan / et al."）
 * @property {string} abstractHTML    - 摘要正文 HTML（可包含 <span class="pb-mark">高亮</span>）
 * @property {Array<{label:string, body:string}>} findings - KEY FINDINGS 数组
 * @property {string} takeawayLabel   - 一句话总结前缀（如 "一句话总结："）
 * @property {string} takeawayBody    - 一句话总结正文
 * @property {string} doi             - DOI
 * @property {string} volLabel        - 卷期号（如 "VOL.63 · NO.2"）
 * @property {string} barcodeSeed     - 条码随机种子（传数字字符串保证可复现）
 */

/**
 * 生成条码 bars 数组
 * @param {string} seed
 * @returns {string} 条码 <i> 列表
 */
function generateBarcodeBars(seed) {
  const seedNum = parseInt(seed, 10) || 42;
  // 简单伪随机算法，保证可复现
  const bars = [];
  let s = seedNum;
  for (let i = 0; i < 56; i++) {
    s = (s * 9301 + 49297) % 233280;
    const r = s / 233280;
    const widths = [2, 3, 2, 4, 3, 2, 2, 3, 5, 2, 4, 3];
    bars.push(widths[Math.floor(r * widths.length)]);
  }
  return bars.map(w => `<i style="height:${12 + (w * 4)}px"></i>`).join('');
}

/**
 * 转义 HTML 防止 XSS
 */
function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * 渲染 KEY FINDINGS 列表
 */
function renderFindings(findings) {
  return findings.map((f, i) => {
    const num = String(i + 1).padStart(2, '0');
    return `
      <div class="pb-finding-item">
        <div class="pb-finding-num">${num}</div>
        <div class="pb-finding-text"><strong>${escapeHTML(f.label)}：</strong>${escapeHTML(f.body)}</div>
      </div>`;
  }).join('');
}

/**
 * 渲染 STAT STRIP（数字 chip 横排）
 * @param {Array<{value:string, label:string, tone?:string}>} stats
 */
function renderStatStrip(stats) {
  if (!stats || !stats.length) return '';
  const cols = stats.length;
  const chips = stats.map(s => {
    const tone = s.tone === 'accent' ? ' is-accent' : s.tone === 'yellow' ? ' is-yellow' : '';
    return `
      <div class="pb-stat-chip${tone}">
        <div class="pb-stat-value">${escapeHTML(s.value || '')}</div>
        <div class="pb-stat-label">${escapeHTML(s.label || '')}</div>
      </div>`;
  }).join('');
  return `<div class="pb-stat-strip" style="--pb-stat-cols:${cols}">${chips}</div>`;
}

/**
 * 渲染 SOURCE STRIP（学术引用 / 基准出处 · KEY FINDINGS 下方）
 * @param {Array<{tag:string, text:string}>} sources
 */
function renderSourceStrip(sources) {
  if (!sources || !sources.length) return '';
  const items = sources.map(s => `
    <span class="pb-source-item"><strong>${escapeHTML(s.tag || '')}</strong>${escapeHTML(s.text || '')}</span>`).join('');
  return `<div class="pb-source-strip">
    <span class="pb-source-label">SOURCES</span>
    ${items}
  </div>`;
}

/**
 * 渲染 ILLUSTRATION（mini 示意图 SVG）
 * @param {string} svg
 */
function renderIllustration(svg) {
  if (!svg) return '';
  return `<div class="pb-illustration">${svg}</div>`;
}

/**
 * 渲染 COVER HERO（大尺寸 hero 区域 · 封面专用）
 * @param {string} svg
 */
function renderCoverHero(svg) {
  if (!svg) return '';
  return `<div class="pb-cover-hero">${svg}</div>`;
}

/**
 * 渲染 COVER STEPS（6 步索引横排 · 封面专用）
 * @param {Array<{num:string, title:string}>} steps
 */
function renderCoverSteps(steps) {
  if (!steps || !steps.length) return '';
  const items = steps.map(s => `
    <div class="pb-cover-step">
      <div class="pb-cover-step-num">STEP ${escapeHTML(s.num || '')}</div>
      <div class="pb-cover-step-title">${escapeHTML(s.title || '')}</div>
    </div>`).join('');
  return `<div class="pb-cover-steps">${items}</div>`;
}

/**
 * 生成完整的 Paper Brief 单张卡片 HTML
 * @param {PaperBriefData} data
 * @returns {string} 完整 HTML
 */
export function page(data) {
  const barcode = generateBarcodeBars(data.barcodeSeed || '15');
  const isCover = data.isCover === true;
  const headerBrandSize = isCover ? '52px' : '64px';

  return `
<section class="poster${isCover ? ' pb-cover' : ''}" id="paper-brief">
  <div class="pb-grain"></div>

  <header class="pb-header">
    <div class="pb-brand">
      <span class="pb-brand-name" style="font-size:${headerBrandSize}">${escapeHTML(data.brandName || 'PAPER BRIEF')}</span>
      <span class="pb-issue">${escapeHTML(data.issueLabel || '/ 15')}</span>
    </div>
    <span class="pb-issue-right">${escapeHTML(data.subbrand || '')}</span>
    <div class="pb-subbrand">${escapeHTML(data.subbrand || '')}</div>
  </header>

  <div class="pb-frame">

    <div class="pb-top-row">
      <div class="pb-date-strip">${escapeHTML(data.dateLabel || '')}</div>
      ${renderStatStrip(data.stats)}
    </div>

    <h1 class="pb-title">
      <span class="pb-triangle"></span>${escapeHTML(data.title || '')}
    </h1>

    <div class="pb-meta-row">
      <span class="pb-meta-journal">${escapeHTML(data.journalMeta || '')}</span>
      <span class="pb-meta-authors">${escapeHTML(data.authors || '')}</span>
    </div>

    ${data.coverDeckHTML ? `<div class="pb-cover-deck">${data.coverDeckHTML}</div>` : ''}

    ${renderCoverHero(data.coverHero)}

    ${renderCoverSteps(data.coverSteps)}

    <div class="pb-abstract">
      <div class="pb-abstract-head">
        <span class="pb-abstract-icon">&lt;/&gt;</span>
        <span class="pb-abstract-title">ABSTRACT</span>
        <span class="pb-abstract-dots">
          <span></span><span></span><span></span>
        </span>
      </div>
      <div class="pb-abstract-body">${data.abstractHTML || ''}</div>
    </div>

    ${renderIllustration(data.illustration)}

    <div class="pb-findings"${(!data.findings || !data.findings.length) ? ' style="display:none"' : ''}>
      <div class="pb-findings-label">KEY FINDINGS</div>
      ${renderFindings(data.findings || [])}
    </div>

    ${renderSourceStrip(data.sources)}

    ${data.takeawayBody ? `
    <div class="pb-takeaway">
      <span class="pb-takeaway-label">${escapeHTML(data.takeawayLabel || '一句话总结：')}</span>
      ${escapeHTML(data.takeawayBody)}
    </div>` : ''}

    <footer class="pb-footer">
      <div class="pb-barcode">
        <div class="pb-barcode-bars">${barcode}</div>
        <span class="pb-barcode-text">${escapeHTML(data.footerBarcodeText || 'PAPER BRIEF')}</span>
      </div>
      <div class="pb-footer-doi">${escapeHTML(data.footerLeft || `DOI ${data.doi || ''}`)}</div>
      <div class="pb-footer-vol">${escapeHTML(data.volLabel || '')}</div>
    </footer>

  </div>
</section>`;
}

/**
 * 渲染输出辅助：把 page() 输出的 HTML 渲染为 PNG
 * 需要在浏览器/Node 环境下调用 Playwright
 * @param {string} html - page() 返回的完整 HTML（含 outer wrapper）
 * @param {string} outPath - 输出 PNG 路径
 */
export async function render(html, outPath) {
  const { chromium } = await import('playwright');
  const browser = await chromium.launch();
  const ctx = await browser.newContext({
    viewport: { width: 1080, height: 1440 },
    deviceScaleFactor: 1,
  });
  const pageObj = await ctx.newPage();
  await pageObj.setContent(html, { waitUntil: 'networkidle' });
  await pageObj.waitForTimeout(500);
  // 强制截 viewport 1080x1440，绕过 element height 坍塌问题
  await pageObj.screenshot({
    path: outPath,
    clip: { x: 0, y: 0, width: 1080, height: 1440 },
  });
  await browser.close();
}

/**
 * 读取 shared.css 内容
 */
async function loadSharedCSS() {
  const fs = await import('node:fs/promises');
  const path = await import('node:path');
  const cssPath = '/Users/yang/.claude/skills/guizang-social-card-skill/assets/paper-brief-templates/shared.css';
  return await fs.readFile(path.resolve(cssPath), 'utf8');
}

/**
 * 构建完整的 HTML 文档（page + shared.css 内联进 <style>）
 * 关键修复：不依赖外部 <link> 加载，page.setContent() 也不会丢样式。
 */
export async function chrome(content) {
  const css = await loadSharedCSS();
  return `<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<title>Paper Brief</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800;900&family=JetBrains+Mono:wght@400;500;700&family=Noto+Serif+SC:wght@400;500;700;900&family=Playfair+Display:ital,wght@1,700;1,900&family=DM+Serif+Display:ital@1&display=swap" rel="stylesheet">
<style>
${css}
html,body{margin:0;padding:0;background:var(--pb-paper);}
</style>
</head>
<body>${content}</body>
</html>`;
}

export default { page, chrome, render, generateBarcodeBars, escapeHTML };