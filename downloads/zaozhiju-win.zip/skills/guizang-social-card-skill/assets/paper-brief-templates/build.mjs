/* ============================================================
   PAPER BRIEF (Mode F) — build.mjs
   ------------------------------------------------------------
   项目渲染入口模板。每个项目复制一份到项目目录，
   按下方示例填写数据字段即可。
   ============================================================ */

import { page, chrome, render } from '/Users/yang/.claude/skills/guizang-social-card-skill/assets/paper-brief-templates/tools.js';
import fs from 'node:fs/promises';
import path from 'node:path';

// ---------- 1. 数据字段（按真实论文填）----------
const data = {
  brandName:    'PAPER BRIEF',
  issueLabel:   '/ 15',
  subbrand:     '经济学周刊 · 论文快报',
  dateLabel:    '2026.08.05 WED',
  title:        'Beyond Anthropomorphism: Social Presence in Human-AI Collaboration Processes',
  journalMeta:  'JMS 63(2) · 2026 · pp. 515–560',
  authors:      'Dominik Siemon / Edona Elshan / Triparna de Vreede / et al.',
  abstractHTML: '我们常把 AI 做得更像人，期待它因此更好相处、更愿意合作。但「社会临场感」不等于拟人化外观：用户能否感到 AI 在互动中「在场」，还受到<span class="pb-mark">理解性、依赖意愿和团队关系</span>的影响。研究聚焦社会临场感在真实人机协作中的作用。作者通过三个研究检验社会临场感与协作行为的关系，关注团队承诺、对 AI 的依赖意愿，以及熟悉度和可理解性。不仅看「AI 像不像人」，也看这种感知是否改变成员对团队的投入，以及交给 AI 任务的意愿。结果表明，社会临场感与协作动机正相关，且主要通过<span class="pb-mark">团队承诺和相互依赖</span>意愿起作用。当用户熟悉 AI、能理解其行为方式时，这种效应更强。论文超越了「越拟人越好」的直觉，强调人机协作设计需同时提升社会临场感、AI 可理解性和团队关系质量。',

  findings: [
    {
      label: '作用路径',
      body: '社会临场感通过团队承诺和相互依赖意愿影响协作动机',
    },
    {
      label: '熟悉程度',
      body: '熟悉 AI 时，社会临场感对协作的作用更强',
    },
    {
      label: '设计重点',
      body: 'AI 可理解性与拟人化外表同影响人机协作质量',
    },
  ],

  takeawayLabel: '一句话总结：',
  takeawayBody:  '让 AI 看起来像人只是起点，真正决定合作的是人能否理解并依赖它。',

  doi:          '10.1111/joms.70000',
  volLabel:     'VOL.63 · NO.2',
  barcodeSeed:  '15',
};

// ---------- 2. 渲染 ----------
const html = await chrome(page(data));

// ---------- 3. 输出路径（绝对路径）----------
const OUT_DIR = '/Users/yang/.openclaw/workspace/local-tests/paper-brief-001/output';
const OUT_PNG = path.join(OUT_DIR, 'paper-brief-001.png');

await fs.mkdir(OUT_DIR, { recursive: true });
await render(html, OUT_PNG);

console.log(`✓ 已生成: ${OUT_PNG}`);