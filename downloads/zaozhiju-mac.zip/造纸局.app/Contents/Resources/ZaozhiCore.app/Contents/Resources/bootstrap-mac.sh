#!/bin/bash
# 造纸局 Mac 首启/启动脚本（幂等,对齐 Windows 的 bootstrap.ps1）：
#   服务活着→啥也不干;否则 体检缺啥→弹窗确认→一键补齐→后台拉起服务。
#   开发机（存在 ~/Desktop/kami/workbench）直接跑仓库最新代码;分发包把 .app 内载荷解到 ~/.zaozhiju/workbench 再跑。
set -u
RES="$(cd "$(dirname "$0")" && pwd)"     # .app/Contents/Resources
DEV_WB="$HOME/Desktop/kami/workbench"
RUN_HOME="$HOME/.zaozhiju"
RUN_WB="$RUN_HOME/workbench"
LOG="$RUN_HOME/desktop-launch.log"
PORT="${PORT:-8712}"
TOOLBIN="$HOME/.zaozhiju/bin"
mkdir -p "$RUN_HOME"
say() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }
say "── bootstrap 启动 (pid $$, HOME=$HOME) ──"

# GUI 启动（Dock/Finder）的 PATH 很干净,node/npm/claude 可能不在——常见位置补一遍
for p in /usr/local/bin /opt/homebrew/bin "$HOME/.local/bin" "$HOME/.pyenv/shims" "$HOME"/.nvm/versions/node/*/bin "$TOOLBIN"; do
  [ -d "$p" ] || continue
  case ":$PATH:" in *":$p:"*) ;; *) PATH="$PATH:$p" ;; esac
done
export PATH

# -1) 服务已活着：直接退出（窗口重开秒进）；AUTO 模式（设置页/失败卡发起的一键补依赖）放行到下面补齐
if [ "${ZAOZHIJU_AUTO:-0}" != 1 ] && curl -s --max-time 2 "http://127.0.0.1:${PORT}/api/types" >/dev/null 2>&1; then exit 0; fi

# -0.5) 登记装机脚本与 App 位置（「一键补依赖」「一键升级」靠这两个文件找到路）
BOOT_ABS="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
echo "$BOOT_ABS" > "$RUN_HOME/setup.loc"

# 0) 硬前提 Node（装过 claude CLI 自然有）
if ! command -v node >/dev/null 2>&1; then
  say "缺 Node.js：引导去官网安装"
  osascript -e 'display dialog "造纸局需要先安装 Node.js（装过 claude 命令行的机器自带）。装好后重新打开造纸局即可。" buttons {"打开下载页"} default button 1 with title "造纸局 · 装机"' >/dev/null 2>&1
  open "https://nodejs.org/en/download"
  exit 1
fi
if ! command -v claude >/dev/null 2>&1; then say "提醒：没找到 claude 命令——界面能开,但出单会失败。先跑 npm install -g @anthropic-ai/claude-code 并登录 claude"; fi

# 1) 选代码目录：开发机用仓库（永远最新）;分发机解包载荷（版本戳变了才重解,已有 node_modules/data 不动）
if [ -f "$DEV_WB/server/server.mjs" ]; then
  WB="$DEV_WB"
  say "开发机模式：直接跑仓库代码 $WB"
else
  [ -d "$RES/workbench/server" ] || { say "包内没有载荷(构建异常):$RES/workbench"; exit 1; }
  echo "$(cd "$RES/../.." && pwd)" > "$RUN_HOME/app.loc"
  CUR="$(cat "$RES/workbench/.built-at" 2>/dev/null || echo none)"
  OLD="$(cat "$RUN_HOME/payload.stamp" 2>/dev/null || echo old)"
  if [ "$CUR" != "$OLD" ]; then
    say "解包载荷 → $RUN_WB …"
    mkdir -p "$RUN_WB"
    rsync -a --delete --exclude node_modules --exclude data "$RES/workbench/" "$RUN_WB/"
    echo "$CUR" > "$RUN_HOME/payload.stamp"
    say "载荷就位"
  fi
  WB="$RUN_WB"
fi

# 2) 体检：列缺项（全部已有则不打扰）
SK="$HOME/.claude/skills"
GZ="$SK/guizang-social-card-skill"
MISSING_SKILLS=""
for s in kami guizang-social-card-skill sweety-statechart-video arch-diagram; do
  [ -f "$SK/$s/SKILL.md" ] || MISSING_SKILLS="$MISSING_SKILLS $s"
done
NEED=""
[ -n "$MISSING_SKILLS" ] && NEED="${NEED}做法技能文件(出卡/出文档/出视频;$(( $(echo $MISSING_SKILLS | wc -w) )) 个)、"
[ -d "$WB/node_modules/fflate" ] || NEED="${NEED}服务端小依赖(npm,几十MB)、"
# playwright 浏览器缓存:mac 在 ~/Library/Caches,Linux 在 ~/.cache——两个都认(Mac 上只查 .cache 会误报缺,每次白下 130MB)
has_chromium() { ls "$HOME/Library/Caches/ms-playwright" "$HOME/.cache/ms-playwright" 2>/dev/null | grep -q chromium; }
if [ ! -d "$GZ/node_modules/playwright" ] || ! has_chromium; then
  NEED="${NEED}出卡浏览器内核(约130MB)、"
fi
NEED_PYLIBS=""
NEED_PY_POPUP=0
if command -v python3 >/dev/null 2>&1 && python3 -c "import sys" >/dev/null 2>&1; then
  for m in weasyprint pypdf fitz edge_tts pptx docx; do
    python3 -c "import $m" >/dev/null 2>&1 || NEED_PYLIBS="$NEED_PYLIBS $m"
  done
  # weasyprint 挂但只挂在本机组件(pango 等,没 brew 装不了)时:产品自动走 Chromium 排版路,产出不受影响——不算缺项,别每次开机弹窗(2026-11-08 实机确诊弹窗死循环根因)
  OTHER_LIBS="$(echo "$NEED_PYLIBS" | sed 's/weasyprint//;s/ //g')"
  if [ -n "$OTHER_LIBS" ]; then NEED="${NEED}Python 排版/配音/文档库(PDF/Word/PPT/视频必需)、"; NEED_PY_POPUP=1; fi
  if [ -n "$NEED_PYLIBS" ] && [ "$NEED_PY_POPUP" = 0 ]; then
    say "weasyprint 缺系统组件(本机没 brew 装不了 pango)：产品走 Chromium 排版路,不算缺项"
  fi
else
  NEED="${NEED}可用的 python3(缺则先跑 xcode-select --install)、"
  NEED_PY_POPUP=1
fi
HAS_FFMPEG=0; command -v ffmpeg >/dev/null 2>&1 && HAS_FFMPEG=1
[ "$HAS_FFMPEG" = 0 ] && NEED="${NEED}ffmpeg(视频剪辑必需,约100MB)、"
# Word 需要的转换器 pandoc(装到 ~/.zaozhiju/bin,服务端自动可见)——2026-11-08 新增
HAS_PANDOC=0
{ command -v pandoc >/dev/null 2>&1 || [ -x "$TOOLBIN/pandoc" ]; } && HAS_PANDOC=1
[ "$HAS_PANDOC" = 0 ] && NEED="${NEED}Word 转换工具 pandoc(约20MB)、"
# PPT 目检放映软件:Keynote/soffice 有其一即可(都没有时 PPT 单会如实标注没做目检,不算崩)
HAS_VIEWER=0
{ [ -d /Applications/Keynote.app ] || command -v soffice >/dev/null 2>&1; } && HAS_VIEWER=1
[ "$HAS_VIEWER" = 0 ] && NEED="${NEED}PPT 目检放映软件(Keynote/LibreOffice 任一)、"
NEED="${NEED%、}"

# 3) 弹窗确认（ZAOZHIJU_AUTO=1 跳过弹窗直接装;选过"先不装"就记号在案不再问,设置页可重新打开询问）
DO=0
SKIP_MARK="$HOME/.zaozhiju/skip-setup"
if [ -n "$NEED" ]; then
  if [ "${ZAOZHIJU_AUTO:-0}" = 1 ]; then
    DO=1; say "体检缺:${NEED}；AUTO 模式直接补齐"
  elif [ -f "$SKIP_MARK" ]; then
    say "体检缺:${NEED}；你之前选过先不装——跳过弹窗直接起服务(设置页可重新问)"
  else
    CHOICE="$(osascript -e "display dialog \"造纸局体检：这台电脑还缺 ${NEED} 。『一键装齐』约 10-20 分钟,期间保持窗口开着；『先不装』缺的功能暂不可用,其余照常,之后不再打扰(设置页可随时重新打开询问)。\" with title \"造纸局 · 首次装机\" buttons {\"先不装\",\"一键装齐\"} default button \"一键装齐\" giving up after 90" 2>/dev/null)"
    mkdir -p "$HOME/.zaozhiju"
    case "$CHOICE" in
      *一键装齐*) DO=1; rm -f "$SKIP_MARK"; say "弹窗:一键装齐(缺:${NEED})";;
      *先不装*) say "弹窗:先不装(缺:${NEED}),记号在案不再问"; : > "$SKIP_MARK";;
      *) say "弹窗没人点/不可用:先起服务,暂不再问(设置页可重新打开询问)(缺:${NEED})"; : > "$SKIP_MARK";;
    esac
  fi
else
  say "体检:什么都不缺,直接起服务"
fi

# 4) 按缺项补齐（每项先判有无,已有不重做）
if [ "$DO" = 1 ]; then
  mkdir -p "$SK"
  for s in $MISSING_SKILLS; do
    if [ -d "$WB/skills/$s" ]; then cp -R "$WB/skills/$s" "$SK/"; say "已安装技能 $s"; else say "载荷缺技能 $s(异常)"; fi
  done
  if [ ! -d "$WB/node_modules/fflate" ]; then
    say "安装服务端依赖 npm install …"
    ( cd "$WB" && npm install --no-audit --no-fund --loglevel=error ) >>"$LOG" 2>&1
    say "服务端依赖完成"
  fi
  if [ ! -d "$GZ/node_modules/playwright" ] && [ -f "$GZ/package.json" ]; then
    say "安装 guizang 技能依赖 …"
    ( cd "$GZ" && npm install --no-audit --no-fund --loglevel=error ) >>"$LOG" 2>&1
  fi
  if ! has_chromium; then
    say "下载 playwright chromium …"
    ( cd "$GZ" && npx playwright install chromium ) >>"$LOG" 2>&1
    say "chromium 安装完成"
  fi
  if [ -n "$NEED_PYLIBS" ]; then
    # weasyprint 需要系统级 pango：有 brew 就顺带补上(没有也不拦——Chromium 排版路已验证可用)
    if command -v brew >/dev/null 2>&1 && ! brew list pango >/dev/null 2>&1; then
      say "brew 安装 pango(weasyprint 的系统组件) …"
      brew install pango >>"$LOG" 2>&1 && say "pango 就位" || say "pango 装失败：weasyprint 走 Chromium 排版路代替,不影响出 PDF"
    fi
    say "pip 安装 Python 库 …"
    python3 -m pip install --user --quiet --disable-pip-version-check weasyprint pypdf pymupdf edge-tts python-pptx python-docx >>"$LOG" 2>&1 && say "Python 库完成" || say "pip 装失败：手动跑 python3 -m pip install --user weasyprint pypdf pymupdf edge-tts python-pptx python-docx"
    # macOS 的 dyld 只在「解释器自己的 lib 目录」和系统目录里找组件,环境变量传不进去(SIP 剥除)——
    # brew 装好的排版组件要软链进 python 的 lib 目录,WeasyPrint 才真正复活(2026-11-08 杨机实测:链完 import 即通)
    if command -v brew >/dev/null 2>&1 && python3 -c "import weasyprint" 2>&1 | grep -q "could not import"; then
      PYLIB="$(python3 -c 'import sys; print(sys.prefix)')/lib"
      if [ -d "$PYLIB" ] && [ -w "$PYLIB" ]; then
        for spec in "glib libgobject-2.0.0.dylib" "pango libpango-1.0.dylib" "pango libpangoft2-1.0.dylib" "harfbuzz libharfbuzz.0.dylib" "harfbuzz libharfbuzz-subset.0.dylib" "fontconfig libfontconfig.1.dylib"; do
          set -- $spec
          F="$(brew --prefix "$1" 2>/dev/null)/lib/$2"
          if [ -f "$F" ] && [ ! -e "$PYLIB/$2" ]; then ln -s "$F" "$PYLIB/$2" && say "排版组件已链入 $2"; fi
        done
        python3 -c "import weasyprint" >/dev/null 2>&1 && say "weasyprint 复活(原班排版引擎归队)" || say "链完仍不可用：继续走 Chromium 排版路"
      fi
    fi
  fi
  if [ "$HAS_FFMPEG" = 0 ]; then
    if command -v brew >/dev/null 2>&1; then
      say "brew 安装 ffmpeg …"
      brew install ffmpeg >>"$LOG" 2>&1 && say "ffmpeg 就位" || say "ffmpeg 装失败：手动 brew install ffmpeg"
    else
      say "缺 ffmpeg 且没有 brew：蜡笔视频暂不可用。手动补：先装 brew（https://brew.sh）再 brew install ffmpeg"
    fi
  fi
  if [ "$HAS_PANDOC" = 0 ]; then
    say "下载 pandoc(Word 转换) …"
    case "$(uname -m)" in arm64) PARCH=arm64 ;; *) PARCH=x86_64 ;; esac
    PURL="https://github.com/jgm/pandoc/releases/download/3.13/pandoc-3.13-${PARCH}-macOS.zip"
    PTMP="$RUN_HOME/.pandoc-dl"; rm -rf "$PTMP"; mkdir -p "$PTMP" "$TOOLBIN"
    if ! curl -fsSL --max-time 150 -o "$PTMP/p.zip" "$PURL" >>"$LOG" 2>&1; then
      # 直连 GitHub 失败:改用「网络设置」里的系统代理再试一次(2026-11-08 杨机实测:直连不稳)
      PH="$(scutil --proxy 2>/dev/null | awk '/HTTPSProxy/{print $3; exit}')"; PP="$(scutil --proxy 2>/dev/null | awk '/HTTPSPort/{print $3; exit}')"
      if [ -n "$PH" ]; then
        say "直连失败,走系统代理 ${PH}:${PP:-8080} 重试 …"
        curl -fsSL --max-time 300 -x "http://${PH}:${PP:-8080}" -o "$PTMP/p.zip" "$PURL" >>"$LOG" 2>&1
      fi
    fi
    ( cd "$PTMP" && unzip -oq p.zip ) >>"$LOG" 2>&1
    PBIN="$(find "$PTMP" -type f -name pandoc 2>/dev/null | head -1)"
    if [ -n "$PBIN" ]; then
      cp "$PBIN" "$TOOLBIN/pandoc" && chmod +x "$TOOLBIN/pandoc" && say "pandoc 就位($TOOLBIN/pandoc)"
    else
      say "pandoc 下载失败：Word 单会如实报缺。手动补:https://github.com/jgm/pandoc/releases 下载 macOS zip,把里边的 pandoc 可执行文件放进 $TOOLBIN"
    fi
    rm -rf "$PTMP"
  fi
  if [ "$HAS_VIEWER" = 0 ]; then
    if command -v brew >/dev/null 2>&1; then
      say "brew 安装 LibreOffice(PPT 目检放映,较大) …"
      brew install --cask libreoffice >>"$LOG" 2>&1 && say "LibreOffice 就位" || say "LibreOffice 装失败:PPT 单仍出,但目检环节会如实标注"
    else
      say "缺目检放映软件且没有 brew:装 Keynote(App Store)或 https://www.libreoffice.org ,不装 PPT 单会如实标注没做目检"
    fi
  fi
fi

# 5) Pexels 配图钥匙空占位（不联网不弹窗;想配实拍图把 Mac 上同名文件内容粘进来即可）
mkdir -p "$HOME/.lapian"
[ -f "$HOME/.lapian/pexels_key" ] || { echo "" > "$HOME/.lapian/pexels_key"; say "已建空 ~/.lapian/pexels_key（不粘=纯排版交付,不算故障）"; }

# 6) 起服务（常驻后台,下次开秒进;AUTO 补依赖时服务已在跑就不重复起）
if curl -s --max-time 2 "http://127.0.0.1:${PORT}/api/types" >/dev/null 2>&1; then say "服务已在运行（本次只补齐依赖,不重复起）"; exit 0; fi
say "启动造纸局服务 http://127.0.0.1:${PORT} (代码目录 ${WB})"
# 子 shell + trap(继承 SIG_IGN,等效 nohup) + exec：$! 就是 node 真身 pid（旧写法记的是包装进程,一键升级杀不掉旧服务）
( cd "$WB"; trap '' HUP; exec node server/server.mjs >>"$LOG" 2>&1 ) & echo $! > "$RUN_HOME/server.pid"
